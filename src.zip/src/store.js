import { create } from "zustand";
import { useEffect } from "react";  
import { useSocket } from "./SocketContext";  // Ensure this is the correct custom hook or context.
import SystemData from "./Servo/LiveData/RunningData/SystemData";
import { createTheme } from "@mui/material";

const useHealthStore = create((set) => ({
    healthStatus: null,
    setHealthStatus: (data) => set({ healthStatus: data })
}));

const useRunningDataStore = create((set) => ({
    runningData: null,
    setRunningData: (data) => set({ runningData: data })
}));

// Fixed typo in store name: useSytemDataStore -> useSystemDataStore
const useSystemDataStore = create((set) => ({
    systemData: null,
    setSystemData: (data) => set({ systemData: data })
}));


export const useHealthStatusListener = () => {
    const setHealthStatus = useHealthStore((state) => state.setHealthStatus);
    const socket = useSocket();

    useEffect(() => {
        if (socket) {
            // Only attach listener if socket is available
            socket.on("healthStatus", (data) => {
                setHealthStatus(data);
            });

            return () => {
                socket.off("healthStatus");
            };
        }
    }, [setHealthStatus, socket]);
};


export const useRunningDataListener = () => {
    const setRunningData = useRunningDataStore((state) => state.setRunningData);
    const socket = useSocket();

    useEffect(() => {
        if (socket) {
            // Only attach listener if socket is available
            socket.on("runningData", (data) => {
                setRunningData(data);
            });

            return () => {
                socket.off("runningData");
            };
        }
    }, [setRunningData, socket]);
};

export { useHealthStore, useRunningDataStore, useSystemDataStore };  // Export the new store too.
