// import React, { useState } from 'react';
// import { Button, TextField, Box, Typography, Grid, Container } from '@mui/material';  // Material UI components
// import { sendFormData } from "../../services/websocketServer";  // Assume you have a function to send data to the backend

// import { useSocket } from "../../SocketContext";

// const CalibrationMode = () => {
//   // State to hold form data
//   const [formData, setFormData] = useState({
//     azimuthStartAngle: '',
//     azimuthEndAngle: '',
//     azimuthScanSpeed: '',
//     azimuthAcceleration: '',
//     azimuthDeceleration: '',
//     elevationStartAngle: '',
//     elevationEndAngle: '',
//     elevationStepAngle: '',
//     elevationScanSpeed: '',
//     elevationAcceleration: '',
//     elevationDeceleration: '',
//     backTrack: '', // Back_Track (Ebl/Disable)
//   });

//   // Handle input changes
//   const handleChange = (event) => {
//     setFormData({
//       ...formData,
//       [event.target.name]: event.target.value,
//     });
//   };

// const socket=useSocket();
//   // Handle form submission (send data to the backend)
//   const handleSubmit = () => {
//     // sendFormData(formData);
//         console.log("Form data sent:", formData);
//     socket.emit("calibrationCommand",(formData));

//   };

//   return (
//     <Container maxWidth="md" sx={{ padding: 4, backgroundColor: '' }}>
//       <Typography variant="h4" align="center" sx={{ marginBottom: 3 }}>
//         Calibration Mode
//       </Typography>
//       <Box component="form" noValidate autoComplete="off">
//         <Grid container spacing={3}>
//           {/* Azimuth Parameters */}
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Azimuth Start Angle"
//               variant="outlined"
//               fullWidth
//               name="azimuthStartAngle"
//               value={formData.azimuthStartAngle}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Azimuth End Angle"
//               variant="outlined"
//               fullWidth
//               name="azimuthEndAngle"
//               value={formData.azimuthEndAngle}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Azimuth Scan Speed"
//               variant="outlined"
//               fullWidth
//               name="azimuthScanSpeed"
//               value={formData.azimuthScanSpeed}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Azimuth Acceleration"
//               variant="outlined"
//               fullWidth
//               name="azimuthAcceleration"
//               value={formData.azimuthAcceleration}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Azimuth Deceleration"
//               variant="outlined"
//               fullWidth
//               name="azimuthDeceleration"
//               value={formData.azimuthDeceleration}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>

//           {/* Elevation Parameters */}
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Elevation Start Angle"
//               variant="outlined"
//               fullWidth
//               name="elevationStartAngle"
//               value={formData.elevationStartAngle}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Elevation End Angle"
//               variant="outlined"
//               fullWidth
//               name="elevationEndAngle"
//               value={formData.elevationEndAngle}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Elevation Step Angle"
//               variant="outlined"
//               fullWidth
//               name="elevationStepAngle"
//               value={formData.elevationStepAngle}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Elevation Scan Speed"
//               variant="outlined"
//               fullWidth
//               name="elevationScanSpeed"
//               value={formData.elevationScanSpeed}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Elevation Acceleration"
//               variant="outlined"
//               fullWidth
//               name="elevationAcceleration"
//               value={formData.elevationAcceleration}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               label="Elevation Deceleration"
//               variant="outlined"
//               fullWidth
//               name="elevationDeceleration"
//               value={formData.elevationDeceleration}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>

//           {/* Back Track Parameter */}
//           <Grid item xs={12}>
//             <TextField
//               label="Back Track (Ebl/Disable)"
//               variant="outlined"
//               fullWidth
//               name="backTrack"
//               value={formData.backTrack}
//               onChange={handleChange}
//               sx={{
//                 '& .MuiInputBase-input': {
//                   color: 'black', // Change text color to white when focused
//                 },
//                 '& .MuiInputLabel-root': {
//                   color: 'black', // Set the label color to white
//                 },
//                 '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
//                   borderColor: 'black', // Change border color when focused
//                 },
//                 '& .MuiInputLabel-root.Mui-focused': {
//                   color: 'black', // Ensure the label stays white when focused
//                 },
//               }}
//             />
//           </Grid>
//         </Grid>

//         {/* Calibration Start/Stop Button */}
//         <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: 4 }}>
//           <Button
//             variant="contained"
//             color="secondary"
//             sx={{
//               padding: '12px 24px',
//               borderRadius: '30px',
//               boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
//               transition: '0.3s ease-in-out',
//               '&:hover': {
//                 backgroundColor: '#d32f2f',
//                 boxShadow: '0 8px 16px rgba(0, 0, 0, 0.3)',
//               },
//               fontSize: '16px',
//               fontWeight: 'bold',
//             }}
//             onClick={handleSubmit}
//           >
//             Submit
//           </Button>
//         </Box>
//       </Box>
//     </Container>
//   );
// };

// export default CalibrationMode;

import React, { useState } from "react";
import {
  Button,
  TextField,
  Box,
  Typography,
  Grid,
  Container,
  FormControlLabel,
  Switch,
} from "@mui/material"; // Material UI components
import { sendFormData } from "../../services/websocketServer"; // Assume you have a function to send data to the backend

import { useSocket } from "../../SocketContext";

const CalibrationMode = () => {
  // State to hold form data
  const [formData, setFormData] = useState({
    azimuthStartAngle: "",
    azimuthEndAngle: "",
    azimuthScanSpeed: "",
    azimuthAcceleration: "",
    azimuthDeceleration: "",
    elevationStartAngle: "",
    elevationEndAngle: "",
    elevationStepAngle: "",
    elevationScanSpeed: "",
    elevationAcceleration: "",
    elevationDeceleration: "",
    backTrack: "", // Back_Track (Ebl/Disable)
  });

  // Handle input changes
  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;

    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value, // Ensure checkboxes store boolean values
    });
  };
  const socket = useSocket();
  // Handle form submission (send data to the backend)
  const handleSubmit = () => {
    // sendFormData(formData);
    console.log("Form data sent:", formData);
    socket.emit("calibrationCommand", formData);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    // For the Azimuth and Elevation angles (0-360)
    if (
      (name.includes("Angle") && (value < 0 || value > 360)) ||
      // For scan speed, acceleration, and deceleration (0-6)
      ((name.includes("Speed") ||
        name.includes("Acceleration") ||
        name.includes("Deceleration")) &&
        (value < 0 || value > 6)) ||
      // For step angle (0-30)
      (name === "elevationStepAngle" && (value < 0 || value > 30))
    ) {
      return; // Prevent changing the value if it's out of the valid range
    }
    handleChange(event); // Proceed with regular state update
  };

  return (
    <Container maxWidth="md" sx={{ padding: 4, backgroundColor: "" }}>
      <Typography
        variant="h4"
        align="center"
        sx={{ marginBottom: 3, fontFamily: "'Times New Roman', serif" }}
      >
        Calibration Mode
      </Typography>
      <Box component="form" noValidate autoComplete="off">
        <Grid container spacing={3}>
          {/* Azimuth Parameters */}
          <Grid item xs={12} sm={6}>
            <TextField
              label="Azimuth Start Angle"
              variant="outlined"
              fullWidth
              name="azimuthStartAngle"
              value={formData.azimuthStartAngle}
              onChange={handleInputChange}
              helperText="0-360"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Azimuth End Angle"
              variant="outlined"
              fullWidth
              name="azimuthEndAngle"
              value={formData.azimuthEndAngle}
              onChange={handleInputChange}
              helperText="0-360"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the input
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Azimuth Scan Speed"
              variant="outlined"
              fullWidth
              name="azimuthScanSpeed"
              value={formData.azimuthScanSpeed}
              onChange={handleInputChange}
              helperText="0-6"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Azimuth Acceleration"
              variant="outlined"
              fullWidth
              name="azimuthAcceleration"
              value={formData.azimuthAcceleration}
              onChange={handleInputChange}
              helperText="0-6"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Azimuth Deceleration"
              variant="outlined"
              fullWidth
              name="azimuthDeceleration"
              value={formData.azimuthDeceleration}
              onChange={handleInputChange}
              helperText="0-6"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>

          {/* Elevation Parameters */}
          <Grid item xs={12} sm={6}>
            <TextField
              label="Elevation Start Angle"
              variant="outlined"
              fullWidth
              name="elevationStartAngle"
              value={formData.elevationStartAngle}
              onChange={handleInputChange}
              helperText="0-360"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Elevation End Angle"
              variant="outlined"
              fullWidth
              name="elevationEndAngle"
              value={formData.elevationEndAngle}
              onChange={handleInputChange}
              helperText="0-360"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Elevation Step Angle"
              variant="outlined"
              fullWidth
              name="elevationStepAngle"
              value={formData.elevationStepAngle}
              onChange={handleInputChange}
              helperText="0-30"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Elevation Scan Speed"
              variant="outlined"
              fullWidth
              name="elevationScanSpeed"
              value={formData.elevationScanSpeed}
              onChange={handleInputChange}
              helperText="0-6"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Elevation Acceleration"
              variant="outlined"
              fullWidth
              name="elevationAcceleration"
              value={formData.elevationAcceleration}
              onChange={handleInputChange}
              helperText="0-6"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Elevation Deceleration"
              variant="outlined"
              fullWidth
              name="elevationDeceleration"
              value={formData.elevationDeceleration}
              onChange={handleInputChange}
              helperText="0-6"
              FormHelperTextProps={{
                sx: {
                  fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the helper text
                  fontWeight: "bold", // Make the helper text bold
                },
              }}
              sx={{
                "& .MuiInputBase-input": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif",
                },
                "& .MuiInputLabel-root": {
                  color: "black",
                  fontFamily: "'Times New Roman', serif", // Adding Times New Roman font to the label
                  fontWeight: "bold",
                },
                "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "black",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "black",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={formData.backTrack} // Ensure it reflects the state value (true or false)
                  onChange={handleChange} // Call the handleChange function when toggled
                  name="backTrack"
                  color="secondary" // Switch color (you can change this)
                  sx={{
                    "& .MuiSwitch-switchBase.Mui-checked": {
                      color: "#6aa86e", // Green when checked (enabled)
                    },
                    "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                      backgroundColor: "#6aa86e", // Green track when checked (enabled)
                    },
                    "& .MuiSwitch-track": {
                      backgroundColor: "#d4727a", // Light gray track color when unchecked
                    },
                    "& .MuiSwitch-thumb": {
                      backgroundColor: formData.backTrack ? "green" : "red", // White thumb
                    },
                    // Change the color of the switch when unchecked (disabled state)
                    "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                      backgroundColor: formData.backTrack ? "green" : "red", // Green when enabled, Red when disabled
                    },
                  }}
                />
              }
              label={
                formData.backTrack
                  ? "Back Track (Enable)"
                  : "Back Track (Disable)"
              } // Dynamic label based on state
              labelPlacement="end"
              sx={{
                "& .MuiFormControlLabel-label": {
                  color: "#333", // Set label color to dark gray
                  fontSize: "20px",
                  fontWeight: 600,
                  textTransform: "capitalize",
                  paddingLeft: "12px",
                  fontFamily: "'Times New Roman', serif",
                },
                display: "flex",
                alignItems: "center",
              }}
            />
          </Grid>
        </Grid>

        {/* Calibration Start/Stop Button */}
        <Box sx={{ display: "flex", justifyContent: "center", marginTop: 4 }}>
          <Button
            variant="contained"
            color="secondary"
            sx={{
              padding: "12px 24px",
              borderRadius: "30px",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
              transition: "0.3s ease-in-out",
              "&:hover": {
                backgroundColor: "#d32f2f",
                boxShadow: "0 8px 16px rgba(0, 0, 0, 0.3)",
              },
              fontSize: "16px",
              fontWeight: "bold",
              fontFamily: "'Times New Roman', serif",
            }}
            onClick={handleSubmit}
          >
            Send Data
          </Button>
        </Box>
      </Box>
    </Container>
  );
};

export default CalibrationMode;
