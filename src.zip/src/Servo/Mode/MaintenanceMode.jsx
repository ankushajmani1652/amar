import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  Grid,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
} from "@mui/material";
import { connectToSocket, sendFormData } from "../../services/websocketServer";
import "../Mode/MaintenanceMode.css";

const MaintenanceMode = () => {
  const [parameters, setParameters] = useState({
    "AZ Brake Release": false,
    "EL Brake Release": false,
    "EL Limit Switch By pass": false,
    "AZ Jog Clockwise(+)": false,
    "AZ Jog Counter Clockwise(-)": false,
    "EL Jog Clockwise(+)": false,
    "EL Jog Counter Clockwise(-)": false,
    "Error Reset": false,
  });

  const handleToggle = (param) => {
    setParameters((prevState) => ({
      ...prevState,
      [param]: !prevState[param],
    }));
  };

  return (
    <div className="container">
      <h1
        style={{
          fontWeight: "bold",
          fontFamily: "'Times New Roman', serif", // Font for the label
        }}
      >
        Maintenance Mode
      </h1>
      <p
        style={{
          fontWeight: "bold",
          fontFamily: "'Times New Roman', serif", // Font for the label
        }}
      >
        Control and reset the maintenance parameters below.
      </p>

      <div className="toggle-list">
        {Object.keys(parameters).map((param) => (
          <div key={param} className="toggle-item">
            <span
              className="label"
              style={{
                fontWeight: "bold",
                fontFamily: "'Times New Roman', serif",
              }}
            >
              {param.replace(/([A-Z])/g, " $1").trim()}
            </span>
            <div className="toggle-switch">
              <input
                type="checkbox"
                id={param}
                className="toggle-checkbox"
                checked={parameters[param]}
                onChange={() => handleToggle(param)}
              />
              <label htmlFor={param} className="toggle-label">
                <span className="switch"></span>
              </label>
            </div>
            <span className="status-text" style={{ fontWeight: "bold",fontFamily: "'Times New Roman', serif" 
 }}>
              {parameters[param] ? "ON" : "OFF"}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MaintenanceMode;
