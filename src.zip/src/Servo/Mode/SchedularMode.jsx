import React from 'react'

const SchedularMode = () => {
  return (
    <div>
      SchedularMode
    </div>
  )
}

export default SchedularMode
