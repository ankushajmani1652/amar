import React, { useState, useEffect } from "react";
import { Card, CardContent, Grid, Typography, Divider } from "@mui/material";
import CircleIcon from "@mui/icons-material/Circle";
import { useSocket } from "../../../SocketContext";
import { Volume } from "lucide-react";
import { useRunningDataListener, useRunningDataStore } from "../../../store";



const SystemData = () => {
 


  const systemData=useRunningDataStore((state)=>state.runningData);

  useRunningDataListener();



  const [responseValues,setResponseValues]=useState({
    systemData: {
      time: null,
      emmStatus: {
        radomeEStopSwitch1: false,
        radomeDoorSwitch: false,
        radomeEStopSwitch2: false,
        servoPanelEStop: false,
        azDriveError: false,
        elDriveError: false,
        systemReady: false,
        systemEnabled: false,
      },
      operationParameters: {
        radomeEStopSwitch1: false,
        radomeDoorSwitch: false,
        radomeEStopSwitch2: false,
        servoPanelEStop: false,
        azDriveError: false,
        elDriveError: false,
        systemReady: false,
        systemEnabled: false,
      },
      syncSignalsStatus: false,
      operationMode: 0,
      scanType: 0,
      runningElevationScanNo: 0,
      runningAzimuthScanNo: 0,
      dataReady: false,
      azimuthDwellSignalLastCycleCount: 0,
      azimuthDwellSignalRunningCycleCount: 0,
      elevationDwellSignalLastCycleCount: 0,
      elevationDwellSignalRunningCycleCount: 0,
      servoPanelIncomePowerSupplyStatus: false,
    }
  });


  const socket=useSocket();

  // useEffect(() => {
  //     socket.on("runningData", (data) => {
  //       console.log(`Received System Data: ${JSON.stringify(data.systemData)}`);
  
  //       setResponseValues(data);
  
  //     })

  //     return()=>{
  //       socket.off("runningData");
  //     }
  //   }, [socket]);
  


  useEffect(()=>{
    if(systemData){
      setResponseValues(systemData);

    }
  },[systemData]);
  const getStatusColor = (isActive) => (isActive ? "green" : "red");

  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4" sx={{ fontWeight: "bold", marginBottom: 1 ,fontFamily: "'Times New Roman', serif"}}>
        System Data                                       
      </Typography>
      


<Typography variant="h6" sx={{ fontWeight: 'bold', marginBottom: 1, marginLeft: 0, marginTop: 1, backgroundColor: "",fontFamily: "'Times New Roman', serif" }}>
   {responseValues.systemData.time ? (
    new Date(responseValues.systemData.time).toLocaleString('en-US', {
      weekday: 'short', 
      year: 'numeric',  
      month: '2-digit', 
      day: '2-digit',   
      hour: '2-digit',  
      minute: '2-digit',
      hour12: true      
    }).replace(',', '') 
  ) : 'Loading...'}
</Typography>

      <Grid container spacing={4}>
        {/* First Row with 3 Boxes (Time, Date, System Parameters) */}
        {/* <Grid item xs={12} sm={6} md={4}>
          <Card
            sx={{
              boxShadow: 3,
              padding: 2,
              borderRadius: 3,Sync Signal Status: Sync Signal Status: 
              backgroundColor: "#e3f2fd",
              height: "100%",
            }}
          >
            <Typography
              variant="h5"
              sx={{ fontWeight: "bold", marginBottom: 2, color: "#1e88e5" }}
            >
              Time
            </Typography>
            <Divider />
            <CardContent>
              <Typography variant="body1">
                <strong>Milliseconds:</strong>
              </Typography>
              <Typography variant="body1">
                <strong>Seconds:</strong>
              </Typography>
              <Typography variant="body1">
                <strong>Minutes:</strong>
              </Typography>
              <Typography variant="body1">
                <strong>Hours:</strong>
              </Typography>
            </CardContent>
          </Card>
        </Grid> */}
{/* 
        <Grid item xs={12} sm={6} md={4}>
          <Card
            sx={{
              boxShadow: 3,
              padding: 2,
              borderRadius: 3,
              backgroundColor: "#ffebee",
              height: "100%",
            }}
          >
            <Typography
              variant="h5"
              sx={{ fontWeight: "bold", marginBottom: 2, color: "#e57373" }}
            >
              Date
            </Typography>
            <Divider />
            <CardContent>
              <Typography variant="body1">
                <strong>Day:</strong>
              </Typography>
              <Typography variant="body1">
                <strong>Month:</strong>
              </Typography>
              <Typography variant="body1">
                <strong>Year:</strong>
              </Typography>
            </CardContent>
          </Card>
        </Grid> */}



<Grid container item xs={12} spacing={4}>
          {/* Signal Status & Counts */}
          <Grid item xs={12} sm={6} md={4}>
            <Card
              sx={{
                boxShadow: 3,
                padding: 2,
                borderRadius: 3,
                backgroundColor: "#fff3e0",
                height: "100%",
              }}
            >
              <Typography
                variant="h5"
                sx={{ fontWeight: "bold", marginBottom: 2, color: "#ff9800",fontFamily: "'Times New Roman', serif" }}
              >
                Signal Status & Counts
              </Typography>
              <Divider />
              <CardContent>
                <Typography variant="body1" fontFamily= "'Times New Roman', serif">
                  <strong>Azimuth Dwell Signal Last Cycle Count : {responseValues?.systemData?.azimuthDwellSignalLastCycleCount} </strong>
                 
                </Typography>
                <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                  <strong><br></br>
                    Azimuth Dwell Signal Running Cycle Count    :{responseValues?.systemData?.azimuthDwellSignalRunningCycleCount}</strong>
                </Typography>
                <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                  <strong><br></br>Elevation Dwell Signal Last Cycle Count    : {responseValues?.systemData?.elevationDwellSignalLastCycleCount }</strong>
                </Typography>
                <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                  <strong><br></br>Elevation Dwell Signal Running Cycle Count    : {responseValues?.systemData?.elevationDwellSignalRunningCycleCount}</strong>
                </Typography>
              </CardContent>
            </Card>
          </Grid>

          {/* Power Supply Status */}

          {/* System EMM Status */}
          <Grid item xs={12} sm={6} md={4}>
            <Card
              sx={{
                boxShadow: 3,
                padding: 2,
                borderRadius: 3,
                backgroundColor: "#e8f5e9",
                height: "100%",
              }}
            >
              <Typography
                variant="h5"
                sx={{ fontWeight: "bold", marginBottom: 2, color: "#43a047",fontFamily: "'Times New Roman', serif" }}
              >
                System EMM Status
              </Typography>
              <Divider />
              <CardContent>
                <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
                  {Object.keys(responseValues?.systemData?.emmStatus).map((key) => (
                    <div
                      key={key}
                      style={{ display: "flex", alignItems: "center" }}
                    >
                      <Typography variant="body1" sx={{ marginRight: 1,fontFamily: "'Times New Roman', serif" }}>
                        <strong>
                          {key
                            .replace(/([A-Z])/g, " $1")
                            .replace(/^./, (str) => str.toUpperCase())}
                          :
                        </strong>
                      </Typography>
                      <CircleIcon
                        sx={{
                          fontSize: 12,
                          color: getStatusColor(responseValues?.systemData?.emmStatus[key]),
                        }}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </Grid>

          {/* Operation Parameters */}
          <Grid item xs={12} sm={6} md={4}>
          <Card
            sx={{
              boxShadow: 3,
              padding: 2,
              borderRadius: 3,
              backgroundColor: "#e8f5e9",
              height: "100%",
            }}
          >
            <Typography
              variant="h5"
              sx={{ fontWeight: "bold", marginBottom: 2, color: "#43a047",fontFamily: "'Times New Roman', serif" }}
            >
              Operation Parameters
            </Typography>
            <Divider />
            <CardContent>
              <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
                {Object.keys(responseValues?.systemData?.operationParameters).map((key) => (
                  <div key={key} style={{ display: "flex", alignItems: "center" }}>
                    <Typography variant="body1" sx={{ marginRight: 1,fontFamily: "'Times New Roman', serif" }}>
                      <strong>
                        {key
                          .replace(/([A-Z])/g, " $1")
                          .replace(/^./, (str) => str.toUpperCase())}
                        :
                      </strong>
                    </Typography>
                    <CircleIcon
                      sx={{
                        fontSize: 12,
                        color: getStatusColor(responseValues?.systemData?.operationParameters[key]),
                      }}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </Grid>

          {/* System Sync Signal Status */}
          <Grid item xs={12} sm={6} md={4}>
            <Card
              sx={{
                boxShadow: 3,
                padding: 2,
                borderRadius: 3,
                backgroundColor: "#ffebee",
                height: "100%",
              }}
            >
              <Typography
                variant="h5"
                sx={{ fontWeight: "bold", marginBottom: 2, color: "#e57373",fontFamily: "'Times New Roman', serif" }}
              >
                System Sync Signal Status
              </Typography>
              <Divider />
              <CardContent>
                <Typography variant="body1" fontFamily= "'Times New Roman', serif">
                  <strong>Sync Signal Status:  { <CircleIcon
                      sx={{
                        fontSize: 12,
                        
                        color: getStatusColor(responseValues?.systemData?.syncSignalsStatus),
                      }}
                    />} </strong>
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <Card
              sx={{
                boxShadow: 3,
                padding: 2,
                borderRadius: 3,
                backgroundColor: "#f1f8e9",
                height: "100%",
              }}
            >
              <Typography
                variant="h5"
                sx={{ fontWeight: "bold", marginBottom: 2, color: "#388e3c",fontFamily: "'Times New Roman', serif" }}
              >
                Power Supply Status
              </Typography>
              <Divider />
              <CardContent>
                <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                  <strong>Servo Panel Income Power Supply Status:   {
                     <CircleIcon
                     sx={{
                       fontSize: 12,
                       color: getStatusColor(responseValues?.systemData?.servoPanelIncomePowerSupplyStatus),
                     }}
                   />}</strong>
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <Card
            sx={{
              boxShadow: 3,
              padding: 2,
              borderRadius: 3,
              backgroundColor: "#e8f5e9",
              height: "100%",
            }}
          >
            <Typography
              variant="h5"
              sx={{ fontWeight: "bold", marginBottom: 2, color: "#43a047",fontFamily: "'Times New Roman', serif" }}
            >
              System Parameters
            </Typography>
            <Divider />
            <CardContent>
              <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                <strong>Operation Mode: {
                  responseValues?.systemData?.operationMode !== undefined
                    ? ({
                      0x00: "Standby",
                      0x01: "Manual",
                      0x02: "Designate",
                      0x03: "Volume Scan",
                      0x04: "Azimuth Sector Scan",
                      0x05: "Elevation Sector Scan/RHI",
                      0x06: "Command Designate",
                      0x07: "Calibration Mode",
                      0x08: "Maintenance Mode"
                    }[responseValues.systemData.operationMode] || "Unknown Mode")
                    : "N/A"
                }</strong>

              </Typography>
              <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                <strong>Scan Type: {responseValues?.systemData?.scanType!==undefined?({
                  0x00: "Not Applicable",
                  0x01: "Single Scan",
                  0x02: "Multiple Scan"
                }[responseValues?.systemData?.scanType]|| "Unknown Type"):"N/A"}</strong>
              </Typography>
              <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                <strong>Running Elevation Scan No:  { responseValues?.systemData?.runningElevationScanNo}</strong>
              </Typography>
              <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                <strong>Running Azimuth Scan No:{responseValues?.systemData?.runningAzimuthScanNo} </strong>
              </Typography>
              <Typography variant="body1"fontFamily= "'Times New Roman', serif">
                <strong>Data Ready:   {
                //    <CircleIcon
                //    sx={{
                //      fontSize: 12,
                //      color: getStatusColor(responseValues?.systemData?.dataReady),
                //    }}
                //  />

                responseValues?.systemData?.dataReady===true?"Yes":"No"
              }</strong>
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Second Row with remaining boxes */}
        
      </Grid>
    </div>
  );
};

export default SystemData;
