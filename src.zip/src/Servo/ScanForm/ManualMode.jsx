import React from 'react'

const ManualMode = () => {
  return (
    <div>
      
    </div>
  )
}

export default ManualMode
