// import React, { useState } from "react";
// import { Select, MenuItem, FormControl, InputLabel } from "@mui/material"; // Import necessary components

// import {
//   Box,
//   Typography,
//   TextField,
//   Button,
//   Tooltip,
//   Snackbar,
//   Alert,
// } from "@mui/material";
// import { Socket } from "socket.io-client";
// import Slide from '@mui/material/Slide';
// import WarningAmberIcon from '@mui/icons-material/WarningAmber';

// const AlongWindRHI = ({ onSubmit, ackMessage, ackOpen, onAckClose, socket }) => {
//   const [elevationStartAngle, setStartAngle] = useState();
//   const [elevationEndAngle , setStopAngle] = useState();
//   const [elevationSpeed, setElevationSpeed] = useState();
//   const [windAngleDetection, setWindAngleDetection] = useState();
//   const [numElevationSteps, setNumElevationSteps] = useState();
//   const [buzzerBypassChecked, setBuzzerBypassChecked] = useState(false);
//   const [backTrackingChecked, setBackTrackingChecked] = useState(false);
//   const [warningOpen, setWarningOpen] = useState(false);
//   const [warningMessage, setWarningMessage] = useState("");

//   const [remoteWindAngle, setRemoteWindAngle] = useState("");

//   const showWarning = (message) => {
//     setWarningMessage(message);
//     setWarningOpen(true);
//   };

//   const handleWindAngleDetectionChange = (event) => {
//     setWindAngleDetection(event.target.value);
//   };

//   const handleInputChange = (setter, value, min, max, message) => {
//     const numericValue = parseInt(value, 10);
//     if (numericValue < min || numericValue > max || isNaN(numericValue)) {
//       showWarning(message);
//       setter(min); // Set to the minimum if invalid
//     } else {
//       setter(numericValue)
//     }
//   };

//   const handleSubmit = () => {
//     const formData = {
//       scanType: "alongwind",
//       elevationStartAngle,
//       elevationEndAngle,
//       elevationSpeed,
//       windAngleDetection,
//       buzzerBypass: buzzerBypassChecked,
//       backTracking: backTrackingChecked,
//       remoteWindAngle,
//     };

//     socket.emit("crossAlongWindRHI", formData);
//   };

//   const handleWarningClose = () => {
//     setWarningOpen(false);
//   };

//   return (
//     <Box
//       sx={{
//         backgroundColor: "#1a1a1a",
//         color: "#fff",
//         padding: 4,
//         borderRadius: 2,
//         maxWidth: 600,
//         margin: "0 auto",
//         boxShadow: "0 4px 10px rgba(0, 0, 0, 0.5)",
//       }}
//     >
//       <Typography variant="h5" gutterBottom></Typography>

//       {/* Elevation Start and Stop Angle */}
//       <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
//         <Box sx={{ flex: 1 }}>
//           <Typography variant="h5" gutterBottom>
//             Elevation Start Angle:
//           </Typography>
//           <TextField
//   type="number"
//   value={elevationStartAngle}
//   onChange={(e) => {
//     const value = e.target.value;
//     // Ensure the value matches the regex: a number with up to two decimal places
//     if (/^\d*\.?\d{0,2}$/.test(value) || value === '') {
//       setStartAngle(value);  
//     }
//   }}
//   fullWidth
//   inputProps={{
//     min: 0,
//     max: 180,
//     step: "0.01",
//   }}
//   sx={{
//     input: { color: "white" },
//     "& .MuiOutlinedInput-root fieldset": {
//       borderColor: "#00bcd4",
//     },
//     "&:hover .MuiOutlinedInput-root fieldset": {
//       borderColor: "#00bcd4",
//     },
//   }}
// />

//           <Typography variant="body2" sx={{ textAlign: "right" }}>
//             Range: 0° - 180°
//           </Typography>
//         </Box>

//         <Box sx={{ flex: 1 }}>
//           <Typography variant="h5" gutterBottom>
//             Elevation Stop Angle:
//           </Typography>
//           <TextField
//             type="number"
//             value={elevationEndAngle }
//             onChange={(e) =>
//               handleInputChange(
//                 setStopAngle,
//                 e.target.value,
//                 "",
//                 180,
//                 "Stop angle must be between 0° and 180°."
//               )
//             }
//             fullWidth
//             inputProps={{ min: 0, max: 180 }}
//             sx={{
//               input: { color: "white" },
//               "& .MuiOutlinedInput-root fieldset": {
//                 borderColor: "#00bcd4",
//               },
//               "&:hover .MuiOutlinedInput-root fieldset": {
//                 borderColor: "#00bcd4",
//               },
//             }}
//           />
//           <Typography variant="body2" sx={{ textAlign: "right" }}>
//             Range: 0° - 180°
//           </Typography>
//         </Box>
//       </Box>

//       {/* Elevation Speed */}
//       <Box sx={{ marginBottom: 3 }}>
//         <Typography variant="h5" gutterBottom>
//           Elevation Speed:
//         </Typography>
//         <TextField
//           type="number"
//           value={elevationSpeed}
//           onChange={(e) =>
//             handleInputChange(
//               setElevationSpeed,
//               e.target.value,
//               "",
//               1.5,
//               "Elevation speed must be between 0 and 1.5"
//             )
//           }
//           fullWidth
//           inputProps={{ min: 0, max: 1.5 }}
//           sx={{
//             input: { color: "white" },
//             "& .MuiOutlinedInput-root fieldset": {
//               borderColor: "#00bcd4",
//             },
//             "&:hover .MuiOutlinedInput-root fieldset": {
//               borderColor: "#00bcd4",
//             },
//           }}
//         />
//         <Typography variant="body2" sx={{ textAlign: "right" }}>
//           Range: 0 - 1.5
//         </Typography>
//       </Box>

//       {/* Remote Wind Angle */}
//       <Box sx={{ marginBottom: 3 }}>
//         <Typography variant="h5" gutterBottom>
//           Remote Wind Angle:
//         </Typography>
//         <TextField
//           type="number"
//           value={remoteWindAngle}
//           onChange={(e) =>
//             handleInputChange(
//               setRemoteWindAngle,
//               e.target.value,
//               "",
//               360,
//               "Wind angle must be between 0° and 360°."
//             )
//           }
//           fullWidth
//           inputProps={{ min: 0, max: 360 }}
//           sx={{
//             input: { color: "white" },
//             "& .MuiOutlinedInput-root fieldset": {
//               borderColor: "#00bcd4",
//             },
//             "&:hover .MuiOutlinedInput-root fieldset": {
//               borderColor: "#00bcd4",
//             },
//           }}
//         />
//         <Typography variant="body2" sx={{ textAlign: "right" }}>
//           Range: 0° - 360°
//         </Typography>
//       </Box>

//       <Box sx={{ flex: 1, marginBottom: 3, marginTop: 3 }}>
//         <Tooltip title="Select wind angle detection method" arrow>
//           <Typography variant="h5" gutterBottom>
//             Wind Angle Detection:
//           </Typography>
//         </Tooltip>
//         <FormControl fullWidth>
//           <Select
//             value={windAngleDetection}
//             onChange={handleWindAngleDetectionChange}
//             displayEmpty
//             renderValue={(selected) => {
//               if (!selected) {
//                 return "Select a method"; // Placeholder text
//               }
//               return selected;
//             }}
//             sx={{
//               color: "white",
//               "& .MuiOutlinedInput-notchedOutline": {
//                 borderColor: "#00bcd4",
//               },
//               "&:hover .MuiOutlinedInput-notchedOutline": {
//                 borderColor: "#00bcd4",
//               },
//             }}
//           >
//             <MenuItem value="remote">Remote</MenuItem>
//             <MenuItem value="servo">Servo</MenuItem>
//           </Select>
//         </FormControl>
//       </Box>

//       {/* Number of Elevation Steps */}
//       <Box sx={{ display: "flex", alignItems: "center", marginBottom: 3 }}>
//         <Typography variant="h5" sx={{ marginRight: 2, fontWeight: "bold" }}>
//           Number of Elevation Steps:
//         </Typography>
//         <Typography variant="h6" sx={{ color: "#00bcd4", fontWeight: "bold" }}>
//           70
//         </Typography>
//       </Box>

//       {/* Buzzer By-pass and Back Tracking */}
//       <Box sx={{ display: "flex", justifyContent: "space-between", gap: 2 }}>
//       <Button
//     variant={buzzerBypassChecked ? "contained" : "outlined"}
//     onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
//     sx={{
//       backgroundColor: buzzerBypassChecked ? "#00bcd4" : "transparent",
//       color: buzzerBypassChecked ? "#fff" : "#00bcd4",
//       "&:hover": {
//         backgroundColor: buzzerBypassChecked ? "#0097a7" : "#00bcd4",
//         color: "#fff",
//       },
//       flex: 1,
//       display: "block", // Ensures the content wraps
//        minWidth: "200px"
//     }}
//   >
//     Azimuth Axis
//     <Typography variant="body2" sx={{ textAlign: "center", marginTop: 1 }}>
//       {buzzerBypassChecked ? "Enabled" : "Disabled"}
//     </Typography>
//   </Button>

//   <Button
//     variant={backTrackingChecked ? "contained" : "outlined"}
//     onClick={() => setBackTrackingChecked(!backTrackingChecked)}
//     sx={{
//       backgroundColor: backTrackingChecked ? "#00bcd4" : "transparent",
//       color: backTrackingChecked ? "#fff" : "#00bcd4",
//       "&:hover": {
//         backgroundColor: backTrackingChecked ? "#0097a7" : "#00bcd4",
//         color: "#fff",
//       },
//       flex: 1,
//       display: "block", // Ensures the content wraps
//        minWidth: "200px"
//     }}
//   >
//     Elevation Axis
//     <Typography variant="body2" sx={{ textAlign: "center", marginTop: 1 }}>
//       {backTrackingChecked ? "Enabled" : "Disabled"}
//     </Typography>
//   </Button>

//       </Box>

//       {/* Submit Button */}
//       <Box
//         sx={{
//           display: "flex",
//           justifyContent: "space-between",
//           gap: 2,
//           marginTop: 2,
//         }}
//       >
//         <Button
//           variant="contained"
//           onClick={handleSubmit}
//           sx={{
//             backgroundColor: "#00bcd4",
//             "&:hover": {
//               backgroundColor: "#0097a7",
//             },
//             flex: 1, // Adjusts width proportionally
//           }}
//         >
//           OK
//         </Button>
//         <Button
//           variant="contained"
//           onClick={handleSubmit}
//           sx={{
//             backgroundColor: "#00bcd4",
//             "&:hover": {
//               backgroundColor: "#0097a7",
//             },
//             flex: 1, // Adjusts width proportionally
//           }}
//         >
//           Send
//         </Button>
//       </Box>

//       {/* Snackbar for Warnings */}
//       <Snackbar
//         open={warningOpen}
//         autoHideDuration={6000}
//         onClose={handleWarningClose}
//         anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
//         TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
//       >
//         <Alert
//           onClose={handleWarningClose}
//           severity="warning"
//           sx={{
//             width: '100%',
//             backgroundColor: '#ffcc00', // Vibrant yellow for visibility
//             color: '#1a1a1a', // Dark text for better contrast
//             fontWeight: 'bold',
//             fontSize: '1.2rem', // Larger font size
//             boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
//             border: '2px solid #ff9800', // Border for emphasis
//           }}
//           icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
//         >
//           {warningMessage}
//         </Alert>
//       </Snackbar>
//     </Box>
//   );
// };

// export default AlongWindRHI;




import React, { useState } from "react";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material"; // Import necessary components

import {
  Box,
  Typography,
  TextField,
  Button,
  Tooltip,
  Snackbar,
  Alert,
} from "@mui/material";
import { Socket } from "socket.io-client";
import Slide from '@mui/material/Slide';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const AlongWindRHI = ({ onSubmit, ackMessage, ackOpen, onAckClose, socket }) => {
  const [elevationStartAngle, setStartAngle] = useState();
  const [elevationEndAngle, setStopAngle] = useState();
  const [elevationSpeed, setElevationSpeed] = useState("");
  const [windAngleDetection, setWindAngleDetection] = useState();
  const [numElevationSteps, setNumElevationSteps] = useState();
  const [buzzerBypassChecked, setBuzzerBypassChecked] = useState(false);
  const [backTrackingChecked, setBackTrackingChecked] = useState(false);
  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");

  const [remoteWindAngle, setRemoteWindAngle] = useState("");

  const showWarning = (message) => {
    setWarningOpen(false); // Close it first
    setTimeout(() => {
      setWarningMessage(message);
      setWarningOpen(true); // Re-open after closing
    }, 100); // Small delay ensures state updates properly
  };

  const handleWindAngleDetectionChange = (event) => {
    setWindAngleDetection(event.target.value);
  };

  // const handleInputChange = (setter, value, min, max, message) => {


  //   const numericValue = parseInt(value, 10);
  //   if (numericValue < min || numericValue > max || isNaN(numericValue)) {
  //     showWarning(message);
  //     setter(min); // Set to the minimum if invalid
  //   } else {

  //     // if (/^\d*\.?\d{0,2}$/.test(value) || value === '') {
  //     //   setStartAngle(value);
  //     // }

  //     setter(numericValue);
  //   }
  // };



  // const handleInputChange = (setter, value, min, max, message) => {
  //   const numericValue = parseFloat(value); // Use parseFloat for decimal support
  
  //   // Validate if the value is out of range or not a number
  //   if (numericValue < min || numericValue > max || isNaN(numericValue)) {
  //     showWarning(message); // Show warning message
  //     setter(""); // Reset to an empty state or min value
  //   } else {
  //     // Optional: Allow only up to two decimal places
  //     if (/^\d*\.?\d{0,2}$/.test(value) || value === "") {
  //       setter(value); // Update state with the valid value
  //     }
  //   }
  // };

  const handleElevationStartChange = ( value) => {
        
    const formattedValue =parseFloat(parseFloat(value).toFixed(2));// Format to 2 decimal places
   
    if (value < 0.00 || value > 180.00) {
        showWarning('Elevation angle must be between 0° and 180.00°.');
        return;
    }


    setStartAngle(formattedValue);
};



  const handleElevationSpeedChange = (value) => {
    const numericValue = parseFloat(parseFloat(value).toFixed(2));
    if (value < 0 || value > 1.5) {
      showWarning('Elevation Speed must be between 0 and 1.5');
      return;
    }

    setElevationSpeed(numericValue);
  };



const handleRemoteWindAngleChange = (value) => {
  const values = parseFloat(parseFloat(value).toFixed(2));
  if (value < 0 || value > 360) {
    showWarning("Stop angle must be between 0° and 360°.");
  } else {
    setRemoteWindAngle(values);
  }
};


  const handleElevationStopChange = ( value) => {
        
    const formattedValues =parseFloat(parseFloat(value).toFixed(2));// Format to 2 decimal places

if (value < 0.00 || value > 180.00) {
  showWarning('Elevation angle must be between 0° and 180.00°.');
  return;
}


    setStopAngle(formattedValues);
};


  const handleSubmit = (event) => {
    if (event) event.preventDefault();

    if (elevationStartAngle === undefined || elevationStartAngle === "" || elevationStartAngle < 0 || elevationStartAngle > 360) {
      showWarning("Please enter all values"); 
        return;
    }

    if (elevationEndAngle === undefined || elevationEndAngle === "" || elevationEndAngle < 0 || elevationEndAngle > 360) {
      showWarning("Please enter all values"); 
        return;
    }

    if (elevationSpeed === undefined || elevationSpeed === "" || elevationSpeed <= 0) {
      showWarning("Please enter all values"); 
        return;
    }

    if (remoteWindAngle === undefined || remoteWindAngle === "" || remoteWindAngle < 0 || remoteWindAngle > 360) {
      showWarning("Please enter all values"); 
        return;
    }

    if (buzzerBypassChecked === undefined) {
      showWarning("Please enter all values"); 
        return;
    }

    if (backTrackingChecked === undefined) {
      showWarning("Please enter all values"); 
        return;
    }

    if (windAngleDetection === undefined) {
      showWarning("Please enter all values"); 
        return;
    }

    const formData = {
        scanType: "alongwind",
        elevationStartAngle,
        elevationEndAngle,
        elevationSpeed,
        windAngleDetection,
        buzzerBypass: buzzerBypassChecked,
        backTracking: backTrackingChecked,
        remoteWindAngle,
    };

    socket.emit("crossAlongWindRHI", formData);
    console.log("Form Data Submitted:", formData);
};


  const handleWarningClose = () => {
    setWarningOpen(false);
  };

  return (
    <Box
      sx={{
        backgroundColor: "#f7f7eb",
        color: "#fff",
        padding: 4,
        borderRadius: 2,
        maxWidth: 600,
        margin: "0 auto",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.5)",
      }}
    >
      <Typography variant="h5" gutterBottom></Typography>

      {/* Elevation Start and Stop Angle */}
      <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black"  fontWeight="bold" fontFamily= "'Times New Roman', serif"
          >
            Elevation Start Angle:
          </Typography>
          <TextField
            type="number"
            value={elevationStartAngle}
            onChange={(e) =>    
              handleElevationStartChange(
               
              e.target.value
           
            )
            }
            fullWidth
            inputProps={{
              min: 0,
              max: 180,
              step: "0.01",
            }}
            sx={{
              input: { color: "black", fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
          <Typography variant="body2" sx={{ textAlign: "right",color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"  }} >
            Range: 0° - 180°
          </Typography>
        </Box>

        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Elevation Stop Angle:
          </Typography>
          <TextField
            type="number"
            value={elevationEndAngle}
            onChange={(e) =>  
               handleElevationStopChange(
               
              e.target.value
           
            )}
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
          <Typography variant="body2" sx={{ textAlign: "right",color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"
}}>
            Range: 0° - 180°
          </Typography>
        </Box>
      </Box>

      {/* Elevation Speed */}
      <Box sx={{ marginBottom: 3 }}>
        <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
          Elevation Speed:
        </Typography>
        <TextField
          type="number"
          value={elevationSpeed}
          onChange={(e) =>
            handleElevationSpeedChange(
              e.target.value
             
           )
            
          }
          fullWidth
          inputProps={{ min: 0, max: 1.5 }}
          sx={{
            input: { color: "black" ,fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
            "& .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
            "&:hover .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right",color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif" }}>
          Range: 0 - 1.5
        </Typography>
      </Box>

      {/* Remote Wind Angle */}
      <Box sx={{ marginBottom: 3 }}>
        <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
          Remote Wind Angle:
        </Typography>
        <TextField
          type="number"
          value={remoteWindAngle}
          onChange={(e) =>handleRemoteWindAngleChange(
           
            e.target.value
            
          )
          }
          fullWidth
          inputProps={{ min: 0, max: 360 }}
          sx={{
            input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
            "& .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
            "&:hover .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          Range: 0° - 360°
        </Typography>
      </Box>

      <Box sx={{ flex: 1, marginBottom: 3, marginTop: 3 }}>
        <Tooltip title="Select wind angle detection method" arrow>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Wind Angle Detection:
          </Typography>
        </Tooltip>
        <FormControl fullWidth>
          <Select
            value={windAngleDetection}
            onChange={handleWindAngleDetectionChange}
            displayEmpty
            renderValue={(selected) => {
              if (!selected) {
                return "Select a Method"; // Placeholder text
              }
              return selected;
            }}
            sx={{
              color: "black",
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-notchedOutline": {
                borderColor: "#00bcd4",
              },
              fontWeight:"bold"
              ,fontFamily: "'Times New Roman', serif"
            }}
          >
            <MenuItem value="Remote" sx={{fontFamily:"'Times New Roman', serif"}}>Remote</MenuItem>
            <MenuItem value="Servo" sx={{fontFamily:"'Times New Roman', serif"}}>Servo</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Number of Elevation Steps */}
      <Box sx={{ display: "flex", alignItems: "center", marginBottom: 3 }}>
        <Typography variant="h5" sx={{ marginRight: 2, fontWeight: "bold",color: "black", fontFamily: "'Times New Roman', serif"}}>
          Number of Elevation Steps:
        </Typography>
        <Typography variant="h6" sx={{ color: "#00bcd4", fontWeight: "bold" }}>
          70
        </Typography>
      </Box>

      {/* Buzzer By-pass and Back Tracking */}
      <Box sx={{ display: "flex", justifyContent: "space-between", gap: 2 }}>
        <Button
          variant={buzzerBypassChecked ? "contained" : "outlined"}
          onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
          sx={{
            backgroundColor: buzzerBypassChecked ? "#00bcd4" : "transparent",
            color: buzzerBypassChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: buzzerBypassChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            ,fontFamily: "'Times New Roman', serif"
          }}
        >
          Azimuth Axis
          <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 ,fontFamily: "'Times New Roman', serif"}}>
            {buzzerBypassChecked ? "Enabled" : "Disabled"}
          </Typography>
        </Button>

        <Button
          variant={backTrackingChecked ? "contained" : "outlined"}
          onClick={() => setBackTrackingChecked(!backTrackingChecked)}
          sx={{
            backgroundColor: backTrackingChecked ? "#00bcd4" : "transparent",
            color: backTrackingChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: backTrackingChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            ,fontFamily: "'Times New Roman', serif"
          }}
        >
          Elevation Axis
          <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1,fontFamily: "'Times New Roman', serif" }}>
            {backTrackingChecked ? "Enabled" : "Disabled"}
          </Typography>
        </Button>
      </Box>

      {/* Submit Button */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          gap: 2,
          marginTop: 2,
        }}
      >
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
            flex: 1 // Adjusts width proportionally
          ,fontFamily: "'Times New Roman', serif"
          }}
        >
          OK
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
            flex: 1 // Adjusts width proportionally
          ,fontFamily: "'Times New Roman', serif"
          }}
        >
          Send
        </Button>
      </Box>

      {/* Snackbar for Warnings */}
      <Snackbar
        open={warningOpen}
        autoHideDuration={6000}
        onClose={handleWarningClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
        TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
      >
        <Alert
          onClose={handleWarningClose}
          severity="warning"
          sx={{
            width: '100%',
            backgroundColor: '#ffcc00', // Vibrant yellow for visibility
            color: '#1a1a1a', // Dark text for better contrast
            fontWeight: 'bold',
            fontSize: '1.2rem', // Larger font size
            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
            border: '2px solid #ff9800', // Border for emphasis
          }}
          icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
        >
          {warningMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AlongWindRHI;
