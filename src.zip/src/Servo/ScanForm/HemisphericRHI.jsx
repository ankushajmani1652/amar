import React, { useState } from "react";
import {
  Button,
  Box,
  Typography,
  TextField,
  Slider,
  Tooltip,
  Snackbar,
  Alert,
} from "@mui/material";
import Slide from '@mui/material/Slide';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const HemisphericRHI = ({ onSubmit, ackMessage, ackOpen, onAckClose, socket }) => {
  const [startAngle, setStartAngle] = useState("");
  const [stopAngle, setStopAngle] = useState("");
  const [buzzerBypassChecked, setBuzzerBypassChecked] = useState(false);
  const [backTrackingChecked, setBackTrackingChecked] = useState(false);
  const [azimuthAngles, setAzimuthAngles] = useState("");
  const [azimuthScanSpeed, setAzimuthScanSpeed] = useState([]); // Azimuth scan speeds
  const [numAzimuth, setNumAzimuth] = useState(""); // Number of elevations
  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const [elevationSpeed, setElevationSpeed] = useState("");

  const showWarning = (message) => {
    setWarningOpen(false); // Close it first
    setTimeout(() => {
      setWarningMessage(message);
      setWarningOpen(true); // Re-open after closing
    }, 100); // Small delay ensures state updates properly
  };
  const handleStartAngleChange = (event) => {
    const value = parseFloat(parseFloat(event.target.value).toFixed(2));
    if (value < 0 || value > 180) {
      showWarning("Start angle must be between 0° and 180°.");
    } else {
      setStartAngle(value);
    }
  };

  const handleStopAngleChange = (event) => {
    const value = parseFloat(parseFloat(event.target.value).toFixed(2));
    if (value < 0 || value > 180) {
      showWarning("Stop angle must be between 0° and 180°.");
    } else {
      setStopAngle(value);
    }
  };


  const handleAzimuthChange = (index, value) => {
    const formattedValue = parseFloat(parseFloat(value).toFixed(2));
    const newAngles = [...azimuthAngles];


    if (value < 0 || value > 360) {
      showWarning('Elevation angle must be between 0° and 360°.');
      return;
    }

    newAngles[index] = value < 360 ? parseFloat(formattedValue) : "";

    setAzimuthAngles(newAngles);

    // Check if the value is within the valid range (0 - 360)
    // if (numericValue >= 0 && numericValue < 360) {
    //   const newAngles = [...azimuthAngles];
    //   newAngles[index] = numericValue; // Update the specific angle
    //   setAzimuthAngles(newAngles);
    // } else {
    //   // If value is out of range, show a warning and reset the value
    //   showWarning("Azimuth Angle must be between 0° and 360°.");
    //   const newAngles = [...azimuthAngles];
    //   newAngles[index] = ""; 
    //   setAzimuthAngles(newAngles);
    // }
  };

  const handleInputChange = (value) => {
    const numericValue = parseFloat(parseFloat(value).toFixed(2));
    if (value < 0 || value > 1.5) {
      showWarning('Elevation Speed must be between 0 and 1.5');
      return;
    }

    setElevationSpeed(numericValue);
  };


  //   const handleScanSpeedChange = (index, value) => {
  //     const newSpeeds = [...azimuthScanSpeed];
  //     newSpeeds[index] = value; // Update azimuth scan speed for each elevation
  //     setAzimuthScanSpeed(newSpeeds);
  //   };

  // const handleOverlapAngle = (event, newValue) => {
  //     setOverlapAngle(newValue);
  // };

  const handleNumAzimuthChange = (event) => {
    const num = parseInt(event.target.value, 10);
    if (isNaN(num) || num < 0 || num > 36) {
      showWarning("Number of elevations must be between 0 and 36.");
      setNumAzimuth(num < 0 || isNaN(num) ? "" : 36); // Clamp the value within range
    } else {
      setNumAzimuth(num);
      setAzimuthAngles(Array(num).fill(0)); // Initialize elevation angles to 0
    }
  };

  const handleSubmit = (event) => {
    if (event) event.preventDefault();

    let errors = [];

    if (startAngle === undefined || startAngle === "" || startAngle < 0 || startAngle > 360) {
      errors.push("Elevation Start Angle is required and must be between 0° and 360°.");
    }

    if (stopAngle === undefined || stopAngle === "" || stopAngle < 0 || stopAngle > 360) {
      errors.push("Elevation End Angle is required and must be between 0° and 360°.");
    }

    if (elevationSpeed === undefined || elevationSpeed === "" || elevationSpeed <= 0) {
      errors.push("Elevation Speed is required and must be a positive value.");
    }

    if (numAzimuth === undefined || numAzimuth === "" || numAzimuth <= 0) {
      errors.push("Number of Azimuth must be a positive value.");
    }

    if (!Array.isArray(azimuthAngles) || azimuthAngles.length !== numAzimuth) {
      errors.push("Azimuth Angles must be an array with the same length as the Number of Azimuth.");
    }

    if (buzzerBypassChecked === undefined) {
      errors.push("Buzzer Bypass must be true or false.");
    }

    if (backTrackingChecked === undefined) {
      errors.push("Back Tracking must be true or false.");
    }

    if (errors.length > 0) {
      showWarning("Please enter all values");
      return;
    }

    const formData = {
      elevationStartAngle: startAngle,
      elevationEndAngle: stopAngle,
      buzzerBypass: buzzerBypassChecked,
      backTracking: backTrackingChecked,
      elevationSpeed: elevationSpeed,
      noOfAzimuth: numAzimuth,
      azimuthAngles: azimuthAngles,
    };

    socket.emit("hemisphericScan", formData);
    console.log("Form Data Submitted:", formData);
  };


  const handleWarningClose = () => {
    setWarningOpen(false);
  };

  return (
    <Box
      sx={{
        backgroundColor: "#f7f7eb",
        color: "#fff",
        padding: 4,
        borderRadius: 2,
        maxWidth: 600,
        margin: "0 auto",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.5)",
      }}
    >
      <Typography variant="h5" gutterBottom>
        {/* Volume Scan */}
      </Typography>

      {/* Start Angle Slider */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          gap: 2, // Adds space between the fields
          marginBottom: 3,
        }}
      >
        {/* Azimuth Start Angle Input */}
        <Box sx={{ flex: 1 }}>
          <Tooltip title="Enter the starting angle for the scan" arrow>
            <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
              Elevation Start Angle:
            </Typography>
          </Tooltip>
          <TextField
            type="number"
            value={startAngle}
            onChange={handleStartAngleChange}
            fullWidth
            inputProps={{
              min: 0,
              max: 360,
            }}
            sx={{
              input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
              "& .MuiOutlinedInput-root": {
                "& fieldset": {
                  borderColor: "#00bcd4",
                },
                "&:hover fieldset": {
                  borderColor: "#00bcd4",
                },
              },
            }}
          />
          <Typography variant="body2" sx={{ textAlign: "right",color: "black",fontWeight:"bold" ,fontFamily: "'Times New Roman', serif"}}>
            Range: 0° - 180°
          </Typography>
        </Box>

        {/* Overlap Angle Input */}
        <Box sx={{ flex: 1 }}>
          <Tooltip title="Set the stopping angle for the scan" arrow>
            <Typography variant="h5" gutterBottom color= "black" fontWeight="bold"fontFamily= "'Times New Roman', serif">
              Elevation Stop Angle:
            </Typography>
          </Tooltip>
          <TextField
            type="number"
            value={stopAngle}
            onChange={handleStopAngleChange}
            fullWidth
            inputProps={{
              min: 0,
              max: 360,
            }}
            sx={{
              input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
              "& .MuiOutlinedInput-root": {
                "& fieldset": {
                  borderColor: "#00bcd4",
                },
                "&:hover fieldset": {
                  borderColor: "#00bcd4",
                },
              },
            }}
          />
          <Typography variant="body2" sx={{ textAlign: "right",color: "black" ,fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
            Range: 0° - 180°
          </Typography>
        </Box>
      </Box>
      {/* Buzzer By-pass and Back Tracking Buttons */}
      <Box
        sx={{
          marginBottom: 3,
          display: "flex",
          justifyContent: "space-between",
           gap: 2 
        }}
      >
        <Button
          variant={buzzerBypassChecked ? "contained" : "outlined"}
          onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
          sx={{
            backgroundColor: buzzerBypassChecked ? "#00bcd4" : "transparent",
            color: buzzerBypassChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: buzzerBypassChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            ,fontFamily: "'Times New Roman', serif"          }}
        >Buzzer By-pass:
                    <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1,fontFamily: "'Times New Roman', serif" }}>
          
          {buzzerBypassChecked
            ? " Enabled"
            : " Disabled"}
                      </Typography>
            
        </Button>
        <Button
          variant={backTrackingChecked ? "contained" : "outlined"}
          onClick={() => setBackTrackingChecked(!backTrackingChecked)}
          sx={{
            backgroundColor: backTrackingChecked ? "#00bcd4" : "transparent",
            color: backTrackingChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: backTrackingChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            ,fontFamily: "'Times New Roman', serif"          }}
        >Back Tracking:
                    <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 ,fontFamily: "'Times New Roman', serif"}}>
          
          {backTrackingChecked
            ? " Enabled"
            : " Disabled"}
                      </Typography>
            
        </Button>
      </Box>
      <Box sx={{ marginTop: 3 }}>
        <Tooltip title="Enter the elevation speed for the scan" arrow>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Elevation Speed:
          </Typography>
        </Tooltip>
        <TextField
          type="number"
          value={elevationSpeed}
          onChange={(e) => {
            handleInputChange(

              e.target.value

            )

          }
          }
          fullWidth
          inputProps={{
            min: "",
            max: 1.5,

          }}
          sx={{
            input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
            "& .MuiOutlinedInput-root": {
              "& fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover fieldset": {
                borderColor: "#00bcd4",
              },
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right",color: "black" ,fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          Range: 0 - 1.5
        </Typography>
      </Box>

      {/* Number of Azimuth Input */}
      <Box sx={{ marginBottom: 3 }}>
        <Tooltip title="Enter the number of azimuth angles" arrow>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Number of Azimuth:
          </Typography>
        </Tooltip>
        <TextField
          type="number"
          value={numAzimuth}
          onChange={handleNumAzimuthChange}
          fullWidth
          inputProps={{
            min: 0,
            max: 60, // Limit the number of elevation angles
          }}
          sx={{
            input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
            "& .MuiOutlinedInput-root": {
              "& fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover fieldset": {
                borderColor: "#00bcd4",
              },
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right",color: "black" ,fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          Range: 1 - 36
        </Typography>
      </Box>

      {/* Azimuth Angles */}
      {Array.from({ length: numAzimuth }).map((_, index) => (
        <Box
          key={index}
          sx={{
            marginBottom: 3,
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          {/* Azimuth Angle Input */}
          <Box sx={{ width: "48%" }}>
            <Tooltip title={`Set azimuth angle ${index + 1}`} arrow>
              <Typography variant="h5" gutterBottom fontWeight="bold" color="black" fontFamily= "'Times New Roman', serif">
                Azimuth Angle {index + 1}{" "}
                {/*<strong>{elevationAngles[index]}°</strong>*/}
              </Typography>
            </Tooltip>
            <TextField
              value={azimuthAngles[index]}
              onChange={(event) =>
                handleAzimuthChange(index, event.target.value)
              }
              type="number"
              fullWidth
              inputProps={{
                min: 0,
                max: 60,
              }}
              sx={{
                input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#00bcd4",
                  },
                  "&:hover fieldset": {
                    borderColor: "#00bcd4",
                  },
                },
              }}
            />
          </Box>

          {/* Azimuth Scan Speed Input */}

        </Box>
      ))}

      {/* Submit Button */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          gap: 2,
          marginTop: 2,
        }}
      >
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
            flex: 1 // Adjusts width proportionally
            ,fontFamily: "'Times New Roman', serif" }}
        >
          OK
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
            flex: 1, // Adjusts width proportionally
            fontFamily: "'Times New Roman', serif"}}
        >
          Send
        </Button>
      </Box>

      {/* Snackbar for Acknowledgment */}
      <Snackbar
        open={warningOpen}
        autoHideDuration={6000}
        onClose={handleWarningClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
        TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
      >
        <Alert
          onClose={handleWarningClose}
          severity="warning"
          sx={{
            width: '100%',
            backgroundColor: '#ffcc00', // Vibrant yellow for visibility
            color: '#1a1a1a', // Dark text for better contrast
            fontWeight: 'bold',
            fontSize: '1.2rem', // Larger font size
            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
            border: '2px solid #ff9800', // Border for emphasis
          }}
          icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
        >
          {warningMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default HemisphericRHI;
