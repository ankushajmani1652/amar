import React from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  AppBar,
  Toolbar,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
} from '@mui/material';
import { styled } from '@mui/system';
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';

// Styled Components
const TitleText = styled(Typography)({
  fontSize: '6rem',
  fontWeight: 'bold',
  textAlign: 'left',
  color: '#f5dcba',
  textShadow: '4px 4px 6px rgba(0, 0, 0, 0.3), 0 0 25px rgba(5, 22, 36, 0.8)',
  letterSpacing: '2px',
  marginTop: '20px',
  zIndex: 2,
});

const RadarText = styled(Typography)({
  fontSize: '6rem',
  fontWeight: 'bold',
  textAlign: 'left',
  color: '#f5dcba',
  textShadow: '4px 4px 6px rgba(0, 0, 0, 0.3), 0 0 25px rgba(5, 22, 36, 0.8)',
  letterSpacing: '2px',
  marginTop: '-20px',
  marginLeft: '70px',
  zIndex: 2,
});

const DescriptionText = styled(Typography)(`
  font-size: 2rem;
  color: #f5dcba;
  font-weight: bold;
  text-align: left;
  margin-top: 20px;
  white-space: nowrap;
  overflow: hidden;
  width: 0;
  animation: typing 5s steps(50) 1s infinite;
`);

const typingKeyframes = `
  @keyframes typing {
    from { width: 0; }
    to { width: 100%; }
  }
`;

const cloudKeyframes = `
  @keyframes cloudMove {
    0% { transform: translateX(0); }
    100% { transform: translateX(-100%); }
  }
`;

const cloudAnimationStyles = {
  position: 'absolute',
  top: 0,
  left: 0,
  width: '100%',
  height: '100%',
  animation: 'cloudMove 60s linear infinite',
  zIndex: -1,
};

const BoxContainer = styled(Grid)({
  marginTop: '30px',
});

const BoxItem = styled(Paper)({
  padding: '30px',
  textAlign: 'center',
  borderRadius: '50% 50% 30% 30% / 40% 40% 60% 60%',
  background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.8), rgba(211, 211, 211, 0.6))',
  boxShadow: '0px 10px 20px rgba(0, 0, 0, 0.1)',
  transform: 'scale(1)',
  transition: 'transform 0.3s ease, box-shadow 0.3s ease',
  height: '300px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  flexDirection: 'column',
  '&:hover': {
    transform: 'scale(1.05)',
    boxShadow: '0px 15px 30px rgba(0, 0, 0, 0.15)',
  },
});

const HeadingText = styled(Typography)({
  fontSize: '2rem',
  fontWeight: 'bold',
  color: '#3a5a99',
  marginBottom: '15px',
  textTransform: 'uppercase',
});

const SubText = styled(Typography)({
  fontSize: '1.2rem',
  color: '#37574f',
  marginBottom: '10px',
  lineHeight: 1.6,
  fontFamily: 'Arial, sans-serif',
});

const General = () => {
  const [powerOn, setPowerOn] = React.useState(false);
  const [confirmDialogOpen, setConfirmDialogOpen] = React.useState(false);

  const handlePowerToggle = () => {
    if (powerOn) {
      setConfirmDialogOpen(true); // Ask before turning off
    } else {
      setPowerOn(true); // Turn on directly
    }
  };

  const confirmPowerOff = () => {
    setPowerOn(false);
    setConfirmDialogOpen(false);
  };

  const cancelPowerOff = () => {
    setConfirmDialogOpen(false);
  };

  return (
    <Box
      sx={{
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        background: 'linear-gradient(135deg,rgb(31, 79, 150),rgb(156, 201, 240))',
      }}
    >
      <AppBar position="static" sx={{ background: 'linear-gradient(135deg,rgb(156, 201, 240),rgb(31, 79, 150))' }}>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Cloud Radar
          </Typography>

          {/* Power Button */}
          <Box display="flex" alignItems="center" gap={1}>
            <IconButton
              onClick={handlePowerToggle}
              sx={{
                color: '#fff',
                backgroundColor: powerOn ? '#4caf50' : '#f44336',
                borderRadius: '20px',
                padding: '8px 16px',
                transition: 'all 0.3s ease-in-out',
                fontWeight: 'bold',
                '&:hover': {
                  backgroundColor: powerOn ? '#388e3c' : '#d32f2f',
                },
              }}
            >
              <PowerSettingsNewIcon sx={{ marginRight: 1 }} />
              <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                {powerOn ? 'ON' : 'OFF'}
              </Typography>
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>

      <style>{cloudKeyframes}</style>
      <style>{typingKeyframes}</style>

      <Box sx={cloudAnimationStyles} />

      <Box
        sx={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'left',
          alignItems: 'flex-start',
          position: 'relative',
          marginLeft: '40px',
        }}
      >
        <TitleText>Cloud</TitleText>
        <RadarText>RADAR</RadarText>
        <DescriptionText>
          A sophisticated system for real-time CLoud monitoring.
        </DescriptionText>
      </Box>

      <Box
        sx={{
          position: 'absolute',
          top: '30%',
          right: '80px',
          transform: 'translateY(-50%)',
        }}
      >
        <img
          src="/cloud21.png"
          alt="Logo"
          style={{ height: '400px', width: 'auto' }}
        />
      </Box>

      <Box sx={{ flex: 1 }}>
        <BoxContainer container spacing={3}>
          <Grid item xs={12} md={4}>
            <BoxItem elevation={3}>
              <HeadingText>Radar Information</HeadingText>
              <SubText>Radar Name: <strong></strong></SubText>
              <SubText>Radar Type: <strong></strong></SubText>
            </BoxItem>
          </Grid>

          <Grid item xs={12} md={4}>
            <BoxItem elevation={3}>
              <HeadingText>Radar Task</HeadingText>
              <SubText>Running Task: <strong></strong></SubText>
              <SubText>Scheduled Task: <strong></strong></SubText>
            </BoxItem>
          </Grid>

          <Grid item xs={12} md={4}>
            <BoxItem elevation={3}>
              <HeadingText>Radar Site</HeadingText>
              <SubText>Site Latitude: <strong></strong></SubText>
              <SubText>Site Longitude: <strong></strong></SubText>
              <SubText>Site MSL: <strong></strong></SubText>
              <SubText>Site ID: <strong></strong></SubText>
            </BoxItem>
          </Grid>
        </BoxContainer>
      </Box>

      {/* Power Off Confirmation Dialog */}
      <Dialog open={confirmDialogOpen} onClose={cancelPowerOff}>
        <DialogTitle>Confirm Power Off</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to power off the radar system?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={cancelPowerOff} color="primary">
            Cancel
          </Button>
          <Button onClick={confirmPowerOff} color="error" variant="contained">
            Power Off
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default General;
