import React, { useState, useEffect } from "react";
import { Box, Typography, Paper } from "@mui/material";


import { useSocket } from "../../SocketContext";
const SystemParameter = () => {
  // State to store data from server
  const [sytemParaneters, setSytemParaneters] = useState({});
  const [adminParameters, setadminParameters] = useState({});
  const [networkSettings, setNetworkSettings] = useState({});
  const [masterAdminParameters, setmasterAdminParameters] = useState({});
  const [currentTime, setCurrentTime] = useState({});


  const socket=useSocket();


  const [responseValues, setResponseValues] = useState({
    timeStamp:null,
    adminParameters: {
      azimuthEncoderBias: 0,
      elevationEncoderBias: 0,
      azimuthSystemAccRate: 0,
      azimuthSystemDecRate: 0,
      azimuthSystemMaxSpeed: 0,
      elevationSystemAccRate: 0,
      elevationSystemDecRate: 0,
      elevationSystemMaxSpeed: 0,
      elevationMaxUpAngle: 0,
      elevationMaxDownAngle: 0,
      elevationUpSoftLimit: 0,
      elevationDownSoftLimit: 0,
      localModeDataInterval:0
    },
    masterAdminParameters: {
      azimuthMaxAcceleration: 0,
      azimuthMaxDeceleration: 0,
      azimuthMaxSpeed: 0,
      elevationMaxAcceleration: 0,
      elevationMaxDeceleration: 0,
      elevationMaxSpeed: 0,
    },
    networkSettings: {
      ipAddressServoControlSystem: "",
      ipAddressRadarController: "",
      ipAddressHMI: "",
      udpPortBroadcast: 0,
      udpPortDedicated: 0,
    },
  });
  


  useEffect(() => {
    socket.on("readSystemParameters", (data) => {
      
      setResponseValues(data);
    });
  
    return () => {
      socket.off("readSystemParameters"); // Cleanup to prevent memory leaks
    };
  }, []); // Runs only once when the component mounts
  
  // Use another useEffect to log the updated state
  
  
  // useEffect(() => {


 
    
  //   // Mock data fetch for demonstration (replace with actual server call)
  //   const fetchHealthData = async () => {
  //     // Replace these with actual API calls
  //     setSytemParaneters({
  //       timeMilliseconds: "",
  //       timeSeconds: "",
  //       timeMinutes: "",
  //       timeHours: "",
  //       dateDay: "",
  //       dateMonth: "",
  //       dateYear: "",
  //       systemEMMStatus: "",
  //       systemOperationParams: "",
  //       systemSyncSignalsStatus: "",
  //       powerSupplyStatus: "",
  //     });

  //     setadminParameters({
  //       azimuthEncoderBias: 0,
  //       elevationEncoderBias: 0,
  //       azimuthSystemAccRate: 0,
  //       azimuthSystemDecRate: 0,
  //       azimuthSystemMaxSpeed: 0,
  //       elevationSystemAccRate: 0,
  //       elevationSystemDecRate: 0,
  //       elevationSystemMaxSpeed: 0,
  //       elevationMaxUpAngle: 0,
  //       elevationMaxDownAngle: 0,
  //       elevationUpSoftLimit: 0,
  //       elevationDownSoftLimit: 0,
  //     });

  //     setmasterAdminParameters({
  //       azimuthMaxAcceleration: 0,
  //       azimuthMaxDeceleration: 0,
  //       azimuthMaxSpeed: 0,
  //       elevationMaxAcceleration: 0,
  //       elevationMaxDeceleration: 0,
  //       elevationMaxSpeed: 0,
  //     });

  //     setNetworkSettings({
  //       auxPower: "",
  //       busVoltage: "",
  //       heatSinkTemperature: "",
  //       brakeCurrent: "",
  //       driveError: "",
  //     });
  //   };

  //   fetchHealthData();
  // }, []);

  const Adminparameters = [
    {
      name: "Azimuth Encoder Bias",
      value: responseValues?.adminParameters?.azimuthEncoderBias || "Loading...",

    },
    {
      name: "Elevation Encoder Bias",
      value: responseValues?.adminParameters?.elevationEncoderBias || "Loading...",
    },
    {
      name: "Azimuth System Acc Rate",
      value: responseValues?.adminParameters?.azimuthSystemAccRate || "Loading...",
    },
    {
      name: "Azimuth System Dec Rate",
      value: responseValues?.adminParameters?.azimuthSystemDecRate || "Loading...",
    },
    {
      name: "Azimuth System Max Speed",
      value: responseValues?.adminParameters?.azimuthSystemMaxSpeed || "Loading...",
    },
    {
      name: "Elevation System Acc Rate",
      value: responseValues?.adminParameters?.elevationSystemAccRate || "Loading...",
    },
    {
      name: "Elevation System Dec Rate",
      value: responseValues?.adminParameters?.elevationSystemDecRate || "Loading...",
    },
    {
      name: "Elevation System Max Speed",
      value: responseValues?.adminParameters?.elevationSystemMaxSpeed || "Loading...",
    },
    {
      name: "Elevation Max Up Angle",
      value: responseValues?.adminParameters?.elevationMaxUpAngle || "Loading...",
    },
    {
      name: "Elevation Max Down Angle",
      value: responseValues?.adminParameters?.elevationMaxDownAngle || "Loading...",
    },
    {
      name: "Elevation Up Soft Limit",
      value: responseValues?.adminParameters?.elevationUpSoftLimit || "Loading...",
    },
    {
      name: "Elevation Down Soft Limit",
      value: responseValues?.adminParameters?.elevationDownSoftLimit || "Loading...",
    },
    {
      name: "Local Mode Data Interval",
      value: responseValues?.adminParameters?.localModeDataInterval || "Loading...",
    },
  ];

  const Elparameters = [
    {
      name: "Azimuth Max Acceleration",
      value: responseValues?.masterAdminParameters?.azimuthMaxAcceleration || "Loading...",
    },
    {
      name: "Azimuth Max Deceleration",
      value: responseValues?.masterAdminParameters?.azimuthMaxDeceleration || "Loading...",
    },
    {
      name: "Azimuth Max Speed",
      value: responseValues?.masterAdminParameters?.azimuthMaxSpeed || "Loading...",
    },
    {
      name: "Elevation Max Acceleration",
      value: responseValues?.masterAdminParameters?.elevationMaxAcceleration || "Loading...",
    },
    {
      name: "Elevation Max Deceleration",
      value: responseValues?.masterAdminParameters?.elevationMaxDeceleration || "Loading...",
    },
    {
      name: "Elevation Max Speed",
      value: responseValues?.masterAdminParameters?.elevationMaxSpeed || "Loading...",
    },
  ];

  const parameters = [
    {
      name: "IP Address of Servo Control System",
      value: responseValues?.networkSettings?.ipAddressServoControlSystem,
    },
    {
      name: "IP Address of Radar Controller",
      value: responseValues?.networkSettings?.ipAddressRadarController,
    },
    { name: "IP Address of HMI", value: responseValues?.networkSettings?.ipAddressHMI },
    { name: "UDP Port Broadcast", value: responseValues?.networkSettings?.udpPortBroadcast },
    { name: "UDP Port Dedicated", value: responseValues?.networkSettings?.udpPortDedicated },
  ];

  return (
    <Box display="flex" flexDirection="column" gap={1} p={0}>
      {/* Time and Date Section */}
      <Paper
        elevation={3}
        sx={{ p: 3, mb: 2, borderRadius: "12px", boxShadow: 3 }}
      >
        {/* Title Section */}
        <Typography
          variant="h4"
          sx={{
            fontWeight: "bold",
            textAlign: "center",
            marginBottom: "16px",
            color: "primary.main",
            fontFamily: "'Times New Roman', serif" 

          }}
        >
          System Parameters
        </Typography>

        {/* Time Section */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={2}
          flexDirection={{ xs: "column", sm: "row" }}
        >
          <Box display="flex" gap={3} flexWrap="wrap">
           
          <Typography variant="h6" sx={{ fontWeight: 'bold', marginBottom: 1, marginLeft: 1, marginTop: 1, backgroundColor: "",                    fontFamily: "'Times New Roman', serif" 
 }}>
 {responseValues.timeStamp? (
    new Date(responseValues.timeStamp).toLocaleString('en-US', {
      weekday: 'short', // Abbreviated day (e.g., 'Mon')
      year: 'numeric',  // Full year (e.g., '2025')
      month: '2-digit', // Two-digit month (e.g., '03')
      day: '2-digit',   // Two-digit day (e.g., '03')
      hour: '2-digit',  // Two-digit hour (e.g., '09')
      minute: '2-digit',// Two-digit minute (e.g., '52')
      hour12: true      // 12-hour format with AM/PM
    }).replace(',', '') // Remove comma from default format
  ) : 'Loading...'}
</Typography>



          </Box>
        </Box>

        {/* Date Section */}
       

        {/* Parameters Section */}
        <Box display="flex" justifyContent="flex-end" gap={3} flexWrap="wrap">
          {parameters.map((param, index) => (
            <Box
              key={index}
              sx={{
                display: "flex",
                flexDirection: "column", // Stack the name and value vertically
                justifyContent: "flex-start", // Align items to the start
                background: "rgba(255, 255, 255, 0.1)",
                borderRadius: "12px",
                padding: "12px 16px",
                boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                cursor: "pointer", // Indicate clickable area
                transition: "background-color 0.3s ease, transform 0.3s ease", // Smooth transition
                "&:hover": {
                  backgroundColor: "rgba(255, 255, 255, 0.2)", // Highlight on hover
                  transform: "scale(1.05)", // Subtle zoom effect
                },
              }}
            >
              <Typography
                variant="subtitle1"
                sx={{
                  // fontWeight: "bold",
                  textTransform: "uppercase",
                  color: "blue",
                  fontFamily: "'Times New Roman', serif" 
                }}
              >
                {param.name}
              </Typography>
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "medium",
                  color: "text.primary",
                  marginTop: "4px", // Add spacing between name and value
                  color: "green",
                  fontWeight: "bold",
                }}
              >
                {param.value}
              </Typography>
            </Box>
          ))}
        </Box>
      </Paper>


      {/* System Data - Horizontal Layout */}
      <Box
        display="flex"
        justifyContent="space-between"
        gap={3}
        marginTop="-10px"
      >
        {/* Azimuth Health Section */}
        <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
          <Typography
            variant="h4"
            sx={{
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: "3px",
              // color: theme.palette.text.primary,
              fontFamily: "'Times New Roman', serif" 

            }}
          >
            Admin Parameter
          </Typography>
          <Box sx={{ padding: "6px", borderRadius: "8px" }}>
            <Box display="flex" flexDirection="column" gap="13px">
              {Adminparameters.map((param, index) => (
                <Box
                  key={index}
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    background: "rgba(255, 255, 255, 0.1)",
                    borderRadius: "8px",
                    padding: "0px 6px",
                    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "rgba(255, 255, 255, 0.2)",
                    },
                  }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{ fontWeight: "bold", textTransform: "uppercase",                     fontFamily: "'Times New Roman', serif" 
                    }}
                  >
                    {param.name}
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: "medium", color:"green",fontWeight:"bold" }}>
                    {param.value}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>
        </Paper>

        <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
          <Typography
            variant="h4"
            sx={{
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: "6px",
              // color: theme.palette.text.primary,
              fontFamily: "'Times New Roman', serif" 

            }}
          >
            Master Admin Parameters
          </Typography>
          <Box sx={{ padding: "6px", borderRadius: "8px" }}>
            <Box display="flex" flexDirection="column" gap="22px">
              {Elparameters.map((param, index) => (
                <Box
                  key={index}
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    background: "rgba(255, 255, 255, 0.1)",
                    borderRadius: "8px",
                    padding: "1px 6px",
                    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "rgba(255, 255, 255, 0.2)",
                    },
                  }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{ fontWeight: "bold", textTransform: "uppercase",fontFamily: "'Times New Roman', serif" 
                    }}
                  >
                    {param.name}
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: "medium", color:"green", fontWeight:"bold" }}>
                    {param.value}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>
        </Paper>
      </Box>
    </Box>
  );
};

export default SystemParameter;
