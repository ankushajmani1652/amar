import React, { createContext, useState, useContext } from "react";
import Popup from "./Popup";

const PopupContext = createContext();

// PopupProvider component remains the same, it's exported as a named export
export const PopupProvider = ({ children }) => {
  const [popupContent, setPopupContent] = useState(null);

  const openPopup = (content) => setPopupContent(content);
  const closePopup = () => setPopupContent(null);

  return (
    <PopupContext.Provider value={{ popupContent, openPopup, closePopup }}>
      {children}
      {popupContent && <Popup open={true} onClose={closePopup} content={popupContent} />}
    </PopupContext.Provider>
  );
};

// `usePopup` can now be exported as default
const usePopup = () => useContext(PopupContext);

export default usePopup;
