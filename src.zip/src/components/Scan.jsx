import React from 'react'

export const Scan = () => {
    return (
        <Box m="20px">

            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="DASHBOARD" subtitle="" />
            </Box>
        </Box>
    )
}

