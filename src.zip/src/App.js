import { useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { CssBaseline, ThemeProvider } from "@mui/material";

import { ColorModeContext, useMode } from "./theme";
import { AuthProvider, useAuth } from "./UserRegistration/AuthContext";
import PrivateRoute from "./UserRegistration/PrivateRoute";

import Sidebar from "./sceans/global/Sidebar";
import Topbar from "./sceans/global/Topbar";
import LoginPage from "./UserRegistration/LoginPage";

import General from "./sceans/Dashboard/general";
import Index from "./sceans/Dashboard";
import Rf from "./RfReceiver/Rf";
import TaskCreationPage from "./sceans/global/SidebarComponents/TaskCreator";
import TaskSchedular from "./sceans/global/SidebarComponents/TaskSchedular";
import ServoDesktop from "./Servo/Components/ServoDashboard";
import VolumeScanForm from "./Servo/ScanForm/VolumeScan";
import AzimuthScanForm from "./Servo/ScanForm/AzimuthScan";
import BoundaryLayerRHI from "./Servo/ScanForm/BoundaryLayer";
import DesignationMode from "./Servo/ScanForm/DesignationMode";
import CrossWindRHI from "./Servo/ScanForm/CrossWindRHI";
import ElevationSectorScan from "./Servo/ScanForm/ElevationSectorScan";
import HemisphericRHI from "./Servo/ScanForm/HemisphericRHI";
import StowMode from "./Servo/ScanForm/StowMode";
import AlongWindRHI from "./Servo/ScanForm/AlongWindRHI";
import RadarHealthStatus from "./RadarCommunication/RadarHealth/RadarHealthStatus";
import Pbit from "./RadarCommunication/RadarHealth/Pbit";
import SunCalibration from "./RadarCommunication/Calibration/SunCalibration";
import SphareCalibration from "./RadarCommunication/Calibration/SphareCalibration";
import BoreSightCalibration from "./RadarCommunication/Calibration/BoreSightCalibration";
import DefaultParamerer from "./SystemConfiguration/DefaultParamerer";
import { PopupProvider } from "./components/PopupContext";

function AppContent() {
  const [powerStatus, setPowerStatus] = useState(false);
  const { user } = useAuth();
  const location = useLocation();

  const isLoginPage = location.pathname === "/login";
  const isAuthenticated = !!user;

  return (
    <div className="app">
      {/* Sidebar appears only when authenticated and not on login page */}
      {isAuthenticated && !isLoginPage && (
        <Sidebar powerStatus={powerStatus} setPowerStatus={setPowerStatus} />
      )}

      <main className="content">
        {/* Topbar appears only when authenticated and not on login page */}
        {isAuthenticated && !isLoginPage && <Topbar />}

        <Routes>
          <Route path="/" element={<LoginPage />} />

          <Route
            path="/general"
            element={
              <PrivateRoute allowedRoles={["superuser", "normaluser", "user"]}>
                <General />
              </PrivateRoute>
            }
          />

          <Route
            path="/RadarRunningData"
            element={
              <PrivateRoute allowedRoles={["superuser", "normaluser", "user"]}>
                <Index />
              </PrivateRoute>
            }
          />

          <Route
            path="/Rf"
            element={
              <PrivateRoute allowedRoles={["superuser"]}>
                <Rf />
              </PrivateRoute>
            }
          />

          <Route
            path="/Servo"
            element={
              <PrivateRoute allowedRoles={["superuser", "normaluser"]}>
                {powerStatus ? <ServoDesktop /> : <General />}
              </PrivateRoute>
            }
          />

          <Route
            path="/TaskCreator"
            element={
              <PrivateRoute allowedRoles={["superuser", "normaluser"]}>
                <TaskCreationPage />
              </PrivateRoute>
            }
          />

          <Route
            path="/TaskSchedular"
            element={
              <PrivateRoute allowedRoles={["superuser", "normaluser"]}>
                <TaskSchedular />
              </PrivateRoute>
            }
          />

          <Route path="/Volume_AzimuthScan" element={<VolumeScanForm />} />
          <Route path="/AzimuthScan" element={<AzimuthScanForm />} />
          <Route path="/BoundaryLayer" element={<BoundaryLayerRHI />} />
          <Route path="/DesignationMode" element={<DesignationMode />} />
          <Route path="/HemisphericRHI" element={<HemisphericRHI />} />
          <Route path="/StowMode" element={<StowMode />} />
          <Route path="/AlongWindRHI" element={<AlongWindRHI />} />
          <Route path="/CrossWindRHI" element={<CrossWindRHI />} />
          <Route path="/ElevationSectorScan" element={<ElevationSectorScan />} />
          <Route path="/RadarHealthStatus" element={<RadarHealthStatus />} />
          <Route path="/Pbit" element={<Pbit />} />
          <Route path="/SunCalibration" element={<SunCalibration />} />
          <Route path="/SphareCalibration" element={<SphareCalibration />} />
          <Route path="/BoreSightCalibration" element={<BoreSightCalibration />} />
          <Route path="/DefaultParamerer" element={<DefaultParamerer />} />
        </Routes>
      </main>
    </div>
  );
}

function App() {
  const [theme, colorMode] = useMode();

  return (
    <AuthProvider>
      <ColorModeContext.Provider value={colorMode}>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          <PopupProvider>
            <AppContent />
          </PopupProvider>
        </ThemeProvider>
      </ColorModeContext.Provider>
    </AuthProvider>
  );
}

export default App;
