// import React, { useState } from "react";
// import {
//     TextField,
//     Button,
//     Checkbox,
//     FormControlLabel,
//     Typography,
//     Container,
//     Box,
//     Grid,
//     Paper
// } from "@mui/material";
// import { Google, Apple } from "@mui/icons-material";

// const LoginPage = () => {
//     const [form, setForm] = useState({
//         firstName: "",
//         lastName: "",
//         email: "",
//         password: "",
//         agreed: false,
//     });

//     const handleChange = (e) => {
//         const { name, value, type, checked } = e.target;
//         setForm({ ...form, [name]: type === "checkbox" ? checked : value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         if (!form.agreed) {
//             alert("You must agree to the Terms & Conditions");
//             return;
//         }
//         console.log("Form submitted", form);
//     };

//     return (
//         <Container maxWidth="md" sx={{ display: "flex", justifyContent: "center", height: "100vh", alignItems: "center" }}>
//             <Paper elevation={10} sx={{ padding: 4, borderRadius: 4, backgroundColor: "#1e1e2e", color: "#fff", width: "100%" }}>
//                 <Grid container spacing={0}>
//                     {/* Left Side - Image */}
//                     <Grid item xs={12} md={6} sx={{
//                         backgroundImage: "url('https://cdn.dribbble.com/users/1841260/screenshots/7169295/media/898c87817635703c20c604776a8a0088.jpg?resize=1000x750&vertical=center')",
//                         backgroundSize: "cover",
//                         backgroundPosition: "center",
//                         display: "flex",
//                         alignItems: "center",
//                         justifyContent: "center",
//                         flexDirection: "column",
//                         borderRadius: "12px 0 0 12px",
//                         padding: 3
//                     }}>
//                         <Typography variant="h5" fontWeight="bold"> </Typography>
//                         <Typography variant="subtitle1" sx={{ mt: 2 }}></Typography>
//                     </Grid>

//                     {/* Right Side - Form */}
//                     <Grid item xs={12} md={6} sx={{ padding: 4 }}>
//                         <Typography variant="h5" fontWeight="bold" gutterBottom>Create an account</Typography>
//                         <form onSubmit={handleSubmit}>
//                             <Grid container spacing={2}>
//                                 <Grid item xs={6}>
//                                     <TextField fullWidth label="First Name" name="firstName" value={form.firstName} onChange={handleChange} variant="outlined" InputProps={{ style: { color: "#fff" } }} sx={{ backgroundColor: "#333", borderRadius: 1 }} />
//                                 </Grid>
//                                 <Grid item xs={6}>
//                                     <TextField fullWidth label="Last Name" name="lastName" value={form.lastName} onChange={handleChange} variant="outlined" InputProps={{ style: { color: "#fff" } }} sx={{ backgroundColor: "#333", borderRadius: 1 }} />
//                                 </Grid>
//                                 <Grid item xs={12}>
//                                     <TextField fullWidth label="Email" type="email" name="email" value={form.email} onChange={handleChange} variant="outlined" InputProps={{ style: { color: "#fff" } }} sx={{ backgroundColor: "#333", borderRadius: 1 }} />
//                                 </Grid>
//                                 <Grid item xs={12}>
//                                     <TextField fullWidth label="Password" type="password" name="password" value={form.password} onChange={handleChange} variant="outlined" InputProps={{ style: { color: "#fff" } }} sx={{ backgroundColor: "#333", borderRadius: 1 }} />
//                                 </Grid>
//                             </Grid>
//                             <FormControlLabel control={<Checkbox checked={form.agreed} onChange={handleChange} name="agreed" sx={{ color: "#fff" }} />} label={<Typography variant="body2" color="white">I agree to the Terms & Conditions</Typography>} />
//                             <Button fullWidth variant="contained" type="submit" sx={{ mt: 2, backgroundColor: "#6a5acd" }}>Create Account</Button>
//                             <Typography variant="body2" align="center" sx={{ mt: 2 }}>Or register with</Typography>
//                             <Box display="flex" justifyContent="center" gap={2} sx={{ mt: 2 }}>
//                                 <Button variant="outlined" startIcon={<Google />} sx={{ color: "#fff", borderColor: "#fff" }}>Google</Button>
//                                 <Button variant="outlined" startIcon={<Apple />} sx={{ color: "#fff", borderColor: "#fff" }}>Apple</Button>
//                             </Box>
//                         </form>
//                     </Grid>
//                 </Grid>
//             </Paper>
//         </Container>
//     );
// };

// export default LoginPage;

// LoginPage.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import { Box, TextField, Button, Typography, Container, Grid, Paper } from "@mui/material";

const LoginPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    const success = login(username, password);
    if (success) {
      navigate("/general"); // Navigate to general page after login
    } else {
      alert("Invalid credentials");
    }
  };

  return (
    <Container maxWidth="md" sx={{ display: "flex", justifyContent: "center", height: "100vh", alignItems: "center" }}>      
  <Paper elevation={10} sx={{ padding: 4, borderRadius: 4, backgroundColor: "#1e1e2e", color: "#fff", width: "100%" }}>        {/* Left Side - Image */}
  <Grid container spacing={0}>
        <Grid item xs={12} md={6} sx={{
backgroundImage: "url('/unnamed.webp')",
backgroundSize: "cover",
                        backgroundPosition: "center",
                       display: "flex",
                        alignItems: "center",
                       justifyContent: "center",
                        flexDirection: "column",
                         borderRadius: "12px 0 0 12px",
                         padding: 3
                         
                         }}>
                            </Grid>
        {/* Right Side - Form */}
        <Grid item xs={12} md={6} sx={{ padding: 4 }}>  
        <Typography variant="h2" fontWeight="bold" gutterBottom>Login</Typography>        <Box sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px",
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
            backgroundColor: "white",
            width: "100%",
            maxWidth: "400px",
          }}>
            <Typography variant="h4" sx={{ marginBottom: "20px", fontWeight: "bold" }}>
              Login
            </Typography>
            <form onSubmit={handleLogin} style={{ width: "100%" }}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    label="Username"
                    variant="outlined"
                    fullWidth
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    autoFocus
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    label="Password"
                    type="password"
                    variant="outlined"
                    fullWidth
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </Grid>
                <Grid item xs={12}>
                  <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    fullWidth
                    sx={{
                      padding: "10px",
                      fontSize: "16px",
                      borderRadius: "8px",
                      marginTop: "16px",
                      backgroundColor: "#3f51b5",
                      "&:hover": {
                        backgroundColor: "#303f9f",
                      },
                    }}
                  >
                    Login
                  </Button>
                </Grid>
              </Grid>
            </form>
          </Box>
        </Grid>
        </Grid>

      </Paper>
    </Container>
  );
};

export default LoginPage;

