// Pbit.js
import React, { useState } from 'react';
import Sidebar from './RadarSidebar'; // Import Sidebar component
import { Box, Button } from '@mui/material';
import { Routes, Route } from 'react-router-dom';
import Navbar from './RadarHealthStatus'; // Import Navbar

const Pbit = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false); // State to control sidebar visibility

  const handleSidebarToggle = () => {
    setSidebarOpen(!sidebarOpen); // Toggle the sidebar visibility
  };

  return (
    <Box sx={{ display: 'flex' }}>
      {/* Navbar with the PBIT Status button */}
      <Navbar onPbitClick={handleSidebarToggle} />

      {/* Sidebar */}
      <Sidebar open={sidebarOpen} onClose={handleSidebarToggle} />

      {/* Main Content */}
      <Box sx={{ flexGrow: 1, padding: 3 }}>
        <h2>PBIT Status</h2>
        <Routes>
          <Route path="/antenna-horizontal" element={<div>Antenna Horizontal Content</div>} />
          <Route path="/sspa-vertical" element={<div>SSPA Vertical Content</div>} />
          <Route path="/digital-rf-subsystem" element={<div>Digital RF Subsystem Content</div>} />
          <Route path="/power" element={<div>Power Content</div>} />
          <Route path="/servo" element={<div>Servo Content</div>} />
          <Route path="/fan" element={<div>FAN Content</div>} />
        </Routes>
      </Box>
    </Box>
  );
};

export default Pbit;
