import React, { useState } from 'react';
import { Box, TextField, Button, Switch, Typography, FormControlLabel } from '@mui/material';

const SunCalibration = () => {
  // States to manage input and toggle values
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [altitude, setAltitude] = useState('');
  const [flux, setFlux] = useState('');
  const [isOn, setIsOn] = useState(false);
  const [isAutomatic, setIsAutomatic] = useState(false);
  const [startTime, setStartTime] = useState('');
  const [stopTime, setStopTime] = useState('');

  // Handlers for input changes
  const handleLatitudeChange = (e) => setLatitude(e.target.value);
  const handleLongitudeChange = (e) => setLongitude(e.target.value);
  const handleAltitudeChange = (e) => setAltitude(e.target.value);
  const handleFluxChange = (e) => setFlux(e.target.value);
 
  const handleStartTimeChange = (e) => setStartTime(e.target.value);
  const handleStopTimeChange = (e) => setStopTime(e.target.value);

  // Start and Stop button handlers
  const handleStartStopClick = () => {
    alert(`Sun Calibration started at ${startTime}`);
  };

  const handleStopClick = () => {
    alert('Sun Calibration stopped.');
  };


 

  // Handle the on/off toggle for the 'Current Time' switch
  const handleOnOffChange = (event) => {
    setIsOn(event.target.checked);
  };

  // Handle the on/off toggle for the 'Automatic' switch
  const handleAutomaticChange = (event) => {
    setIsAutomatic(event.target.checked);
  };

  return (
    <Box sx={{ padding: 3 }}>
      {/* Heading */}
      <Typography variant="h4" gutterBottom align="left" sx={{ fontWeight: 'bold', marginBottom:"30px" }}>
        SUN CALIBRATION
      </Typography>

      {/* Main content */}
      <Box sx={{ display: 'flex', gap: 4 }}>
        {/* Left Section: Input Fields */}
        <Box sx={{ width: '40%' }}>
          <Typography variant="h6" gutterBottom>Sun Calibration Input</Typography>

          <TextField
            label="Latitude"
            fullWidth
            value={latitude}
            onChange={handleLatitudeChange}
            sx={{ marginBottom: 2 }}
          />

          <TextField
            label="Longitude"
            fullWidth
            value={longitude}
            onChange={handleLongitudeChange}
            sx={{ marginBottom: 2 }}
          />

          <TextField
            label="Altitude"
            fullWidth
            value={altitude}
            onChange={handleAltitudeChange}
            sx={{ marginBottom: 2 }}
          />
        </Box>

        {/* Right Section: Sun Calibration Box */}
        <Box sx={{ width: '60%', backgroundColor: '#f4f4f4', padding: 3, borderRadius: 2 }}>
          <Typography variant="h6" gutterBottom>Sun Calibration Control</Typography>

          {/* Flux Textbox */}
          <TextField
            label="Flux"
            fullWidth
            value={flux}
            onChange={handleFluxChange}
            sx={{ marginBottom: 2 }}
          />

          {/* On/Off Toggle */}
          <FormControlLabel
        control={
          <Switch
            checked={isOn}
            onChange={handleOnOffChange}
            sx={{
              '& .MuiSwitch-thumb': {
                backgroundColor: isOn ? 'green' : 'red', // Green if on, red if off
              },
              '& .MuiSwitch-track': {
                backgroundColor: isOn ? 'rgba(0, 255, 0, 0.5)' : 'rgba(255, 0, 0, 0.5)', // Track color changes as well
              },
            }}
          />
        }
        label="Current Time"
        sx={{ marginBottom: 2 }}
      />

      {/* Automatic Switch */}
      <FormControlLabel
        control={
          <Switch
            checked={isAutomatic}
            onChange={handleAutomaticChange}
            sx={{
              '& .MuiSwitch-thumb': {
                backgroundColor: isAutomatic ? 'green' : 'red', // Green if on, red if off
              },
              '& .MuiSwitch-track': {
                backgroundColor: isAutomatic ? 'rgba(0, 255, 0, 0.5)' : 'rgba(255, 0, 0, 0.5)', // Track color changes as well
              },
            }}
          />
        }
        label="Automatic"
        sx={{ marginBottom: 2 }}
      />
          {/* Start Time and Stop Time */}
          <TextField
            label="Start Time"
            fullWidth
            value={startTime}
            onChange={handleStartTimeChange}
            sx={{ marginBottom: 2 }}
          />

          <TextField
            label="Stop Time"
            fullWidth
            value={stopTime}
            onChange={handleStopTimeChange}
            sx={{ marginBottom: 2 }}
          />

          {/* Start and Stop Buttons */}
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button
              variant="contained"
              color="primary"
              onClick={handleStartStopClick}
              sx={{ flexGrow: 1 }}
            >
              Start Calibration
            </Button>
            <Button
              variant="contained"
              color="secondary"
              onClick={handleStopClick}
              sx={{ flexGrow: 1 }}
            >
              Stop Calibration
            </Button>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default SunCalibration;
