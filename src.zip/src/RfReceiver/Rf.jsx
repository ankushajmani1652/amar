import React, { useState, useEffect } from "react";
import {
  Box,
  Grid,
  Typography,
  Button,
  TextField,
  Switch,
  FormControlLabel,
} from "@mui/material";
import WarningIcon from "@mui/icons-material/Warning";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

const parameters = [
  { name: "Power Supply", value: "12 W " },
  { name: "LO1 Detect", value: "" },
  { name: "LO1 Lock ", value: "" },
  { name: "LO1 Temp", value: " 0 °C" },

  { name: "LO2 Detect", value: "" },
  { name: "LO2 Lock", value: "" },
  { name: "LO2 Temp", value: "0 °C" },

  { name: "RX1 Temp", value: "0 °C" },
  { name: "RX2 Temp", value: "0 °C" },

  { name: "TX Temp", value: "0 °C" },
  { name: "TX Detect", value: "" },

  { name: "Power Amp TX", value: " " },

  { name: "PA Bias", value: "" },

  { name: "VDD Alarm", value: " " },
  { name: "IDD Alarm", value: " " },
];

const Rf = () => {
  const [isMonPortEnabled, setIsMonPortEnabled] = useState(false);
  const [textFieldValues, setTextFieldValues] = useState({});
  const [randomColor, setRandomColor] = useState(false); // State for random response (red/green)
  const [randomIcon, setRandomIcon] = useState(null);
  const [selectGain, setSelectGain] = useState("");
  const [isPAEnabled, setIsPAEnabled] = useState(false);

  const handleSelectGainChange = (event) => {
    setSelectGain(event.target.value);
  };

  // Handler for toggling PA Enable
  const handleTogglePAEnable = (event) => {
    setIsPAEnabled(event.target.checked);
  };

  // Handler for Set button for Select Gain
  const handleSetSelectGain = () => {
    console.log("Select Gain Value:", selectGain);
    // Handle further logic to set the value if needed
  };

  // Handler for Set button for PA Enable
  const handleSetPAEnable = () => {
    console.log("PA Enable Status:", isPAEnabled ? "Enabled" : "Disabled");
    // Handle further logic to set the value if needed
  };

  const handleToggleMonPort = (event) => {
    setIsMonPortEnabled(event.target.checked);
  };

  const handleTextFieldChange = (name, value) => {
    setTextFieldValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };
  const handleSetValue = (name, value) => {
    // Logic to set the value, could be an API call or local state update
    console.log(`${name} set to: ${value}`);
  };

  const getRandomIcon = () => {
    return Math.random() > 0.5 ? (
      <WarningIcon sx={{ fontSize: 23, color: "red" }} />
    ) : (
      <CheckCircleIcon sx={{ fontSize: 23, color: "green" }} />
    );
  };

  return (
    <Grid container spacing={3} sx={{ height: "100vh", padding: 2 }}>
      {/* Left side: Status Box */}
      {/* <Grid item xs={3}>
        <Box
          sx={{
            backgroundColor: "#fff",
            padding: 2,
            borderRadius: 2,
            boxShadow: 2,
            height: "90%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            overflow: "auto",
          }}
        >
          <Typography
            variant="h4"
            sx={{
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: "20px",
            }}
          >
            Status
          </Typography>

          <Box display="flex" flexDirection="column" gap="12px">
            {parameters.map((param, index) => (
              <Box
                key={index}
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  background: "rgba(255, 255, 255, 0.1)",
                  borderRadius: "8px",
                  padding: "6px",
                  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                  cursor: "pointer",
                  "&:hover": {
                    backgroundColor: "rgba(255, 255, 255, 0.2)",
                  },
                }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    fontWeight: "bold",
                    color: "gray",
                    textTransform: "uppercase",
                    fontFamily: "'Times New Roman', serif",
                  }}
                >
                  {param.name}
                </Typography>

                <Box display="flex" alignItems="center">
                  {param.value === "" || param.value === " " ? (
                    getRandomIcon() // Show a random icon for empty or missing values
                  ) : (
                    <Typography
                      variant="h6"
                      sx={{
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {param.value}
                    </Typography>
                  )}
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
      </Grid> */}

      {/* Right side: 2 Rows with 2 Boxes */}
      <Grid item xs={9}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 2,
            fontFamily: "'Times New Roman', serif",
          }}
        >
          {/* Ethernet Link Button */}
          <Button
            variant="contained"
            sx={{
              alignSelf: "flex-start",
              backgroundColor: "green",
              color: "#fff",
              fontWeight: "bold",
              "&:hover": {
                backgroundColor: "#115293",
              },
              width: "100%",
              padding: "10px 20px",
              fontFamily: "'Times New Roman', serif",
            }}
          >
            Ethernet Link
          </Button>

          {/* Band Section with S-Band and Ka-Band */}
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Box
                sx={{
                  height: 160,
                  backgroundColor: "#f5f5f5", // Light gray background for a softer look
                  padding: 3,
                  borderRadius: 2, // Rounded corners for a softer look
                  boxShadow: 3, // Slightly larger shadow for depth
                  display: "flex",
                  marginTop: "2%",

                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "flex-start",
                  transition: "box-shadow 0.3s ease", // Smooth shadow transition on hover
                  "&:hover": {
                    boxShadow: 5, // Increase shadow on hover for interactivity
                  },
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    width: "100%",
                  }}
                >
                  {/* Left Side: S-band LO and Frequency */}
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                    }}
                  >
                    <Typography
                      variant="h6"
                      sx={{
                        fontWeight: "bold",
                        color: "#3f3f3f", // Darker text color for better readability
                        marginBottom: 1,
                        fontFamily: "'Times New Roman', serif",
                      }}
                    >
                      S-band LO
                    </Typography>

                    <TextField
                      label="Select Frequency"
                      variant="outlined"
                      type="number" // Ensure the input is numeric
                      value={textFieldValues["S-band LO"] || 2630} // Default value of 2630
                      inputProps={{
                        min: 2530, // Minimum value
                        max: 2730, // Maximum value
                        step: 1, // Step value of 1
                      }}
                      sx={{
                        width: "150%", // Slightly wider text field
                        marginTop: 1,
                        backgroundColor: "#fff", // White background for input
                        borderRadius: 1,
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": {
                            borderColor: "#ccc", // Lighter border color
                          },
                          "& .MuiOutlinedInput-input": {
                            fontFamily: "'Times New Roman', serif", // Font for the input text
                          },
                        },
                        "& .MuiInputLabel-root": {
                          fontFamily: "'Times New Roman', serif", // Font for the label
                        },
                        "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                        {
                          borderColor: "#7d7d7d", // Border color on hover
                        },
                      }}
                      onInput={(e) => {
                        let value = parseInt(e.target.value, 10);

                        // Enforce min and max values
                        // if (value < 2530) {
                        //   value = 2530;
                        // } else if (value > 2730) {
                        //   value = 2730;
                        // }

                        // Update the state to ensure the value is within range
                        setTextFieldValues((prev) => ({
                          ...prev,
                          "S-band LO": value,
                        }));
                      }}
                    />

                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() => {
                        // Log the values to the console
                        console.log(
                          "S-band LO Frequency:",
                          textFieldValues["S-band LO"]
                        );
                      }}
                    >
                      Set
                    </Button>
                  </Box>

                  {/* Right Side: Ka-Band LO */}
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-end",
                    }}
                  >
                    <Typography
                      variant="h6"
                      sx={{
                        fontWeight: "bold",
                        color: "#3f3f3f",
                        marginTop: 0,
                        marginRight: 3,
                        fontFamily: "'Times New Roman', serif",
                      }}
                    >
                      Ka-Band LO
                    </Typography>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={isMonPortEnabled}
                          onChange={handleToggleMonPort}
                          color="primary"
                          sx={{
                            "& .MuiSwitch-switchBase.Mui-checked": {
                              color: "#4caf50", // Green color when enabled
                            },
                            "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                            {
                              backgroundColor: "#4caf50", // Green track color
                            },
                          }}
                        />
                      }
                      label={isMonPortEnabled ? "Enabled" : "Disabled"}
                      sx={{
                        marginTop: 1,
                        fontWeight: "bold",
                        color: "#3f3f3f",
                      }}
                    />
                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() => {
                        // Log the value of Ka-Band LO switch status
                        console.log("Ka-Band LO :", isMonPortEnabled);
                      }}
                    >
                      Set
                    </Button>
                  </Box>
                </Box>
              </Box>
            </Grid>
          </Grid>

          {/* 2nd Row with Rx and Tx Boxes */}
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Box
                sx={{
                  height: 180, // Increase height to accommodate three text fields
                  backgroundColor: "#f5f5f5", // Light background for a modern look
                  padding: 3,
                  borderRadius: 2,
                  boxShadow: 2, // Slight shadow for depth
                  marginTop: "2%",

                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-evenly", // Even space between elements
                }}
              >
                {/* Title */}
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: "bold",
                    marginBottom: 2,
                    color: "#3f3f3f",
                    fontFamily: "'Times New Roman', serif",
                  }}
                >
                  RX-1
                </Typography>

                {/* Text Fields: Horizontal Layout */}
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    width: "100%",
                  }}
                >
                  {/* Common RF Path Gain */}
                  <Box sx={{ width: "30%" }}>
                    <TextField
                      label="Common RF Path Gain"
                      variant="outlined"
                      sx={{
                        width: "85%", // Slightly wider text field
                        marginTop: 1,
                        backgroundColor: "#fff", // White background for input
                        borderRadius: 1,
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": {
                            borderColor: "#ccc", // Lighter border color
                          },
                          "& .MuiOutlinedInput-input": {
                            fontFamily: "'Times New Roman', serif", // Font for the input text
                          },
                        },
                        "& .MuiInputLabel-root": {
                          fontFamily: "'Times New Roman', serif", // Font for the label
                        },
                        "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                        {
                          borderColor: "#7d7d7d", // Border color on hover
                        },
                      }}
                      onChange={(e) => {
                        setTextFieldValues((prev) => ({
                          ...prev,
                          "Common RF Path Gain": e.target.value,
                        }));
                      }}
                    />
                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() =>
                        handleSetValue(
                          "Common RF Path Gain",
                          textFieldValues["Common RF Path Gain"]
                        )
                      }
                    >
                      Set
                    </Button>
                  </Box>

                  {/* Low ADC Leg Gain */}
                  <Box sx={{ width: "30%" }}>
                    <TextField
                      label="Low ADC Leg Gain"
                      variant="outlined"
                      sx={{
                        width: "85%", // Slightly wider text field
                        marginTop: 1,
                        backgroundColor: "#fff", // White background for input
                        borderRadius: 1,
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": {
                            borderColor: "#ccc", // Lighter border color
                          },
                          "& .MuiOutlinedInput-input": {
                            fontFamily: "'Times New Roman', serif", // Font for the input text
                          },
                        },
                        "& .MuiInputLabel-root": {
                          fontFamily: "'Times New Roman', serif", // Font for the label
                        },
                        "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                        {
                          borderColor: "#7d7d7d", // Border color on hover
                        },
                      }}
                      onChange={(e) => {
                        setTextFieldValues((prev) => ({
                          ...prev,
                          "Low ADC Leg Gain": e.target.value,
                        }));
                      }}
                    />
                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() =>
                        handleSetValue(
                          "Low ADC Leg Gain",
                          textFieldValues["Low ADC Leg Gain"]
                        )
                      }
                    >
                      Set
                    </Button>
                  </Box>

                  {/* High ADC Leg Gain */}
                  <Box sx={{ width: "30%" }}>
                    <TextField
                      label="High ADC Leg Gain"
                      variant="outlined"
                      sx={{
                        width: "85%", // Slightly wider text field
                        marginTop: 1,
                        backgroundColor: "#fff", // White background for input
                        borderRadius: 1,
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": {
                            borderColor: "#ccc", // Lighter border color
                          },
                          "& .MuiOutlinedInput-input": {
                            fontFamily: "'Times New Roman', serif", // Font for the input text
                          },
                        },
                        "& .MuiInputLabel-root": {
                          fontFamily: "'Times New Roman', serif", // Font for the label
                        },
                        "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                        {
                          borderColor: "#7d7d7d", // Border color on hover
                        },
                      }}
                      onChange={(e) => {
                        setTextFieldValues((prev) => ({
                          ...prev,
                          "High ADC Leg Gain": e.target.value,
                        }));
                      }}
                    />
                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() =>
                        handleSetValue(
                          "High ADC Leg Gain",
                          textFieldValues["High ADC Leg Gain"]
                        )
                      }
                    >
                      Set
                    </Button>
                  </Box>
                </Box>
              </Box>
            </Grid>

            <Grid item xs={6}>
              <Box
                sx={{
                  height: 180, // Increase height to accommodate three text fields
                  backgroundColor: "#f5f5f5", // Light background for a modern look
                  padding: 3,
                  borderRadius: 2,
                  boxShadow: 2, // Slight shadow for depth
                  display: "flex",
                  marginTop: "2%",

                  flexDirection: "column",
                  justifyContent: "space-evenly", // Even space between elements
                }}
              >
                {/* Title */}
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: "bold",
                    marginBottom: 2,
                    color: "#3f3f3f",
                    fontFamily: "'Times New Roman', serif",
                  }}
                >
                  RX-2
                </Typography>

                {/* Text Fields: Horizontal Layout */}
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    width: "100%",
                  }}
                >
                  {/* Common RF Path Gain */}
                  <Box sx={{ width: "30%" }}>
                    <TextField
                      label="Common RF Path Gain"
                      variant="outlined"
                      sx={{
                        width: "85%", // Slightly wider text field
                        marginTop: 1,
                        backgroundColor: "#fff", // White background for input
                        borderRadius: 1,
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": {
                            borderColor: "#ccc", // Lighter border color
                          },
                          "& .MuiOutlinedInput-input": {
                            fontFamily: "'Times New Roman', serif", // Font for the input text
                          },
                        },
                        "& .MuiInputLabel-root": {
                          fontFamily: "'Times New Roman', serif", // Font for the label
                        },
                        "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                        {
                          borderColor: "#7d7d7d", // Border color on hover
                        },
                      }}
                      onChange={(e) => {
                        setTextFieldValues((prev) => ({
                          ...prev,
                          "Common RF Path Gain": e.target.value,
                        }));
                      }}
                    />
                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() =>
                        handleSetValue(
                          "Common RF Path Gain",
                          textFieldValues["Common RF Path Gain"]
                        )
                      }
                    >
                      Set
                    </Button>
                  </Box>

                  {/* Low ADC Left Gain */}
                  <Box sx={{ width: "30%" }}>
                    <TextField
                      label="Low ADC Left Gain"
                      variant="outlined"
                      sx={{
                        width: "85%", // Slightly wider text field
                        marginTop: 1,
                        backgroundColor: "#fff", // White background for input
                        borderRadius: 1,
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": {
                            borderColor: "#ccc", // Lighter border color
                          },
                          "& .MuiOutlinedInput-input": {
                            fontFamily: "'Times New Roman', serif", // Font for the input text
                          },
                        },
                        "& .MuiInputLabel-root": {
                          fontFamily: "'Times New Roman', serif", // Font for the label
                        },
                        "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                        {
                          borderColor: "#7d7d7d", // Border color on hover
                        },
                      }}
                      onChange={(e) => {
                        setTextFieldValues((prev) => ({
                          ...prev,
                          "Low ADC Left Gain": e.target.value,
                        }));
                      }}
                    />
                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() =>
                        handleSetValue(
                          "Low ADC Left Gain",
                          textFieldValues["Low ADC Left Gain"]
                        )
                      }
                    >
                      Set
                    </Button>
                  </Box>

                  {/* High ADC Left Gain */}
                  <Box sx={{ width: "30%" }}>
                    <TextField
                      label="High ADC Left Gain"
                      variant="outlined"
                      sx={{
                        width: "85%", // Slightly wider text field
                        marginTop: 1,
                        backgroundColor: "#fff", // White background for input
                        borderRadius: 1,
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": {
                            borderColor: "#ccc", // Lighter border color
                          },
                          "& .MuiOutlinedInput-input": {
                            fontFamily: "'Times New Roman', serif", // Font for the input text
                          },
                        },
                        "& .MuiInputLabel-root": {
                          fontFamily: "'Times New Roman', serif", // Font for the label
                        },
                        "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                        {
                          borderColor: "#7d7d7d", // Border color on hover
                        },
                      }}
                      onChange={(e) => {
                        setTextFieldValues((prev) => ({
                          ...prev,
                          "High ADC Left Gain": e.target.value,
                        }));
                      }}
                    />
                    <Button
                      variant="outlined"
                      sx={{
                        marginTop: 1,
                        backgroundColor: "#d9edc5", // Light green background
                        borderColor: "#4caf50", // Light green border color
                        color: "#4a5242", // Light green text color
                        "&:hover": {
                          borderColor: "#388e3c", // Darker green when hovered
                          color: "#4a5242", // Darker green text on hover
                        },
                      }}
                      onClick={() =>
                        handleSetValue(
                          "High ADC Left Gain",
                          textFieldValues["High ADC Left Gain"]
                        )
                      }
                    >
                      Set
                    </Button>
                  </Box>
                </Box>
              </Box>
            </Grid>

            {/* Tx-Converter Box */}
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Box
                  sx={{
                    height: 160,
                    backgroundColor: "#f5f5f5", // Light gray background for a softer look
                    padding: 3,
                    borderRadius: 2, // Rounded corners for a softer look
                    boxShadow: 3, // Slightly larger shadow for depth
                    display: "flex",
                    marginTop: "2%",
                    marginLeft: "1.2%",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "flex-start",
                    transition: "box-shadow 0.3s ease", // Smooth shadow transition on hover
                    "&:hover": {
                      boxShadow: 5, // Increase shadow on hover for interactivity
                    },
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      width: "100%",
                    }}
                  >
                    {/* Left Side: S-band LO and Frequency */}
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "flex-start",
                      }}
                    >
                      <Typography
                        variant="h6"
                        sx={{
                          fontWeight: "bold",
                          color: "#3f3f3f", // Darker text color for better readability
                          marginBottom: 1,
                          fontFamily: "'Times New Roman', serif",
                        }}
                      >
                        Gain Selection
                      </Typography>
                      <TextField
                        label="Select Gain"
                        variant="outlined"
                        sx={{
                          width: "85%", // Slightly wider text field
                          marginTop: 1,
                          backgroundColor: "#fff", // White background for input
                          borderRadius: 1,
                          "& .MuiOutlinedInput-root": {
                            "& fieldset": {
                              borderColor: "#ccc", // Lighter border color
                            },
                            "& .MuiOutlinedInput-input": {
                              fontFamily: "'Times New Roman', serif", // Font for the input text
                            },
                          },
                          "& .MuiInputLabel-root": {
                            fontFamily: "'Times New Roman', serif", // Font for the label
                          },
                          "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                          {
                            borderColor: "#7d7d7d", // Border color on hover
                          },
                        }}
                        onChange={(e) => {
                          setTextFieldValues((prev) => ({
                            ...prev,
                            "Gain Selection": e.target.value,
                          }));
                        }}
                      />
                      <Button
                        variant="outlined"
                        sx={{
                          marginTop: 1,
                          backgroundColor: "#d9edc5", // Light green background
                          borderColor: "#4caf50", // Light green border color
                          color: "#4a5242", // Light green text color
                          "&:hover": {
                            borderColor: "#388e3c", // Darker green when hovered
                            color: "#4a5242", // Darker green text on hover
                          },
                        }}
                        onClick={() => {
                          // console.log(
                          //   "Select Gain Value:",
                          //   textFieldValues["Select Gain"]
                          // );
                          handleSetValue(
                            "Select Gain",
                            textFieldValues["Gain Selection"]
                          );
                        }}
                      >
                        Set
                      </Button>
                    </Box>

                    {/* Right Side: Ka-Band LO */}
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "flex-end",
                      }}
                    >
                      <Typography
                        variant="h6"
                        sx={{
                          fontWeight: "bold",
                          color: "#3f3f3f",
                          marginTop: 0,
                          marginRight: 3,
                          fontFamily: "'Times New Roman', serif",
                        }}
                      >
                        PA Enable
                      </Typography>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={isPAEnabled}
                            onChange={handleTogglePAEnable}
                            color="primary"
                            sx={{
                              "& .MuiSwitch-switchBase.Mui-checked": {
                                color: "#4caf50", // Green color when enabled
                              },
                              "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                              {
                                backgroundColor: "#4caf50", // Green track color
                              },
                            }}
                          />
                        }
                        label={isPAEnabled ? "Enabled" : "Disabled"}
                        sx={{
                          marginTop: 1,
                          fontWeight: "bold",
                          color: "#3f3f3f",
                        }}
                      />
                      <Button
                        variant="outlined"
                        sx={{
                          marginTop: 1,
                          backgroundColor: "#d9edc5", // Light green background
                          borderColor: "#4caf50", // Light green border color
                          color: "#4a5242", // Light green text color
                          "&:hover": {
                            borderColor: "#388e3c", // Darker green when hovered
                            color: "#4a5242", // Darker green text on hover
                            fontFamily: "'Times New Roman', serif",
                          },
                        }}
                        onClick={() => handleSetValue("PA Enable", isPAEnabled)}
                      >
                        Set
                      </Button>
                    </Box>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      </Grid>
    </Grid>
  );
};

export default Rf;



