import React, { useState, useEffect } from "react";
import {
  Button,
  Box,
  TextField,
  Typography,
  Card,
  CardContent,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  IconButton,
  Select,
  InputLabel,
  FormControl,
  Drawer,
  Switch,
  FormControlLabel,
  FormHelperText,
  Divider,
  Paper,
  InputAdornment,
} from "@mui/material";
import { styled } from "@mui/system";

import DeleteIcon from "@mui/icons-material/Delete"; // Import the Delete icon
import VolumeScanForm from "../../../Servo/ScanForm/VolumeScan";
import AzimuthScanForm from "../../../Servo/ScanForm/AzimuthScan";
import ElevationSectorScan from "../../../Servo/ScanForm/ElevationSectorScan";
import StowMode from "../../../Servo/ScanForm/StowMode";
import HemisphericRHI from "../../../Servo/ScanForm/HemisphericRHI";
import CrossWindRHI from "../../../Servo/ScanForm/CrossWindRHI";
import AlongWindRHI from "../../../Servo/ScanForm/AlongWindRHI";
import BoundaryLayerRHI from "../../../Servo/ScanForm/BoundaryLayer";
import Desktop from "../../../Servo/Components/ServoDashboard";
import DefaultParameter from "../../../SystemConfiguration/DefaultParamerer";
import Rf from "../../../RfReceiver/Rf";
import RadarConfigForm from "./RadarConfigForm";
import Waveform from "./Waveform";

const TaskCreationPage = () => {
  const [tasks, setTasks] = useState([]);
  const [taskParameters, setTaskParameters] = useState({
    taskName: "",
    scanMode: "",
    dualPrf: "",
    ratio: "",
    prf1: "",
    prf2: "",
    ratio: "",
    pcDdc: "",
    rpm: "",
    range: "",
    azStartAngle: "",
    azStopAngle: "",
    elStartAngle: "",
    elStopAngle: "",
    additionalDegree: "",
    signalGenerationSetting: "",
    biasSetting: "",
    dtp1: "",
    dtp2: "",
    totalDtp: "",
    removalDtp: "",
    netcdfResolution: "",
    processing: "",
    fftPoint: "",
    clutterFilter: "",
    filterType: "",
    filterOrder: "",
    speckleFilter: "",
    windowingTechniques: "",
    clutterRatio: "",
    notchWidth: "",
    velocityMin: "",
    velocityMax: "",
    simulation: "",
  });

  const getUnitForKey = (key) => {
    const units = {
      azStartAngle: "Deg",
      azStopAngle: "Deg",
      elStartAngle: "Deg",
      elStopAngle: "Deg",
      additionalDegree: "Deg",
      rpm: "RPM",
      range: "km",
      velocityMin: "m/s",
      velocityMax: "m/s",
      ratio: "%",
      prf1: "Hz",
      prf2: "Hz",
      totalDtp: "ms",
      removalDtp: "%",
      netcdfResolution: "m",
      clutterRatio: "dB",
      notchWidth: "%",
      filterOrder: "",
      simulation: "",
      // Add more as necessary
    };
    return units[key] || "";
  };

  const [scheduledTasks, setScheduledTasks] = useState(0);
  const [completedTasks, setCompletedTasks] = useState(0);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [open, setOpen] = useState(false); // State to handle dialog visibility
  const [dialogContent, setDialogContent] = useState(""); // State to manage dialog content dynamically
  const [openDrawer, setOpenDrawer] = useState(false);
  const [upOpenDrawer, upSetOpenDrawer] = useState(false);

  const [drawerContent, setDrawerContent] = useState("");

  // Load tasks from localStorage when the component mounts
  useEffect(() => {
    const savedTasks = JSON.parse(localStorage.getItem("tasks"));
    if (savedTasks) {
      setTasks(savedTasks);
      // Initialize counters based on the loaded tasks
      setScheduledTasks(
        savedTasks.filter((task) => task.status === "scheduled").length
      );
      setCompletedTasks(
        savedTasks.filter((task) => task.status === "completed").length
      );
    }
  }, []);

  // Save tasks to localStorage whenever tasks change
  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem("tasks", JSON.stringify(tasks));
    }
  }, [tasks]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    // Check for specific parameters that need a value and unit update
    if (name === "" || name === "" || name === "") {
      setTaskParameters({
        ...taskParameters,
        [name]: { value, unit: taskParameters[name].unit },
      });
    } else {
      setTaskParameters({ ...taskParameters, [name]: value });
    }
  };

  const handleCreateTask = () => {
    if (!taskParameters.taskName.trim()) {
      alert("Task name cannot be empty.");
      return;
    }

    console.log("Sending Task Data:", taskParameters);

    const newTask = {
      id: Date.now(), // Unique ID based on timestamp
      ...taskParameters,
      status: "pending",
    };

    setTasks((prevTasks) => {
      const updatedTasks = [...prevTasks, newTask];

      // Update task count based on the status
      const scheduledCount = updatedTasks.filter(
        (task) => task.status === "scheduled"
      ).length;
      const completedCount = updatedTasks.filter(
        (task) => task.status === "completed"
      ).length;

      // Update state with new counts
      setScheduledTasks(scheduledCount);
      setCompletedTasks(completedCount);

      // Save the updated tasks in localStorage
      localStorage.setItem("tasks", JSON.stringify(updatedTasks));

      return updatedTasks;
    });

    setTaskParameters({
      taskName: "",
      scanMode: "",

      dualPrf: "",
      ratio: "",

      prf1: "",
      prf2: "",
      ratio: "",
      pcDdc: "",
      rpm: "",
      range: "",
      azStartAngle: "",
      azStopAngle: "",
      elStartAngle: "",
      elStopAngle: "",
      additionalDegree: "",
      biasSetting: "",
      dtp1: "",
      dtp2: "",
      totalDtp: "",
      removalDtp: "",
      netcdfResolution: "",
      processing: "",
      fftPoint: "",
      clutterFilter: "",
      windowingTechniques: "",
      filterOrder: "",
      clutterRatio: "",
      notchWidth: "",
      velocityMin: "",
      velocityMax: "",
      simulation: "",
    });
  };

  const handleTaskClick = (task) => {
    setSelectedTask(task);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedTask(null);
  };

  const updateTaskStatus = (taskId, status) => {
    setTasks((prevTasks) => {
      const updatedTasks = prevTasks.map((task) =>
        task.id === taskId ? { ...task, status } : task
      );

      // Update task count based on the status
      const scheduledCount = updatedTasks.filter(
        (task) => task.status === "scheduled"
      ).length;
      const completedCount = updatedTasks.filter(
        (task) => task.status === "completed"
      ).length;

      // Update state with new counts
      setScheduledTasks(scheduledCount);
      setCompletedTasks(completedCount);

      // Save the updated tasks in localStorage
      localStorage.setItem("tasks", JSON.stringify(updatedTasks));

      return updatedTasks;
    });
  };

  const scheduleTask = (task) => {
    updateTaskStatus(task.id, "scheduled");
  };

  const handleDeleteTask = (taskId) => {
    const updatedTasks = tasks.filter((task) => task.id !== taskId);
    setTasks(updatedTasks);

    // Update task count based on the status
    const scheduledCount = updatedTasks.filter(
      (task) => task.status === "scheduled"
    ).length;
    const completedCount = updatedTasks.filter(
      (task) => task.status === "completed"
    ).length;

    // Update state with new counts
    setScheduledTasks(scheduledCount);
    setCompletedTasks(completedCount);

    // Save the updated tasks in localStorage
    localStorage.setItem("tasks", JSON.stringify(updatedTasks));
  };

  const handleClickOpen = (content) => {
    setDialogContent(content); // Set dynamic content for the dialog
    setOpen(true); // Open the dialog
  };

  const handleClose = () => {
    setOpen(false); // Close the dialog
  };

  // Function to handle closing the drawer
  const handleCloseDrawer = () => {
    upSetOpenDrawer(false);
  };

  // Function to handle opening the drawer with specific content
  const handleDrawerOpen = (taskName) => {
    setDrawerContent(taskName); // Set the content based on the clicked task
    setOpenDrawer(true);
  };

  const upHandleDrawerOpen = (taskName) => {
    setDrawerContent(taskName); // Set the content based on the clicked task
    upSetOpenDrawer(true);
  };

  // Function to handle closing the drawer
  const handleDrawerClose = () => {
    setOpenDrawer(false);
  };

  //clutter FIlter

  const [filterType, setFilterType] = useState("");
  const [clutterFilter, setClutterFilter] = useState(false);
  const [notchWidth, setNotchWidth] = useState("");
  const [showNotchWidthButtons, setShowNotchWidthButtons] = useState(false); // To toggle the display of buttons

  const handleFilterChange = (event) => {
    setFilterType(event.target.value);
  };

  const handleClutterFilterChange = (event) => {
    setClutterFilter(event.target.checked);
  };

  const handleNotchWidthChange = (event) => {
    setNotchWidth(event.target.value);
    setShowNotchWidthButtons(true); // Show the buttons when the user clicks the "Notch Width" field
  };

  const StyledPaper = styled(Paper)(({ theme }) => ({
    padding: theme.spacing(3),
    borderRadius: "8px",
    boxShadow: theme.shadows[3],
    backgroundColor: "#f9f9f9",
  }));

  const handleNotchWidthSelect = (value) => {
    setNotchWidth(value);
    setShowNotchWidthButtons(false); // Hide the buttons after selection
  };

  const getBackground = (status) => {
    switch (status) {
      case 0:
        return "linear-gradient(135deg, red, black)";
      case 1:
        return "linear-gradient(135deg, green, black)";
      case 2:
        return "linear-gradient(135deg, yellow, black)";
      default:
        return "linear-gradient(135deg, grey, black)";
    }
  };

  const statusData = {
    Receiver: 0,
    Transmitter: 1,
    WRSP: 2,
    Servo: 0,
    Blanking: 1,
  };
  const handleRadarConfigChange = (formData) => {
    setTaskParameters((prev) => ({
      ...prev,
      signalGenerationSetting: formData, // or merge into main structure if fields are separate
    }));

    console.log("Radar Config Form Data Updated:", formData); // ✅ Shows data in console
  };


  return (
    <div
      style={{
        padding: "20px",
        minHeight: "100vh",
        backgroundColor: "#f4f4f4",
      }}
    >


      <Grid container spacing={4}>
        {Object.entries(statusData).map(([name, status]) => (
          <Grid item xs={12} key={name} md={2.3}>
            <Card
              sx={{
                background: getBackground(status),
                color: "white",
                borderRadius: "16px",
              }}
              onClick={() => upHandleDrawerOpen(name)}
            >
              <CardContent>
                <Typography variant="h6" align="center" gutterBottom>
                  {name === "Blanking" ? "Antenna" : name}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>


      {/* Drawer (Box that appears on the right) */}
      <Drawer
        anchor="Top"
        open={upOpenDrawer}
        onClose={handleCloseDrawer}
        sx={{ width: 600, marginTop: "20px" }}
      >
        <Box sx={{ padding: 2 }}>
          <Typography variant="h6">{drawerContent}</Typography>

          {drawerContent === "Servo" && <DefaultParameter />}
          {drawerContent === "WRSP" && <DefaultParameter />}
          {drawerContent === "Receiver" && <Rf />}
          {drawerContent === "Waveform" && <Waveform />}

          <Button
            onClick={handleCloseDrawer}
            color="primary"
            sx={{ marginTop: 2 }}
          >
            Close
          </Button>
        </Box>
      </Drawer>

      <Grid container spacing={2} sx={{ marginTop: 0 }}>
        <Grid item xs={12} md={7}>
          <Card sx={{ padding: 2, backgroundColor: "white" }}>
            <Typography
              variant="h4"
              gutterBottom
              sx={{ color: "black", fontWeight: "" }}
            >
              Create New Task
            </Typography>
            <form noValidate autoComplete="off">
              {/* Grid layout for 3 fields per row */}
              <Grid container spacing={1} sx={{ marginBottom: -2 }}>
                {Object.keys(taskParameters).map((key, index) => (
                  <Grid item xs={12} sm={3} key={index}>
                    {key === "pcDdc" ? (
                      // PC DDC Processing Dropdown
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          PC / DDC{" "}
                        </InputLabel>
                        <Select
                          label="PC/DDC "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem value="pc" sx={{ fontWeight: "bold" }}>
                            PC
                          </MenuItem>
                          <MenuItem value="ddc" sx={{ fontWeight: "bold" }}>
                            DDC
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "windowingTechniques" ? (
                      // Windowing Techniques Dropdown
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor:
                            filterType !== "FFT" && filterType !== "GMAP"
                              ? "#d3d3d3"
                              : "#9cb2d9", // Gray if disabled
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          WINDOWING TECHNIQUE
                        </InputLabel>
                        <Select
                          label="technique"
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                          disabled={
                            filterType !== "FFT" && filterType !== "GMAP"
                          } // Disable if not FFT or GMAP
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem value="hamming" sx={{ fontWeight: "bold" }}>
                            Hamming
                          </MenuItem>
                          <MenuItem value="hanning" sx={{ fontWeight: "bold" }}>
                            Hanning
                          </MenuItem>
                          <MenuItem
                            value="Rectangle"
                            sx={{ fontWeight: "bold" }}
                          >
                            Rectangle
                          </MenuItem>
                          <MenuItem
                            value="Wan Hann"
                            sx={{ fontWeight: "bold" }}
                          >
                            Wan Hann
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "scanMode" ? (
                      // Windowing Techniques Dropdown
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          Scan Mode{" "}
                        </InputLabel>
                        <Select
                          label="scanMode "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem
                            value="volume"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("volume")}
                          >
                            Volumetric
                          </MenuItem>

                          <MenuItem
                            value="Azimuth"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("Azimuth")}
                          >
                            Azimuth Sector
                          </MenuItem>
                          <MenuItem
                            value="Elevation"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("Elevation")}
                          >
                            Elevation Sector
                          </MenuItem>
                          <MenuItem
                            value="Zenith"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("Zenith")}
                          >
                            Zenith Scan
                          </MenuItem>
                          <MenuItem
                            value="Hemispheric"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("Hemispheric")}
                          >
                            Hemispheric Scan
                          </MenuItem>
                          <MenuItem
                            value="Cross Wind"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("Cross Wind")}
                          >
                            Cross Wind RHI
                          </MenuItem>
                          <MenuItem
                            value="Along Wind"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("Along Wind")}
                          >
                            Along Wind RHI
                          </MenuItem>
                          <MenuItem
                            value="Boundary Layer"
                            sx={{ fontWeight: "bold" }}
                            onClick={() => handleDrawerOpen("Boundary Layer")}
                          >
                            Boundary Layer RHI
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "processing" ? (
                      // Windowing Techniques Dropdown
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          PROCESSING{" "}
                        </InputLabel>
                        <Select
                          label="processing "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem
                            value="pulse pair"
                            sx={{ fontWeight: "bold" }}
                          >
                            Pulse Pair
                          </MenuItem>
                          <MenuItem value="fft" sx={{ fontWeight: "bold" }}>
                            FFT
                          </MenuItem>
                          <MenuItem value="dft" sx={{ fontWeight: "bold" }}>
                            DFT
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "dualPrf" ? (
                      // Windowing Techniques Dropdown
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          Dual PRF{" "}
                        </InputLabel>
                        <Select
                          label="Windowing technique "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem value="enable" sx={{ fontWeight: "bold" }}>
                            Enable
                          </MenuItem>
                          <MenuItem value="disable" sx={{ fontWeight: "bold" }}>
                            Disable
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "prf2" ? (
                      // Windowing Techniques Dropdown
                      <FormControl fullWidth variant="outlined">
                        <InputLabel
                          sx={{ color: "black", fontWeight: "bold" }}
                        ></InputLabel>
                        <TextField
                          disabled={taskParameters.dualPrf !== "enable"} // Disable PRF 2 if dualPrf is not enabled
                          label={key.replace(/([A-Z])/g, " $1").toUpperCase()}
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          fullWidth
                          variant="outlined"
                          InputLabelProps={{
                            style: {
                              color: "black", // White color for the label
                              fontWeight: "bold", // Bold font weight for the label
                            },
                          }}
                          InputProps={{
                            style: {
                              color: "black", // Black color for the input text
                            },
                          }}
                          sx={{
                            marginBottom: 2,
                            backgroundColor:
                              taskParameters.dualPrf !== "enable"
                                ? "#d3d3d3"
                                : "#9cb2d9", // Gray if disabled, blue if enabled
                            borderRadius: "8px", // Optional rounded corners for each box
                            padding: "5px", // Padding for a more box-like feel
                          }}
                        />
                      </FormControl>
                    ) : key === "dtp2" ? (
                      // Windowing Techniques Dropdown
                      <FormControl fullWidth variant="outlined">
                        <InputLabel
                          sx={{ color: "black", fontWeight: "bold" }}
                        ></InputLabel>
                        <TextField
                          disabled={taskParameters.dualPrf !== "enable"} // Disable dtp2 if dualPrf is not enabled
                          label={key.replace(/([A-Z])/g, " $1").toUpperCase()}
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          fullWidth
                          variant="outlined"
                          InputLabelProps={{
                            style: {
                              color: "black", // White color for the label
                              fontWeight: "bold", // Bold font weight for the label
                            },
                          }}
                          InputProps={{
                            style: {
                              color: "black", // Black color for the input text
                            },
                          }}
                          sx={{
                            marginBottom: 2,
                            backgroundColor:
                              taskParameters.dualPrf !== "enable"
                                ? "#d3d3d3"
                                : "#9cb2d9", // Gray if disabled, blue if enabled
                            borderRadius: "8px", // Optional rounded corners for each box
                            padding: "5px", // Padding for a more box-like feel
                          }}
                        />
                      </FormControl>
                    ) : key === "simulation" ? (
                      // Windowing Techniques Dropdown
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          SIMULATION{" "}
                        </InputLabel>
                        <Select
                          label="Windowing technique "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem value="gmap" sx={{ fontWeight: "bold" }}>
                            GMAP
                          </MenuItem>
                          <MenuItem value="iir" sx={{ fontWeight: "bold" }}>
                            IIR
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "ratio" ? (
                      // Windowing Techniques Dropdown
                      <FormControl fullWidth variant="outlined">
                        <InputLabel
                          sx={{ color: "black", fontWeight: "bold" }}
                        ></InputLabel>
                        <TextField
                          disabled={taskParameters.dualPrf !== "enable"} // Disable PRF 2 if dualPrf is not enabled
                          label={key.replace(/([A-Z])/g, " $1").toUpperCase()}
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          fullWidth
                          variant="outlined"
                          InputLabelProps={{
                            style: {
                              color: "black", // White color for the label
                              fontWeight: "bold", // Bold font weight for the label
                            },
                          }}
                          InputProps={{
                            style: {
                              color: "black", // Black color for the input text
                            },
                          }}
                          sx={{
                            marginBottom: 2,
                            backgroundColor:
                              taskParameters.dualPrf !== "enable"
                                ? "#d3d3d3"
                                : "#9cb2d9", // Gray if disabled, blue if enabled
                            borderRadius: "8px", // Optional rounded corners for each box
                            padding: "5px", // Padding for a more box-like feel
                          }}
                        />
                      </FormControl>
                    ) : key === "fftPoint" ? (
                      // FFT Point Input Field
                      <FormControl fullWidth variant="outlined">
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          {/* FFT POINT */}
                        </InputLabel>
                        <TextField
                          disabled={taskParameters.processing !== "fft"} // Disable if not FFT
                          label="FFT POINT"
                          name={key}
                          value={taskParameters[key]} // The value of the TextField is taken from the state
                          onChange={handleInputChange}
                          onClick={() => handleDrawerOpen("fftPoint")}
                          fullWidth
                          variant="outlined"
                          InputLabelProps={{
                            style: {
                              color: "black", // White color for the label
                              fontWeight: "bold", // Bold font weight for the label
                            },
                          }}
                          InputProps={{
                            style: {
                              color: "black", // Black color for the input text
                              fontWeight: "bold",
                            },
                          }}
                          sx={{
                            marginBottom: 2,
                            backgroundColor:
                              taskParameters.processing !== "fft"
                                ? "#d3d3d3"
                                : "#9cb2d9", // Gray if disabled, blue if enabled
                            borderRadius: "8px", // Rounded corners
                            padding: "5px", // Padding for box feel
                          }}
                        />
                      </FormControl>
                    ) : key === "biasSetting" ? (
                      // biasSetting
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          BIAS SETTING{" "}
                        </InputLabel>
                        <Select
                          label="technique "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem
                            value="Phidp Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            Phidp Bias
                          </MenuItem>
                          <MenuItem
                            value="Zdr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            Zdr Bias
                          </MenuItem>
                          <MenuItem
                            value="Ldr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            Ldr Bias
                          </MenuItem>
                          <MenuItem
                            value="Range Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            Range Bias
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "clutterRejectionType" ? (
                      // clutterRejectionType
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          Clutter Rejection Type{" "}
                        </InputLabel>
                        <Select
                          label="technique "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem
                            value="Phidp Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            IIR Filter
                          </MenuItem>
                          <MenuItem
                            value="Zdr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            FFT Based
                          </MenuItem>
                          <MenuItem
                            value="Ldr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            MAP Based
                          </MenuItem>
                          <MenuItem
                            value="Range Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            GMAP Based
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "clutterFilter" ? (
                      // FFT Point Input Field
                      <FormControl fullWidth variant="outlined">
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          {/* FFT POINT */}
                        </InputLabel>
                        <TextField
                          label="Clutter Setting"
                          name={key}
                          value={taskParameters[key]} // The value of the TextField is taken from the state
                          onChange={handleInputChange}
                          onClick={() => handleDrawerOpen("clutterFilter")}
                          fullWidth
                          variant="outlined"
                          InputLabelProps={{
                            style: {
                              color: "black", // White color for the label
                              fontWeight: "bold", // Bold font weight for the label
                            },
                          }}
                          InputProps={{
                            style: {
                              color: "black", // Black color for the input text
                              fontWeight: "bold",
                            },
                          }}
                          sx={{
                            marginBottom: 2,
                            backgroundColor: "#9cb2d9",
                            borderRadius: "8px", // Rounded corners
                            padding: "5px", // Padding for box feel
                          }}
                        />
                      </FormControl>
                    ) : key === "filterType" ? (
                      // clutterRejectionType
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          Filter Type{" "}
                        </InputLabel>
                        <Select
                          label="technique "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem
                            value="Phidp Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            Chebyshev
                          </MenuItem>
                          <MenuItem
                            value="Zdr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            Elliptic
                          </MenuItem>
                          <MenuItem
                            value="Ldr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            Butter Worth
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "filterOrder" ? (
                      // clutterRejectionType
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          Filter Order{" "}
                        </InputLabel>
                        <Select
                          label="technique "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem
                            value="Phidp Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            4
                          </MenuItem>
                          <MenuItem
                            value="Zdr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            5
                          </MenuItem>
                          <MenuItem
                            value="Ldr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            6
                          </MenuItem>
                          <MenuItem
                            value="Range Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            7
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "speckleFilter" ? (
                      // speckleFilter
                      <FormControl
                        fullWidth
                        variant="outlined"
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9",
                          borderRadius: "8px",
                          padding: "5px",
                        }}
                      >
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          Speckle Filter{" "}
                        </InputLabel>
                        <Select
                          label="technique "
                          name={key}
                          value={taskParameters[key]}
                          onChange={handleInputChange}
                          sx={{
                            "& .MuiSelect-select": {
                              color: "black", // Ensures selected value in the input is black
                              fontWeight: "bold", // Bold font for selected value
                            },
                            "& .MuiMenuItem-root": {
                              color: "black", // Ensures all dropdown items have black text
                            },
                          }}
                        >
                          <MenuItem value="" sx={{ fontWeight: "bold" }}>
                            Select...
                          </MenuItem>
                          <MenuItem
                            value="Phidp Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            No Speckle FIlter
                          </MenuItem>
                          <MenuItem
                            value="Zdr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            2D Speckle Filter
                          </MenuItem>
                          <MenuItem
                            value="Ldr Bias"
                            sx={{ fontWeight: "bold" }}
                          >
                            3D Speckle Filter
                          </MenuItem>
                        </Select>
                      </FormControl>
                    ) : key === "signalGenerationSetting" ? (
                      // FFT Point Input Field
                      <FormControl fullWidth variant="outlined">
                        <InputLabel sx={{ color: "black", fontWeight: "bold" }}>
                          {/* FFT POINT */}
                        </InputLabel>
                        <TextField
                          label="Signal Generation Setting"
                          name={key}
                          value={taskParameters[key]} // The value of the TextField is taken from the state
                          onChange={handleInputChange}
                          onClick={() =>
                            handleDrawerOpen("signalGenerationSetting")
                          }
                          fullWidth
                          variant="outlined"
                          InputLabelProps={{
                            style: {
                              color: "black", // White color for the label
                              fontWeight: "bold", // Bold font weight for the label
                            },
                          }}
                          InputProps={{
                            style: {
                              color: "black", // Black color for the input text
                              fontWeight: "bold",
                            },
                          }}
                          sx={{
                            marginBottom: 2,
                            backgroundColor: "#9cb2d9",
                            borderRadius: "8px", // Rounded corners
                            padding: "5px", // Padding for box feel
                          }}
                        />
                      </FormControl>
                    ) : (
                      // Regular TextField for other fields
                      <TextField
                        label={
                          <Box sx={{ display: "flex", alignItems: "center" }}>
                            <Typography
                              variant="body1"
                              sx={{ color: "black", fontWeight: "bold" }}
                            >
                              {key.replace(/([A-Z])/g, " $1").toUpperCase()}
                            </Typography>
                            <Typography
                              variant="body2"
                              sx={{ marginLeft: "8px", fontStyle: "italic" }}
                            >
                              {getUnitForKey(key)}
                            </Typography>
                          </Box>
                        }
                        name={key}
                        value={taskParameters[key]}
                        onChange={handleInputChange}
                        fullWidth
                        variant="outlined"
                        InputLabelProps={{
                          style: {
                            color: "black", // White color for the label
                            fontWeight: "bold", // Bold font weight for the label
                          },
                        }}
                        InputProps={{
                          style: {
                            color: "black", // Black color for the input text
                          },
                        }}
                        sx={{
                          marginBottom: 2,
                          backgroundColor: "#9cb2d9", // Box background color
                          borderRadius: "8px", // Optional rounded corners for each box
                          padding: "5px", // Padding for a more box-like feel
                        }}
                      />
                    )}
                  </Grid>
                ))}
              </Grid>
              <Button
                variant="contained"
                color="primary"
                fullWidth
                onClick={handleCreateTask}
                sx={{ marginTop: 2 }}
              >
                Create Task
              </Button>
            </form>
          </Card>
        </Grid>

        {/* Task List (Right Side) */}
        <Grid item xs={12} md={5}>
          {openDrawer && (
            <Box
              sx={{
                maxHeight: "calc(100vh - 170px)", // or adjust based on your layout
                backgroundColor: "#f5ecce",
                boxShadow: 3,
                padding: 2,
                borderRadius: 2,
                zIndex: 1300,
                overflow: "auto",
                width: "100%", // this will make the Box fill the Grid item
              }}
            >
              {drawerContent === "volume" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "volume" */}
                  <Typography variant="h5" fontWeight="bold">
                    Volume Section
                  </Typography>
                  <Typography variant="body1">
                    <VolumeScanForm />
                  </Typography>
                </div>
              )}

              {drawerContent === "Azimuth" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "Azimuth" */}
                  <Typography variant="h5" fontWeight="bold">
                    Azimuth Section
                  </Typography>
                  <Typography variant="body1">
                    <AzimuthScanForm />
                  </Typography>
                </div>
              )}

              {drawerContent === "Elevation" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "Elevation" */}
                  <Typography variant="h5" fontWeight="bold">
                    Elevation Sector
                  </Typography>
                  <Typography variant="body1">
                    <ElevationSectorScan />
                  </Typography>
                </div>
              )}

              {drawerContent === "Zenith" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "Zenith" */}
                  <Typography variant="h5" fontWeight="bold">
                    Zenith Scan
                  </Typography>
                  <Typography variant="body1">
                    <StowMode />
                  </Typography>
                </div>
              )}

              {drawerContent === "Hemispheric" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "Hemispheric" */}
                  <Typography variant="h5" fontWeight="bold">
                    Hemispheric Scan
                  </Typography>
                  <Typography variant="body1">
                    <HemisphericRHI />
                  </Typography>
                </div>
              )}

              {drawerContent === "Cross Wind" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "Cross Wind" */}
                  <Typography variant="h5" fontWeight="bold">
                    Cross Wind RHI
                  </Typography>
                  <Typography variant="body1">
                    <CrossWindRHI />
                  </Typography>
                </div>
              )}

              {drawerContent === "Along Wind" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "Along Wind" */}
                  <Typography variant="h5" fontWeight="bold">
                    Along Wind RHI
                  </Typography>
                  <Typography variant="body1">
                    <AlongWindRHI />
                  </Typography>
                </div>
              )}
              {drawerContent === "Boundary Layer" && (
                <div>
                  {/* Render <volume> content when the drawerContent is "Boundary Layer" */}
                  <Typography variant="h5" fontWeight="bold">
                    Boundary Layer RHI
                  </Typography>
                  <Typography variant="body1">
                    <BoundaryLayerRHI />
                  </Typography>
                </div>
              )}

              {drawerContent === "fftPoint" && (
                <div>
                  <Typography variant="h5" fontWeight="bold">
                    FFT Selection
                  </Typography>
                  <Typography variant="body1">
                    <div>
                      {Array.from({ length: 50 }, (_, index) => (
                        <Button
                          key={index + 1}
                          variant="contained"
                          style={{ margin: "5px" }}
                          onClick={() =>
                            setTaskParameters({
                              ...taskParameters,
                              fftPoint: index + 1,
                            })
                          } // Set the selected number in the taskParameters state
                        >
                          {index + 1}
                        </Button>
                      ))}
                    </div>
                  </Typography>
                </div>
              )}


              {drawerContent === "signalGenerationSetting" && (
                <div>
                  <Typography variant="h5" fontWeight="bold">
                    Signal Generation Setting
                  </Typography>
                  <Typography variant="body1">
                    <RadarConfigForm onChange={handleRadarConfigChange} />
                  </Typography>
                </div>
              )}





              {drawerContent === "clutterFilter" && (
                <Box
                  sx={{
                    maxWidth: 600,
                    margin: "auto",
                    padding: "20px",
                    backgroundColor: "#fff",
                    borderRadius: "8px",
                    boxShadow: 3,
                  }}
                >
                  <Typography variant="h5" fontWeight="bold" gutterBottom>
                    Clutter Setting
                  </Typography>

                  <Divider sx={{ marginBottom: "20px" }} />

                  <Grid container spacing={3}>
                    {/* Clutter Rejection Type */}
                    <Grid item xs={12}>
                      <Typography
                        variant="body1"
                        gutterBottom
                        fontWeight="bold"
                      >
                        Select Clutter Rejection Type:
                      </Typography>
                      <FormControl fullWidth>
                        <InputLabel>Clutter Rejection Type</InputLabel>
                        <Select
                          value={filterType}
                          onChange={handleFilterChange}
                          label="Clutter Rejection Type"
                        >
                          <MenuItem value="IIR">IIR Filter</MenuItem>
                          <MenuItem value="FFT">FFT Based</MenuItem>
                          <MenuItem value="MAP">MAP Based</MenuItem>
                          <MenuItem value="GMAP">GMAP Based</MenuItem>
                        </Select>
                        <FormHelperText>
                          Select the type of filter for clutter rejection.
                        </FormHelperText>
                      </FormControl>
                    </Grid>

                    {/* Clutter Filter */}
                    <Grid item xs={12} md={12}>
                      <StyledPaper>
                        <Typography variant="body1" gutterBottom>
                          Clutter Filter:
                        </Typography>
                        <FormControlLabel
                          control={
                            <Switch
                              checked={clutterFilter}
                              onChange={handleClutterFilterChange}
                              name="clutterFilter"
                              color="primary"
                            />
                          }
                          label="Enable Clutter Filter"
                        />
                      </StyledPaper>
                    </Grid>

                    {/* Clutter Filter Notch Width */}
                    <Grid item xs={12} md={12}>
                      <StyledPaper>
                        <Typography variant="body1" gutterBottom>
                          Clutter Filter Notch Width:
                        </Typography>
                        <TextField
                          fullWidth
                          label="Notch Width"
                          type="number"
                          value={notchWidth}
                          onFocus={handleNotchWidthChange} // Show the buttons when clicked
                          variant="outlined"
                          helperText="Click to select a value from 3 to 20"
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end" fontWeight="bold">
                                %
                              </InputAdornment>
                            ), // Appends % symbol inside the TextField
                          }}
                        />

                        {showNotchWidthButtons && (
                          <div>
                            {Array.from({ length: 18 }, (_, index) => (
                              <Button
                                key={index + 3}
                                variant="contained"
                                style={{ margin: "5px" }}
                                onClick={() =>
                                  handleNotchWidthSelect(index + 3)
                                } // Select the notch width from 3 to 20
                              >
                                {index + 3}%
                              </Button>
                            ))}
                          </div>
                        )}
                      </StyledPaper>
                    </Grid>

                    {/* Save Button */}
                    <Grid item xs={12}>
                      <Button variant="contained" color="secondary" fullWidth>
                        Save Settings
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              )}

              <Button
                onClick={handleDrawerClose}
                variant="contained" // Filled button style
                sx={{
                  marginTop: 2,
                  borderRadius: 2, // Rounded corners
                  padding: "10px 20px", // Comfortable padding
                  backgroundColor: "error.main", // Set red color (Material UI's red color)
                  color: "white", // White text for contrast
                  boxShadow: 3, // Subtle shadow for depth
                  "&:hover": {
                    backgroundColor: "error.dark", // Darker red on hover
                    boxShadow: 6, // Increase shadow on hover
                  },
                }}
              >
                Close
              </Button>
            </Box>
          )}
        </Grid>
      </Grid>

      {/* Dialog for Task Details */}
      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>Task Details</DialogTitle>
        <DialogContent>
          {selectedTask && (
            <Grid container spacing={2}>
              {Object.entries(selectedTask).map(([key, value]) => (
                <Grid item xs={6} key={key}>
                  <Typography variant="body1">
                    <strong>{key.replace(/([A-Z])/g, " $1")}:</strong> {value}
                  </Typography>
                </Grid>
              ))}
              <Grid item xs={12}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => scheduleTask(selectedTask)}
                  sx={{ marginRight: 2 }}
                >
                  Schedule
                </Button>

                <Button
                  variant="contained"
                  color="secondary"
                  onClick={() => updateTaskStatus(selectedTask.id, "completed")}
                >
                  Mark as Completed
                </Button>
                <Button
                  variant="contained"
                  color="secondary"
                  onClick={() => updateTaskStatus(selectedTask.id, "completed")}
                >
                  Remove
                </Button>
              </Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default TaskCreationPage;
