import React, { useState, useEffect } from 'react';
import { TextField, Box, Checkbox, FormControlLabel, Grid, Typography, Button } from '@mui/material';

const RadarConfigForm = () => {
  const [formData, setFormData] = useState({
    sigGen1: { startAmp: '', stopAmp: '', stepAmp: '', startFreq: '', stopFreq: '', stepFreq: '', mod: false, trigger: false },
    sigGen2: { startAmp: '', stopAmp: '', stepAmp: '', startFreq: '', stopFreq: '', stepFreq: '', mod: false, trigger: false },
    sigGen3: { startAmp: '', stopAmp: '', stepAmp: '', startFreq: '', stopFreq: '', stepFreq: '', mod: false, trigger: false },
    radarConstants: { IF1H: '', IF2H: '', IF3H: '', IF1V: '', IF2V: '', IF3V: '' },
    rangeGates: { IF1Start: '', IF1Stop: '', IF2Start: '', IF2Stop: '', IF3Start: '', IF3Stop: '' },
  });

  // Load saved data from localStorage when the component mounts
  useEffect(() => {
    const savedData = localStorage.getItem('radarConfigFormData');
    if (savedData) {
      setFormData(JSON.parse(savedData));
    }
  }, []);

  // Handle input changes
  const handleInputChange = (event, section, key) => {
    const value = event.target.value;
    setFormData((prevState) => ({
      ...prevState,
      [section]: { ...prevState[section], [key]: value },
    }));
  };

  // Handle checkbox changes
  const handleCheckboxChange = (event, section, key) => {
    const checked = event.target.checked;
    setFormData((prevState) => ({
      ...prevState,
      [section]: { ...prevState[section], [key]: checked },
    }));
  };

  // Save data to localStorage
  const handleSubmit = () => {
    localStorage.setItem('radarConfigFormData', JSON.stringify(formData));
    console.log('Saved to localStorage:', formData);
  };

  return (
    <Box p={3} sx={{ backgroundColor: "white", borderRadius: "20px" }}>
      <Typography variant="h4" gutterBottom>
        Radar Configuration
      </Typography>

      {/* Signal Generators Section */}
      <Grid container spacing={3}>
        {[1, 2, 3].map((index) => (
          <Grid item xs={12} md={4} key={`sigGen${index}`}>
            <Typography variant="h6" gutterBottom>
              Signal Generator {index}
            </Typography>

            <TextField
              fullWidth
              label={`Pulsed / CW`}
              value={formData[`sigGen${index}`].startAmp}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
              margin="normal"
            />
            <TextField
              fullWidth
              label={`Power Fixed/Sweep`}
              value={formData[`sigGen${index}`].startAmp}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
              margin="normal"
            />

            <TextField
              fullWidth
              label={`Frequency Fixed/Sweep`}
              value={formData[`sigGen${index}`].startAmp}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
              margin="normal"
            />
            <TextField
              fullWidth
              label={`Power Inc/Dec`}
              value={formData[`sigGen${index}`].startAmp}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
              margin="normal"
            />

            <TextField
              fullWidth
              label={`Start Amplitude ${index}`}
              value={formData[`sigGen${index}`].startAmp}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
              margin="normal"
            />
            <TextField
              fullWidth
              label={`Stop Amplitude ${index}`}
              value={formData[`sigGen${index}`].stopAmp}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stopAmp')}
              margin="normal"
            />
            <TextField
              fullWidth
              label={`Step Amplitude ${index}`}
              value={formData[`sigGen${index}`].stepAmp}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stepAmp')}
              margin="normal"
            />
            <TextField
              fullWidth
              label={`Start Frequency ${index}`}
              value={formData[`sigGen${index}`].startFreq}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startFreq')}
              margin="normal"
            />
            <TextField
              fullWidth
              label={`Stop Frequency ${index}`}
              value={formData[`sigGen${index}`].stopFreq}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stopFreq')}
              margin="normal"
            />
            <TextField
              fullWidth
              label={`Step Frequency ${index}`}
              value={formData[`sigGen${index}`].stepFreq}
              onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stepFreq')}
              margin="normal"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={formData[`sigGen${index}`].mod}
                  onChange={(e) => handleCheckboxChange(e, `sigGen${index}`, 'mod')}
                />
              }
              label={`Modulation ${index}`}
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={formData[`sigGen${index}`].trigger}
                  onChange={(e) => handleCheckboxChange(e, `sigGen${index}`, 'trigger')}
                />
              }
              label={`Trigger ${index}`}
            />
          </Grid>
        ))}
      </Grid>

      {/* Radar Constants Section */}
      <Typography variant="h6" gutterBottom>
        Radar Constants
      </Typography>
      <Grid container spacing={3}>
        {['IF1H', 'IF2H', 'IF3H', 'IF1V', 'IF2V', 'IF3V'].map((key) => (
          <Grid item xs={12} md={4} key={key}>
            <TextField
              fullWidth
              label={`Radar Constant ${key}`}
              value={formData.radarConstants[key]}
              onChange={(e) => handleInputChange(e, 'radarConstants', key)}
              margin="normal"
            />
          </Grid>
        ))}
      </Grid>

      {/* Range Gates Section */}
      <Typography variant="h6" gutterBottom>
        Range Gates
      </Typography>
      <Grid container spacing={3}>
        {['IF1Start', 'IF1Stop', 'IF2Start', 'IF2Stop', 'IF3Start', 'IF3Stop'].map((key) => (
          <Grid item xs={12} md={4} key={key}>
            <TextField
              fullWidth
              label={`Range Gate ${key}`}
              value={formData.rangeGates[key]}
              onChange={(e) => handleInputChange(e, 'rangeGates', key)}
              margin="normal"
            />
          </Grid>
        ))}
      </Grid>

      {/* Submit Button */}
      <Box mt={3}>
        <Button variant="contained" color="primary" onClick={handleSubmit}>
          Save        </Button>
      </Box>
    </Box>
  );
};

export default RadarConfigForm;
