import React, { useState, useEffect } from "react";
import Header from "../../components/Header";
import {
  Box,
  Typography,
  useTheme,
  Button,
  Grid,
  Paper,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Hidden,
} from "@mui/material";
import { styled } from "@mui/system";

import { tokens } from "../../theme";
import StatBox from "../../components/StatBox";
import AntennaComponent from "../../subsystem/Antenna/AntennaComponent";
import LiveLineChart from "../../LiveLineChart";
import FlippableBox from "../../flippableBox";
import RadarLoader from "../../subsystem/RadarLoader/RadarLoader";
import RadarHealthStatus from "../../subsystem/RadarHealthStatus/RadarHealthStatus";
import Buttons from "../../flippableBox";
import ConnectedTvIcon from "@mui/icons-material/ConnectedTv";
import ElectricalServicesIcon from "@mui/icons-material/ElectricalServices";
import StorageIcon from "@mui/icons-material/Storage";
import RadarIcon from "@mui/icons-material/Radar";

const Index = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  // State to track power status (on or off)
  const [isPowerOn, setIsPowerOn] = useState(true);

  // State for dynamic needle values
  const [angle, setAngle] = useState(0);
  const [speed, setSpeed] = useState(0);

  // Toggle function for power on/off
  const togglePower = () => {
    setIsPowerOn((prev) => !prev);
  };

  {
    /* State to control popup visibility and selected subsystem */
  }
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedSubsystem, setSelectedSubsystem] = useState(null);
  const [flippedIndex, setFlippedIndex] = useState(null); // No need for openDialog

  const handleBoxClick = (index) => {
    setFlippedIndex(index === flippedIndex ? null : index); // Toggle flip state
  };
  // Function to handle box click
  // const handleBoxClick = (subsystem) => {
  //   setSelectedSubsystem(subsystem); // Set the clicked subsystem
  //   setOpenDialog(true); // Open the dialog
  // };

  // Function to close the popup
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedSubsystem(null);
  };

  const subsystems = [
    { title: "Weather Radar Controller Status", status: "Active" },
    { title: "Weather Radar Data Product Generation", status: "Inactive" },
    { title: "Weather Radar Signal Processing", status: "Active" },
    // { title: "Data Product Generation", status: "Inactive" },
  ];

  const parameters = [
    { name: "Current Mode", value: "Auto" },
    { name: "Azimuth Angle", value: "45°" },
    { name: "Elevation Angle", value: "30°" },
    { name: "Scan Mode", value: "Normal" },
    { name: "Polarization", value: "Vertical" },
    { name: "PRF1", value: "1200 Hz" },
    { name: "PRF2", value: "1200 Hz" },
    { name: "DTP", value: "15 ms" },
    { name: "RPM", value: "3000" },
    { name: "Pulse Width", value: "10 µs" },
    { name: "Filter", value: "High" },
    { name: "Range", value: "10 km" },
    { name: "Max Range", value: "50 km" },
    { name: "WRDP Archival", value: "On" },
    { name: "WRSP Archival", value: "Off" },
  ];

  const ParameterCard = styled(Paper)(({ theme }) => ({
    padding: "6px",
    borderRadius: "12px",
    backgroundColor: theme.palette.background.paper,
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    // transition: "transform 0.3s ease",
    "&:hover": {
      transform: "scale(1.03)",
      boxShadow: "0 6px 12px rgba(0, 0, 0, 0.3)",
    },
  }));

  // State for dialog visibility and selected parameter
  const [openParameterDialog, setOpenParameterDialog] = useState(false);
  const [selectedParameter, setSelectedParameter] = useState(null);

  // Function to handle parameter click
  const handleParameterClick = (param) => {
    setSelectedParameter(param); // Set the clicked parameter
    setOpenParameterDialog(true); // Open the dialog
  };

  // Function to close the dialog
  const handleCloseParameterDialog = () => {
    setOpenParameterDialog(false);
    // setSSidebarelectedParameter(null);
  };

  // Simulate needle movement
  useEffect(() => {
    const interval = setInterval(() => {
      setAngle((prevAngle) => (prevAngle + 1) % 360);
    }, 5000);
    setSpeed(Math.floor(90));
    // }, 2000); // Updates every 2 seconds

    return () => clearInterval(interval); // Cleanup interval on component unmount
  }, []);

  const color = {
    primary: "#0d47a1", // Blue
    greenAccent: "#66bb6a", // Green
    redAccent: "#f44336", // Red
    grey: "#b0bec5", // Light grey
  };

  // Helper function for calculating the needle position based on value (0-6)
  const calculateNeedlePosition = (value, maxValue) => {
    const percentage = (value / maxValue) * 100;
    // Ensure the needle stays within the bounds (0% to 100%)
    return Math.min(Math.max(percentage, 0), 100); // Clamp the value between 0 and 100
  };
  // Needle Component
  const Needle = ({ value, color, maxValue }) => {
    return (
      <Box
        sx={{
          width: "2px",
          height: "15px",
          backgroundColor: color,
          position: "absolute",
          top: "0px",
          left: `${calculateNeedlePosition(value, maxValue)}%`,
          transformOrigin: "center",
          transition: "all 0.3s ease-in-out", // Smooth animation when needle moves
          boxShadow: `0px 0px 12px rgba(${color === "#66bb6a"
            ? "0, 255, 0"
            : color === "#f44336"
              ? "255, 0, 0"
              : "0, 0, 255"
            }, 0.6)`,
        }}
      />
    );
  };

  // Scale Component
  const Scale = ({ title, value, color, maxValue, isRPM = false }) => {
    const numLabels = 7; // Always display 6 labels

    // The step is 1:1 for Azimuth and Elevation Acceleration, each unit will correspond to one label
    const step = maxValue / numLabels;

    // Calculate the number of labels based on the step
    return (
      <Box display="flex" flexDirection="column" alignItems="center" mb="20px">
        <Typography variant="h5" color={colors.grey} mb="12px">
          {title}:{" "}
          <span style={{ color: "#2f7a04", fontWeight: "bold" }}>
            {value} {title === "Azimuth Acceleration" || title === "Elevation Acceleration" ? " m/s²" : ""}
          </span>
        </Typography>


        <Box
          sx={{
            width: "210px", // Increased width for a larger scale
            height: "20px", // Height of the scale line
            background: `linear-gradient(to right, ${colors.primary} 0%, ${color} 100%)`, // Gradient background for scale
            borderRadius: "5px", // Rounded corners for the scale
            position: "relative",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 10px",
            boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.2)", // Soft shadow for depth
            marginLeft: "40px",
          }}
        >
          {/* Render the Needle */}
          <Needle value={value} color={color} maxValue={maxValue} />
          {/* Labels for each value on the scale */}
          {[...Array(numLabels)].map((_, index) => (
            <Typography
              key={index}
              sx={{
                color: colors.white,
                fontSize: "12px",
                position: "absolute",
                top: "0px",
                left: `${index * (100 / numLabels)}%`, // Adjust label position based on the scale's range
                fontWeight: "bold",
                textShadow: "1px 1px 3px rgba(0, 0, 0, 0.6)", // Text shadow for better visibility
              }}
            >
              {step * index} {/* Displaying values */}
            </Typography>
          ))}
        </Box>
        <Typography
          sx={{
            position: "absolute",
            marginTop: "14px",
            color: colors.grey,
            fontWeight: "600",
            fontWeight: "bold",
          }}
        >
          {/* {value} */}
        </Typography>
      </Box>
    );
  };

  const values = [76, 23, 4];

  return (
    <Box
      display="grid"
      gridTemplateColumns="repeat(12, 1fr)"
      gridAutoRows="minmax(150px, 1fr)"
      gap="10px"
    >
      {/* Radar Paramater */}
      <Box
        sx={{
          gridColumn: {
            xs: "span 12",  // full width on extra small screens
            sm: "span 6",   // half on small screens (optional)
            md: "span 12",  // full width on medium screens
            lg: "span 3",   // 3/12 on large screens
          },
          gridRow: "span 3",
          backgroundColor: colors.primary[400],
          padding: "6px",
          borderRadius: "8px",
          overflow: "auto",
        }}
      >
        <Typography
          variant="h4"
          sx={{
            fontWeight: "bold",
            textAlign: "center",
            marginBottom: "6px",
            color: theme.palette.text.primary,
          }}
        >
          Radar Parameters
        </Typography>

        {/* Parameter List */}
        <Box display="flex" flexDirection="column" gap="12px">
          {parameters.map((param, index) => (
            <Box
              key={index}
              onClick={() => handleParameterClick(param)} // Attach click handler
              sx={{
                display: "flex",
                justifyContent: "space-between",
                background: "rgba(255, 255, 255, 0.1)",
                borderRadius: "8px",
                padding: "1px 6px",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                cursor: "pointer", // Indicate clickable area
                "&:hover": {
                  backgroundColor: "rgba(255, 255, 255, 0.2)", // Highlight on hover
                },
              }}
            >
              <Typography
                variant="subtitle1"
                sx={{
                  fontWeight: "bold",
                  color: theme.palette.text.primary,
                  textTransform: "uppercase",
                }}
              >
                {param.name}
              </Typography>
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "medium",
                  color: theme.palette.text.primary,
                }}
              >
                {param.value}
              </Typography>
            </Box>
          ))}
        </Box>
      </Box>

      <Dialog
        open={openParameterDialog}
        onClose={handleCloseParameterDialog}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>{selectedParameter?.name}</DialogTitle>
        <DialogContent>
          <Typography variant="body1">
            Value: {selectedParameter?.value}
          </Typography>
          <LiveLineChart />
        </DialogContent>
      </Dialog>

      {/* ROW 1 */}

      {subsystems.map((subsystem, index) => (
        <Box
          key={index}
          sx={{
            gridColumn: {
              xs: "span 12",
              sm: "span 6",
              md: "span 12",
              lg: "span 3",
            },
            backgroundColor: colors.primary[400],
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            position: "relative",
            boxShadow: "0 10px 20px rgba(0, 0, 0, 0.3)",
            borderRadius: "10px",
            cursor: "pointer",
            overflow: "hidden",
          }}

          onClick={() => handleBoxClick(index)}
        >
          <StatBox
            title={subsystem.title}
            subtitle={subsystem.status}
            progress="0.75"
            increase=""
          />
        </Box>
      ))}

      {/* Full-Screen FlippableBox Modal */}
      {flippedIndex !== null &&
        subsystems[flippedIndex].title ===
        "Weather Radar Signal Processing" && (
          <Box
            position="fixed"
            top={0}
            left={0}
            width="100vw"
            height="100vh"
            display="flex"
            alignItems="center"
            justifyContent="center"
            backgroundColor="rgba(0, 0, 0, 0.7)" // Dark overlay
            zIndex={1300} // Ensure it's above other elements
            onClick={() => setFlippedIndex(null)} // Close when clicking outside
          >
            <Box
              width="50%"
              height="60%"
              backgroundColor="gray"
              borderRadius="20px"
              boxShadow="0 10px 30px rgba(0,0,0,0.5)"
              display="flex"
              flexDirection="column"
              alignItems="center"
              justifyContent="center"
              position="relative"
              onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside
            >
              <IconButton
                sx={{
                  position: "absolute",
                  top: 10,
                  right: 10,
                  color: "black",
                }}
                onClick={() => setFlippedIndex(null)}
              >
                ✖
              </IconButton>
              {/* <Buttons/> */}

              <FlippableBox
                subsystems={subsystems}
                setIsFlipped={() => setFlippedIndex(null)}
              />
            </Box>
          </Box>
        )}

      {/* Popup Dialog */}

      {/* ROW 2 */}
      <Box
        sx={{
          gridColumn: {
            xs: "span 12", // Full width on extra-small screens
            sm: "span 6",  // Half width on small screens
            md: "span 12", // Full width on medium screens
            lg: "span 4",  // Quarter width on large screens
          },
          gridRow: "span 2",
          overflow: "auto",
          position: "relative",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          boxShadow: "0 10px 20px rgba(0, 0, 0, 0.3)",
          borderRadius: "10px",
          transform: "translateZ(0)",
          "&:hover": {
            boxShadow: "0 20px 30px rgba(0, 0, 0, 0.4)",
          },
          "&::before": {
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            filter: "blur(10px)",
            borderRadius: "10px",
            zIndex: 1,
          },
        }}
      >

        <Box
          mt="25px"
          p="0 30px"
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <Typography
            variant="h4"
            fontWeight="600"
            color={colors.grey[100]}
            fontFamily="'Times New Roman', serif"
          >
            Servo Angle
          </Typography>
        </Box>

        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          overflow="auto"
          mt="0px"
          p="2px"
          flexWrap="wrap"
        >
          {/* Left side: Angle and Speed dials next to each other */}
          <Box
            display="flex"
            flexDirection="column"
            alignItems="center"
            mb="20px"
          >
            {/* Angle Section */}
            <Box
              display="flex"
              flexDirection="column"
              alignItems="center"
              mb="20px"
            >
              <Typography
                variant="h6"
                color={colors.grey[100]}
                mb="10px"
                fontWeight="bold"
              >
                Azimuth Angle
              </Typography>
              <Box
                sx={{
                  width: "120px",
                  height: "120px",
                  borderRadius: "50%",
                  background: `radial-gradient(circle at center, ${colors.primary[400]} 50%, ${colors.greenAccent[500]} 100%)`,
                  position: "relative",
                  boxShadow:
                    "inset 0 5px 15px rgba(255, 255, 255, 0.2), 0 10px 20px rgba(0, 0, 0, 0.3)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {/* Needle */}
                <Box
                  sx={{
                    width: "2px",
                    height: "50px",
                    backgroundColor: `${colors.greenAccent[500]}`,
                    position: "absolute",
                    top: "15px",
                    transform: `{angle}`,
                    transformOrigin: "40% 90%",
                    boxShadow: "0px 0px 10px rgba(0, 255, 0, 0.5)",
                  }}
                />
                {/* Center Pin */}
                <Box
                  sx={{
                    width: "12px",
                    height: "12px",
                    borderRadius: "50%",
                    backgroundColor: colors.grey[100],
                    border: `2px solid ${colors.greenAccent[500]}`,
                    boxShadow: "0 5px 10px rgba(0, 0, 0, 0.5)",
                    position: "absolute",
                  }}
                />
              </Box>
              {/* Angle displayed below the dial */}
              <Typography
                sx={{
                  marginTop: "10px",
                  color: colors.grey[100],
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                {angle}°
              </Typography>
            </Box>

            {/* Speed Section */}
            <Box display="flex" flexDirection="column" alignItems="center">
              <Typography
                variant="h6"
                color={colors.grey[100]}
                mb="10px"
                fontWeight="bold"
              >
                Elevation Angle
              </Typography>
              <Box
                sx={{
                  width: "140px", // Increased width to make the semicircle more prominent
                  height: "70px", // Half of the full circle's height
                  borderRadius: "120px 120px 0 0", // Top corners rounded to create a half circle
                  background: `radial-gradient(${colors.primary[400]} 40%, ${colors.redAccent[500]} 150%)`,
                  position: "relative",
                  boxShadow:
                    "inset 0 5px 15px rgba(255, 255, 255, 0.2), 0 10px 20px rgba(0, 0, 0, 0.3)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  overflow: "hidden", // Hide anything outside the semicircle
                }}
              >
                {/* Needle */}
                <Box
                  sx={{
                    width: "2px",
                    height: "50px",
                    backgroundColor: `${colors.redAccent[500]}`,
                    position: "absolute",
                    top: "15px",
                    transform: `{speed}`,
                    transformOrigin: "50% 90%", // Make needle rotate around the bottom center
                    boxShadow: "0px 0px 10px rgba(255, 0, 0, 0.5)",
                  }}
                />
                {/* Center Pin */}
                <Box
                  sx={{
                    width: "12px",
                    height: "12px",
                    borderRadius: "50%",
                    backgroundColor: colors.grey[100],
                    border: `2px solid ${colors.redAccent[500]}`,
                    boxShadow: "0 5px 10px rgba(0, 0, 0, 0.5)",
                    position: "absolute",
                    top: "54px",
                  }}
                />
              </Box>
              {/* Angle displayed below the dial */}
              <Typography
                sx={{
                  marginTop: "10px",
                  color: colors.grey[100],
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                {speed}°
              </Typography>
            </Box>
          </Box>

          {/* Right side: Servo Mode */}
          <Box
            display="flex"
            flexDirection="column"
            p="0px"
            mt="0px"
          >
            <Typography
              variant="body1"
              fontWeight="600"
              color="black"
              marginBottom="20px"
              backgroundColor="#e0f7fa"
              borderRadius="5px"
              textAlign="center"
              padding="5px 10px"
            >
              {/* Servo Mode: {mode === "local" ? "Local Mode" : "Remote Mode"} */}
              Servo Mode: {"Remote Mode"}

            </Typography>
            <Typography
              variant="body1"
              fontWeight="600"
              color="black"
              marginBottom="20px"
              backgroundColor="#e0f7fa"
              borderRadius="5px"
              textAlign="center"
              padding="5px 10px"
            >
              Operation Mode State:{" "}
              {/* {responseValues.elevation.operationModeState || "Not Available"} */}
              {"Volume Scan"}
            </Typography>

            {/* Scan Completion */}
            <Typography
              variant="body1"
              fontWeight="600"
              color="black"
              marginBottom="20px"
              backgroundColor="#e0f7fa"
              borderRadius="5px"
              textAlign="center"
              padding="5px 10px"
            >
              Scan Completion:{" "}
              {/* {responseValues.scanCompletion ? "Completed" : "In Progress"} */}
              {"Completed"}
            </Typography>
            {/* RPM Scale */}
            <Scale
              title="RPM"
              value={3}
              color={color.primary}
              maxValue={7}
              isRPM={true}
            />
          </Box>
        </Box>
      </Box>

      {/* Other boxes */}
      <Box
        gridRow="span 2"
        backgroundColor={colors.primary[400]}
        overflow="auto"
        sx={{
          gridColumn: {
            xs: "span 12",
            sm: "span 6",
            md: "span 6",
            lg: "span 3",
          },
          boxShadow: "0 10px 20px rgba(0, 0, 0, 0.3)",
          borderRadius: "10px",
          transform: "translateZ(0)",
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",      // Stack content vertically on extra-small screens
            sm: "1fr",      // Stack on small screens too
            md: "1fr 1fr",  // Side-by-side from medium screens onward
          },
          "&:hover": {
            boxShadow: "0 20px 30px rgba(0, 0, 0, 0.4)",
          },
        }}
      >

        {/* Left Half */}
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px",
            borderRight: "1px solid rgba(255, 255, 255, 0.2)", // Optional divider line
          }}
        >
          <Typography variant="h4" fontWeight="600" color={colors.grey[100]}>
            Transmitter
          </Typography>
          <Button
            sx={{
              padding: "3px 14px",
              fontSize: "15px",
              backgroundColor: "#4caf50",
              color: "white",
              borderRadius: "30px",
              marginTop: "20px",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
              "&:hover": {
                backgroundColor: "#45a049",
                boxShadow: "0 6px 12px rgba(0, 0, 0, 0.3)",
              },
              "&:active": {
                backgroundColor: "#388e3c",
              },
              transition: "all 0.3s ease",
            }}
          >
            Tx
          </Button>
        </Box>

        {/* Right Half */}
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px",
          }}
        >
          <Typography variant="h4" fontWeight="600" color={colors.grey[100]}>
            Exciter/Receiver
          </Typography>
          <Button
            sx={{
              padding: "3px 14px",
              fontSize: "15px",
              backgroundColor: "#fc6a6a",
              color: "white",
              borderRadius: "30px",
              marginTop: "20px",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
              "&:hover": {
                boxShadow: "0 6px 12px rgba(0, 0, 0, 0.3)",
              },
              "&:active": {
                // Background color for active state can be added if needed
              },
              transition: "all 0.3s ease",
            }}
          >
            RX
          </Button>
        </Box>
      </Box>


      <Box
        gridRow="span 2"
        backgroundColor={colors.primary[400]}
        overflow="auto"
        sx={{
          gridColumn: {
            xs: "span 12", // Full width on extra-small screens
            sm: "span 6",  // Half width on small screens
            md: "span 6",  // Half width on medium screens
            lg: "span 2",  // 2/12 width on large screens
          },
          boxShadow: "0 10px 20px rgba(0, 0, 0, 0.3)",
          borderRadius: "10px",
          transform: "translateZ(0)",
          "&:hover": {
            boxShadow: "0 20px 30px rgba(0, 0, 0, 0.4)",
          },
        }}
      >

        <Box
          mt="25px"
          p="0 30px"
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <Typography variant="h4" fontWeight="600" color={colors.grey[100]}>
            Health Status
          </Typography>
        </Box>

        <Box
          mt="75px"
          p="0 30px"
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <RadarHealthStatus />
        </Box>
      </Box>

      {/* ROW 3 */}
      {[
        "System Parameters",
        "Power Supply",
        "Near Real Time Communication",
        "Archival System",
      ].map((title, index) => (
        <Box
          key={index}
          gridRow="span 1"
          backgroundColor={colors.primary[400]}
          p="30px"
          sx={{
            gridColumn: {
              xs: "span 12", // Full width on extra-small screens
              sm: "span 6",  // Half width on small screens
              md: "span 4",  // One-third width on medium screens
              lg: "span 3",  // Quarter width on large screens
            },
            boxShadow: "0 10px 20px rgba(0, 0, 0, 0.3)",
            borderRadius: "10px",
            transform: "translateZ(0)",
            "&:hover": {
              boxShadow: "0 20px 30px rgba(0, 0, 0, 0.4)",
            },
          }}
        >

          <Typography variant="h4" fontWeight="600">
            {title}
          </Typography>
          {title === "System Parameters" && (
            <Box
              display="flex"
              justifyContent="center" // Centers the icon horizontally
              alignItems="center" // Centers the icon vertically
              sx={{
                width: "100%", // Take full width of the container
                height: "100%", // Make the Box take full height of its container
              }}
            >
              {/* <RadarCameraView /> */}

              {title === "System Parameters" && (
                <ConnectedTvIcon
                  sx={{
                    fontSize: {
                      xs: 30, // For extra-small screens (mobile)
                      sm: 40, // For small screens (tablets)
                      md: 80, // For medium screens (desktops)
                    },
                    color: "#7a96a1", // Icon color
                  }}
                />
              )}
            </Box>
          )}

          {title === "Power Supply" && (
            <Box
              display="flex"
              justifyContent="center" // Centers the icon horizontally
              alignItems="center" // Centers the icon vertically
              sx={{
                width: "100%", // Take full width of the container
                height: "100%", // Make the Box take full height of its container
              }}
            >
              {/* Power Supply icon with heading */}
              {title === "Power Supply" && (
                <Box textAlign="center">
                  <Typography variant="h6" sx={{ mb: 1 }}>
                    Servo
                  </Typography>
                  <ElectricalServicesIcon
                    sx={{
                      fontSize: {
                        xs: 30, // For extra-small screens (mobile)
                        sm: 40, // For small screens (tablets)
                        md: 40, // For medium screens (desktops)
                      },
                      color: "green", // Icon color
                    }}
                  />
                </Box>
              )}

              {/* Another icon example (add your own titles and icons similarly) */}
              {title === "Power Supply" && (
                <Box textAlign="center">
                  <Typography variant="h6" sx={{ mb: 1 }}>
                    RSP
                  </Typography>
                  <ElectricalServicesIcon
                    sx={{
                      fontSize: {
                        xs: 30, // For extra-small screens (mobile)
                        sm: 40, // For small screens (tablets)
                        md: 40, // For medium screens (desktops)
                      },
                      color: "green", // Icon color
                    }}
                  />
                </Box>
              )}

              {/* You can repeat the same structure for other icons with different colors */}
              {title === "Power Supply" && (
                <Box textAlign="center">
                  <Typography variant="h6" sx={{ mb: 1 }}>
                    NAS
                  </Typography>
                  <ElectricalServicesIcon
                    sx={{
                      fontSize: {
                        xs: 30, // For extra-small screens (mobile)
                        sm: 40, // For small screens (tablets)
                        md: 40, // For medium screens (desktops)
                      },
                      color: "red", // Icon color
                    }}
                  />
                </Box>
              )}

              {title === "Power Supply" && (
                <Box textAlign="center">
                  <Typography variant="h6" sx={{ mb: 1 }}>
                    TX
                  </Typography>
                  <ElectricalServicesIcon
                    sx={{
                      fontSize: {
                        xs: 30, // For extra-small screens (mobile)
                        sm: 40, // For small screens (tablets)
                        md: 40, // For medium screens (desktops)
                      },
                      color: "red", // Icon color
                    }}
                  />
                </Box>
              )}

              {title === "Power Supply" && (
                <Box textAlign="center">
                  <Typography variant="h6" sx={{ mb: 1 }}>
                    RX
                  </Typography>
                  <ElectricalServicesIcon
                    sx={{
                      fontSize: {
                        xs: 30, // For extra-small screens (mobile)
                        sm: 40, // For small screens (tablets)
                        md: 40, // For medium screens (desktops)
                      },
                      color: "green", // Icon color
                    }}
                  />
                </Box>
              )}

              {/* Repeat for any other cases */}
            </Box>
          )}

          {title === "Archival System" && (
            <Box
              display="flex"
              justifyContent="center" // Centers the icon horizontally
              alignItems="center" // Centers the icon vertically
              sx={{
                width: "100%", // Take full width of the container
                height: "100%", // Make the Box take full height of its container
              }}
            >
              {/* <RadarCameraView /> */}

              {title === "Archival System" && (
                <StorageIcon
                  sx={{
                    fontSize: {
                      xs: 30, // For extra-small screens (mobile)
                      sm: 40, // For small screens (tablets)
                      md: 80, // For medium screens (desktops)
                    },
                    color: "#7a96a1", // Icon color
                  }}
                />
              )}
            </Box>
          )}

          {title === "Near Real Time Communication" && (
            <Box
              display="flex"
              justifyContent="center" // Centers the icon horizontally
              alignItems="center" // Centers the icon vertically
              sx={{
                width: "100%", // Take full width of the container
                height: "100%", // Make the Box take full height of its container
              }}
            >
              {/* <RadarCameraView /> */}

              {title === "Near Real Time Communication" && (
                <RadarIcon
                  sx={{
                    fontSize: {
                      xs: 30, // For extra-small screens (mobile)
                      sm: 40, // For small screens (tablets)
                      md: 80, // For medium screens (desktops)
                    },
                    color: "#7a96a1", // Icon color
                  }}
                />
              )}
            </Box>
          )}

          {/* {
                            (index === 0 || index === 2) &&
                        <RadarLoader />} */}
        </Box>
      ))}
    </Box>
  );
};

export default Index;
