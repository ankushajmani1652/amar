import React, { useState } from "react";
import { Box, Typography, Button, TextField, Switch } from "@mui/material";

const DefaultParameter = () => {
  // State to track which parameters are currently open
  const [openParameters, setOpenParameters] = useState({});
  const [isOn, setIsOn] = useState(false);
  const [toggles, setToggles] = useState({});
  const [selectedParam, setSelectedParam] = useState(null);
  const [togglesDisplay1, setTogglesDisplay1] = useState({});
  const [togglesDisplay2, setTogglesDisplay2] = useState({});
  const [togglesDisplay3, setTogglesDisplay3] = useState({});
  const [togglesDisplay4, setTogglesDisplay4] = useState({});
  const [togglesDisplay5, setTogglesDisplay5] = useState({});
  const [togglesDisplay6, setTogglesDisplay6] = useState({});

  const parameters = [
    { name: "Weather Radar Signal Processing", value: "" },
    { name: "WRSP Horizontal", value: "" },
    { name: "WRSP Vertical", value: "" },
    // { name: "Archival Path", value: "" },
    // { name: "NRT", value: "" },
    { name: "Display Base Products", value: "" },
    // { name: "Display 2 Base Product Selection", value: "" },
    // { name: "Display 3 Base Product Selection", value: "" },
    // { name: "Display 4 Base Product Selection", value: "" },
    // { name: "Display 5 Base Product Selection", value: "" },
    // { name: "Display 6 Base Product Selection", value: "" },
  ];

  const wrspLabels = [
    { label: " Min Reflectivity", key: "" },
    { label: " Max Reflectivity", key: "" },
    { label: "Min Velocity", key: "" },
    { label: "Max Velocity", key: "" },
    { label: "Min Vw", key: "" },
    { label: "Max Vw", key: "" },
    { label: "Min Zdr", key: "" },
    { label: "Max Zdr", key: "" },
    { label: "Min Phidp", key: "" },
    { label: "Max Phidp", key: "" },
    { label: "Min Ldr", key: "" },
    { label: "Max Ldr", key: "" },

    { label: "IF1 Zdr Offset", key: "" },
    { label: "IF2 Zdr Offset", key: "" },
    { label: "IF3 Zdr Offset", key: "" },
    { label: "IF1 Phase Offset", key: "" },
    { label: "IF2 Phase Offset", key: "" },
    { label: "IF3 Phase Offset", key: "" },
    { label: "IF1 Pulse Compression Gain", key: "" },
    { label: "IF2Pulse Compression Gain", key: "" },
    { label: "IF3 Pulse Compression Gain", key: "" },
  ];

  const wrspHLabels = [
    { label: "Mean SNR", key: "" },
    { label: "IF1 Power Offset", key: "" },
    { label: "IF2 Power Offset", key: "" },
    { label: "IF3 Power Offset", key: "" },
    { label: "IF1 Velocity Width Offset", key: "" },
    { label: "IF2 Velocity Width Offset", key: "" },
    { label: "IF3 Velocity Width Offset", key: "" },
    { label: "IF1 Noise Floor", key: "" },
    { label: "IF2 Noise Floor", key: "" },
    { label: "IF3 Noise Floor", key: "" },
  ];

  const wrspVLabels = [
    { label: "Mean SNR", key: "" },
    { label: "IF1 Power Offset", key: "" },
    { label: "IF2 Power Offset", key: "" },
    { label: "IF3 Power Offset", key: "" },
    { label: "IF1 Velocity Width Offset", key: "" },
    { label: "IF2 Velocity Width Offset", key: "" },
    { label: "IF3 Velocity Width Offset", key: "" },
    { label: "IF1 Noise Floor", key: "" },
    { label: "IF2 Noise Floor", key: "" },
    { label: "IF3 Noise Floor", key: "" },
  ];

  const BPS = [
    { label: "ZH", key: "ZH" },
    { label: "ZV", key: "ZH2" }, // Example of assigning unique keys for each label
    { label: "UfZH", key: "UfZH" },
    { label: "UfZV", key: "UfZV" },
    { label: "RxSigH", key: "RxSigH" },
    { label: "RxSigV", key: "RxSigV" },
    { label: "SNRH", key: "SNRH" },
    { label: "SNRV", key: "SNRV" },
    { label: "NPH", key: "NPH" },
    { label: "VH", key: "VH" },
    { label: "VV", key: "VV" },
    { label: "VwH", key: "VwH" },
    { label: "VwV", key: "VwV" },
    { label: "Zdr", key: "Zdr" },
    { label: "Ldr", key: "Ldr" },
    { label: "Phidp", key: "Phidp" },
    { label: "Rho", key: "Rho" },
    { label: "Kdp", key: "Kdp" },
    { label: "LogH", key: "LogH" },
    { label: "LogV", key: "LogV" },
    { label: "SQIH", key: "SQIH" },
    { label: "SQIV", key: "SQIV" },
    { label: "CCORH", key: "CCORH" },
    { label: "CCORV", key: "CCORV" },
    { label: "SRI", key: "SRI" },
  ];

  // const BPS2 = [
  //   { label: "ZH", key: "ZH" },
  //   { label: "ZV", key: "ZH2" }, // Example of assigning unique keys for each label
  //   { label: "UfZH", key: "UfZH" },
  //   { label: "UfZV", key: "UfZV" },
  //   { label: "RxSigH", key: "RxSigH" },
  //   { label: "RxSigV", key: "RxSigV" },
  //   { label: "SNRH", key: "SNRH" },
  //   { label: "SNRV", key: "SNRV" },
  //   { label: "NPH", key: "NPH" },
  //   { label: "VH", key: "VH" },
  //   { label: "VV", key: "VV" },
  //   { label: "VwH", key: "VwH" },
  //   { label: "VwV", key: "VwV" },
  //   { label: "Zdr", key: "Zdr" },
  //   { label: "Ldr", key: "Ldr" },
  //   { label: "Phidp", key: "Phidp" },
  //   { label: "Rho", key: "Rho" },
  //   { label: "Kdp", key: "Kdp" },
  //   { label: "LogH", key: "LogH" },
  //   { label: "LogV", key: "LogV" },
  //   { label: "SQIH", key: "SQIH" },
  //   { label: "SQIV", key: "SQIV" },
  //   { label: "CCORH", key: "CCORH" },
  //   { label: "CCORV", key: "CCORV" },
  //   { label: "SRI", key: "SRI" },
  // ];

  // const BPS3 = [
  //   { label: "ZH", key: "ZH" },
  //   { label: "ZV", key: "ZH2" }, // Example of assigning unique keys for each label
  //   { label: "UfZH", key: "UfZH" },
  //   { label: "UfZV", key: "UfZV" },
  //   { label: "RxSigH", key: "RxSigH" },
  //   { label: "RxSigV", key: "RxSigV" },
  //   { label: "SNRH", key: "SNRH" },
  //   { label: "SNRV", key: "SNRV" },
  //   { label: "NPH", key: "NPH" },
  //   { label: "VH", key: "VH" },
  //   { label: "VV", key: "VV" },
  //   { label: "VwH", key: "VwH" },
  //   { label: "VwV", key: "VwV" },
  //   { label: "Zdr", key: "Zdr" },
  //   { label: "Ldr", key: "Ldr" },
  //   { label: "Phidp", key: "Phidp" },
  //   { label: "Rho", key: "Rho" },
  //   { label: "Kdp", key: "Kdp" },
  //   { label: "LogH", key: "LogH" },
  //   { label: "LogV", key: "LogV" },
  //   { label: "SQIH", key: "SQIH" },
  //   { label: "SQIV", key: "SQIV" },
  //   { label: "CCORH", key: "CCORH" },
  //   { label: "CCORV", key: "CCORV" },
  //   { label: "SRI", key: "SRI" },
  // ];

  // const BPS4 = [
  //   { label: "ZH", key: "ZH" },
  //   { label: "ZV", key: "ZH2" }, // Example of assigning unique keys for each label
  //   { label: "UfZH", key: "UfZH" },
  //   { label: "UfZV", key: "UfZV" },
  //   { label: "RxSigH", key: "RxSigH" },
  //   { label: "RxSigV", key: "RxSigV" },
  //   { label: "SNRH", key: "SNRH" },
  //   { label: "SNRV", key: "SNRV" },
  //   { label: "NPH", key: "NPH" },
  //   { label: "VH", key: "VH" },
  //   { label: "VV", key: "VV" },
  //   { label: "VwH", key: "VwH" },
  //   { label: "VwV", key: "VwV" },
  //   { label: "Zdr", key: "Zdr" },
  //   { label: "Ldr", key: "Ldr" },
  //   { label: "Phidp", key: "Phidp" },
  //   { label: "Rho", key: "Rho" },
  //   { label: "Kdp", key: "Kdp" },
  //   { label: "LogH", key: "LogH" },
  //   { label: "LogV", key: "LogV" },
  //   { label: "SQIH", key: "SQIH" },
  //   { label: "SQIV", key: "SQIV" },
  //   { label: "CCORH", key: "CCORH" },
  //   { label: "CCORV", key: "CCORV" },
  //   { label: "SRI", key: "SRI" },
  // ];

  // const BPS6 = [
  //   { label: "ZH", key: "ZH" },
  //   { label: "ZV", key: "ZH2" }, // Example of assigning unique keys for each label
  //   { label: "UfZH", key: "UfZH" },
  //   { label: "UfZV", key: "UfZV" },
  //   { label: "RxSigH", key: "RxSigH" },
  //   { label: "RxSigV", key: "RxSigV" },
  //   { label: "SNRH", key: "SNRH" },
  //   { label: "SNRV", key: "SNRV" },
  //   { label: "NPH", key: "NPH" },
  //   { label: "VH", key: "VH" },
  //   { label: "VV", key: "VV" },
  //   { label: "VwH", key: "VwH" },
  //   { label: "VwV", key: "VwV" },
  //   { label: "Zdr", key: "Zdr" },
  //   { label: "Ldr", key: "Ldr" },
  //   { label: "Phidp", key: "Phidp" },
  //   { label: "Rho", key: "Rho" },
  //   { label: "Kdp", key: "Kdp" },
  //   { label: "LogH", key: "LogH" },
  //   { label: "LogV", key: "LogV" },
  //   { label: "SQIH", key: "SQIH" },
  //   { label: "SQIV", key: "SQIV" },
  //   { label: "CCORH", key: "CCORH" },
  //   { label: "CCORV", key: "CCORV" },
  //   { label: "SRI", key: "SRI" },
  // ];

  // const BPS5 = [
  //   { label: "ZH", key: "ZH" },
  //   { label: "ZV", key: "ZH2" }, // Example of assigning unique keys for each label
  //   { label: "UfZH", key: "UfZH" },
  //   { label: "UfZV", key: "UfZV" },
  //   { label: "RxSigH", key: "RxSigH" },
  //   { label: "RxSigV", key: "RxSigV" },
  //   { label: "SNRH", key: "SNRH" },
  //   { label: "SNRV", key: "SNRV" },
  //   { label: "NPH", key: "NPH" },
  //   { label: "VH", key: "VH" },
  //   { label: "VV", key: "VV" },
  //   { label: "VwH", key: "VwH" },
  //   { label: "VwV", key: "VwV" },
  //   { label: "Zdr", key: "Zdr" },
  //   { label: "Ldr", key: "Ldr" },
  //   { label: "Phidp", key: "Phidp" },
  //   { label: "Rho", key: "Rho" },
  //   { label: "Kdp", key: "Kdp" },
  //   { label: "LogH", key: "LogH" },
  //   { label: "LogV", key: "LogV" },
  //   { label: "SQIH", key: "SQIH" },
  //   { label: "SQIV", key: "SQIV" },
  //   { label: "CCORH", key: "CCORH" },
  //   { label: "CCORV", key: "CCORV" },
  //   { label: "SRI", key: "SRI" },
  // ];
  // Handle when a parameter is clicked
  const handleParameterClick = (param) => {
    setSelectedParam(param.name);

    setOpenParameters((prev) => ({
      ...prev,
      [param.name]: { ...param, isOpen: true }, // Open the box for this specific parameter
    }));
  };

  // Handle saving the parameter value
  const handleSaveParameter = (paramName, newValue) => {
    setOpenParameters((prev) => ({
      ...prev,
      [paramName]: { ...prev[paramName], value: newValue }, // Save the updated value
    }));
  };

  // Handle closing a specific parameter's box
  const handleCloseParameterBox = (paramName) => {
    setOpenParameters((prev) => {
      const updatedParams = { ...prev };
      delete updatedParams[paramName]; // Close the box for this parameter
      return updatedParams;
    });
    setSelectedParam(null);
  };

  const handleOnOffChange = (displayName, labelKey, event) => {
    // Determine which state to update based on the display name
    if (displayName === "Display 1") {
      setTogglesDisplay1((prevState) => ({
        ...prevState,
        [labelKey]: event.target.checked, // Update only the specific toggle for Display 1
      }));
    } else if (displayName === "Display 2") {
      setTogglesDisplay2((prevState) => ({
        ...prevState,
        [labelKey]: event.target.checked, // Update only the specific toggle for Display 2
      }));
    } else if (displayName === "Display 3") {
      setTogglesDisplay3((prevState) => ({
        ...prevState,
        [labelKey]: event.target.checked, // Update only the specific toggle for Display 3
      }));
    } else if (displayName === "Display 4") {
      setTogglesDisplay4((prevState) => ({
        ...prevState,
        [labelKey]: event.target.checked, // Update only the specific toggle for Display 3
      }));
    } else if (displayName === "Display 5") {
      setTogglesDisplay5((prevState) => ({
        ...prevState,
        [labelKey]: event.target.checked, // Update only the specific toggle for Display 3
      }));
    } else if (displayName === "Display 6") {
      setTogglesDisplay6((prevState) => ({
        ...prevState,
        [labelKey]: event.target.checked, // Update only the specific toggle for Display 3
      }));
    }
    // Add more conditions for additional displays (e.g., Display 4, Display 5, etc.)
  };

  return (
    <Box display="flex" gap="12px" maxWidth="1900px" padding={2}>
      {/* Left Panel - Parameter List */}
      <Box
        display="flex"
        flexDirection="column"
        gap="12px"
        maxWidth="400px"
        width="400px"
      >
        {/* Top Buttons */}
        <Box
          display="flex"
          gap="16px"
          justifyContent="space-between"
          marginBottom={2}
        >
          <Button variant="contained" color="primary" sx={{ width: "100%" }}>
            Update Default
          </Button>
          <Button variant="contained" color="secondary" sx={{ width: "100%" }}>
            Load Default
          </Button>
          <Button variant="contained" color="success" sx={{ width: "100%" }}>
            Configure
          </Button>
        </Box>

        {/* Parameter List */}
        {parameters.map((param, index) => (
          <Box
            key={index}
            onClick={() => handleParameterClick(param)} // Attach click handler
            sx={{
              display: "flex",
              justifyContent: "space-between",
              background:
                selectedParam === param.name
                  ? "rgba(0, 255, 0, 0.1)" // Light green background for selected param
                  : "rgba(255, 255, 255, 0.1)", // Default background color
              borderRadius: "8px",
              padding: "8px 16px",
              boxShadow:
                selectedParam === param.name
                  ? "0 4px 8px rgba(0, 255, 0, 0.6)" // Green box shadow for selected param
                  : "0 2px 4px rgba(0, 0, 0, 0.2)", // Default box shadow
              cursor: "pointer", // Indicate clickable area
              "&:hover": {
                backgroundColor:
                  selectedParam === param.name
                    ? "rgba(0, 255, 0, 0.2)" // Darker green on hover if selected
                    : "rgba(255, 255, 255, 0.2)", // Default hover color
              },
              border: selectedParam === param.name ? "2px solid green" : "none", // Green border for selected param
              width: "100%", // Ensure the box takes full width of its container
            }}
          >
            <Typography
              variant="subtitle1"
              sx={{
                fontWeight: "bold",
                color: "#333",
                textTransform: "uppercase",
              }}
            >
              {param.name}
            </Typography>
            <Typography
              variant="h6"
              sx={{ fontWeight: "medium", color: "#333" }}
            >
              {param.value}
            </Typography>
          </Box>
        ))}
      </Box>

      {/* Right Panel - Parameter-Specific Boxes */}
      <Box
        display="flex"
        flexDirection="column"
        gap="12px"
        sx={{
          flex: 1,
          paddingLeft: "16px",
          overflowY: "auto", // Enable vertical scrolling
          maxHeight: "840px", // Set the maximum height of the box
          width: "80%", // Adjust the width (can be percentage or px)
        }}
      >
        {Object.keys(openParameters).map((paramName) => {
          const param = openParameters[paramName];

          return (
            <Box
              key={paramName}
              sx={{
                background: "rgba(241, 235, 235, 0.9)",
                borderRadius: "8px",
                padding: "16px",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
              }}
            >
              <Typography
                variant="h5"
                sx={{ fontWeight: "bold", marginBottom: "16px" }}
              >
                {param.name}
              </Typography>

              {/* Add additional fields for Weather Radar Signal Processing */}

              {param.name === "Weather Radar Signal Processing" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {wrspLabels.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{ marginBottom: "8px", fontWeight: "bold" }}
                      >
                        {label.label}
                      </Typography>
                      <TextField
                        value={param[label.key]} // Default value is 0 if not set
                        onChange={(e) =>
                          handleSaveParameter(param.name, {
                            ...param,
                            [label.key]: e.target.value,
                          })
                        }
                        sx={{
                          width: "100%",
                          background: "white",
                        }}
                        InputProps={{
                          disableUnderline: true, // Remove underline from TextField
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {param.name === "WRSP Horizontal" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {wrspHLabels.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{ marginBottom: "8px", fontWeight: "bold" }}
                      >
                        {label.label}
                      </Typography>
                      <TextField
                        value={param[label.key]} // Default value is 0 if not set
                        onChange={(e) =>
                          handleSaveParameter(param.name, {
                            ...param,
                            [label.key]: e.target.value,
                          })
                        }
                        sx={{
                          width: "100%",
                          background: "white",
                        }}
                        InputProps={{
                          disableUnderline: true, // Remove underline from TextField
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {param.name === "WRSP Vertical" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {wrspVLabels.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{ marginBottom: "8px", fontWeight: "bold" }}
                      >
                        {label.label}
                      </Typography>
                      <TextField
                        value={param[label.key]} // Default value is 0 if not set
                        onChange={(e) =>
                          handleSaveParameter(param.name, {
                            ...param,
                            [label.key]: e.target.value,
                          })
                        }
                        sx={{
                          width: "100%",
                          background: "white",
                        }}
                        InputProps={{
                          disableUnderline: true, // Remove underline from TextField
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {param.name === "Display Base Products" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {BPS.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{
                          marginBottom: "8px",
                          fontWeight: "bold",
                          marginLeft: "12px",
                        }}
                      >
                        {label.label}
                      </Typography>
                      <Switch
                        checked={togglesDisplay1[label.key] || false} // Use the specific toggle for Display 1
                        onChange={
                          (event) =>
                            handleOnOffChange("Display 1", label.key, event) // Pass the display name and label key
                        }
                        sx={{
                          "& .MuiSwitch-thumb": {
                            backgroundColor: togglesDisplay1[label.key]
                              ? "green"
                              : "red",
                          },
                          "& .MuiSwitch-track": {
                            backgroundColor: togglesDisplay1[label.key]
                              ? "rgba(0, 255, 0, 0.5)"
                              : "rgba(255, 0, 0, 0.5)",
                          },
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {/* {param.name === "Display 2 Base Product Selection" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {BPS2.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{
                          marginBottom: "8px",
                          fontWeight: "bold",
                          marginLeft: "12px",
                        }}
                      >
                        {label.label}
                      </Typography>
                      <Switch
                        checked={togglesDisplay2[label.key] || false} // Use the specific toggle for Display 2
                        onChange={
                          (event) =>
                            handleOnOffChange("Display 2", label.key, event) // Pass the display name and label key
                        }
                        sx={{
                          "& .MuiSwitch-thumb": {
                            backgroundColor: togglesDisplay2[label.key]
                              ? "green"
                              : "red",
                          },
                          "& .MuiSwitch-track": {
                            backgroundColor: togglesDisplay2[label.key]
                              ? "rgba(0, 255, 0, 0.5)"
                              : "rgba(255, 0, 0, 0.5)",
                          },
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {param.name === "Display 3 Base Product Selection" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {BPS3.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{
                          marginBottom: "8px",
                          fontWeight: "bold",
                          marginLeft: "12px",
                        }}
                      >
                        {label.label}
                      </Typography>
                      <Switch
                        checked={togglesDisplay3[label.key] || false} // Use the specific toggle for Display 3
                        onChange={
                          (event) =>
                            handleOnOffChange("Display 3", label.key, event) // Pass the display name and label key
                        }
                        sx={{
                          "& .MuiSwitch-thumb": {
                            backgroundColor: togglesDisplay3[label.key]
                              ? "green"
                              : "red",
                          },
                          "& .MuiSwitch-track": {
                            backgroundColor: togglesDisplay3[label.key]
                              ? "rgba(0, 255, 0, 0.5)"
                              : "rgba(255, 0, 0, 0.5)",
                          },
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {param.name === "Display 4 Base Product Selection" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {BPS4.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{
                          marginBottom: "8px",
                          fontWeight: "bold",
                          marginLeft: "12px",
                        }}
                      >
                        {label.label}
                      </Typography>
                      <Switch
                        checked={togglesDisplay4[label.key] || false} // Use the specific state for Display 4
                        onChange={
                          (event) =>
                            handleOnOffChange("Display 4", label.key, event) // Pass display name and label key
                        }
                        sx={{
                          "& .MuiSwitch-thumb": {
                            backgroundColor: togglesDisplay4[label.key]
                              ? "green"
                              : "red",
                          },
                          "& .MuiSwitch-track": {
                            backgroundColor: togglesDisplay4[label.key]
                              ? "rgba(0, 255, 0, 0.5)"
                              : "rgba(255, 0, 0, 0.5)",
                          },
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {param.name === "Display 5 Base Product Selection" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {BPS5.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{
                          marginBottom: "8px",
                          fontWeight: "bold",
                          marginLeft: "12px",
                        }}
                      >
                        {label.label}
                      </Typography>
                      <Switch
                        checked={togglesDisplay5[label.key] || false} // Use the specific state for Display 5
                        onChange={
                          (event) =>
                            handleOnOffChange("Display 5", label.key, event) // Pass display name and label key
                        }
                        sx={{
                          "& .MuiSwitch-thumb": {
                            backgroundColor: togglesDisplay5[label.key]
                              ? "green"
                              : "red",
                          },
                          "& .MuiSwitch-track": {
                            backgroundColor: togglesDisplay5[label.key]
                              ? "rgba(0, 255, 0, 0.5)"
                              : "rgba(255, 0, 0, 0.5)",
                          },
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}

              {param.name === "Display 6 Base Product Selection" && (
                <Box display="flex" flexWrap="wrap" gap="16px">
                  {BPS6.map((label, index) => (
                    <Box
                      key={index}
                      sx={{
                        width: "calc(14.28% - 12px)",
                        marginBottom: "16px",
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{
                          marginBottom: "8px",
                          fontWeight: "bold",
                          marginLeft: "12px",
                        }}
                      >
                        {label.label}
                      </Typography>
                      <Switch
                        checked={togglesDisplay6[label.key] || false} // Use the specific state for Display 6
                        onChange={
                          (event) =>
                            handleOnOffChange("Display 6", label.key, event) // Pass display name and label key
                        }
                        sx={{
                          "& .MuiSwitch-thumb": {
                            backgroundColor: togglesDisplay6[label.key]
                              ? "green"
                              : "red",
                          },
                          "& .MuiSwitch-track": {
                            backgroundColor: togglesDisplay6[label.key]
                              ? "rgba(0, 255, 0, 0.5)"
                              : "rgba(255, 0, 0, 0.5)",
                          },
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )} */}

              <Box display="flex" gap="16px">
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleSaveParameter(param.name, param.value)}
                  sx={{ flex: 1, background: "green" }}
                >
                  Save
                </Button>
                <Button
                  variant="outlined"
                  color="red"
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent the parent Box click handler from firing
                    handleCloseParameterBox(param.name); // Close this parameter's box
                  }}
                  sx={{
                    flex: 1,
                    background: "#f7727d",
                    ":hover": { backgroundColor: "#f7727d" }, // Prevent the hover effect on the close button
                  }}
                >
                  Close
                </Button>
              </Box>
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default DefaultParameter;
