import React, { useEffect, useState } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { toggleServoPower, applyServoSettings } from "./servoSlice";

import {
  connectToSocket,
  sendPowerToggleRequest,
  sendFormData,
} from "../../services/websocketServer";

import {
  Button,
  TextField,
  Box,
  IconButton,
  CircularProgress,
  Typography,
  Paper,
  Tabs,
  Tab,
  Divider,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

const PowerButton = () => {
  const dispatch = useDispatch();
  const [power, setPower] = useState(false);
  const [loading, setLoadingState] = useState(false);
  const [error, setErrorState] = useState(null);
  const [mode, setMode] = useState("manual"); // Default to 'manual' mode
  const [formData, setFormData] = useState({
    azimuthDirection: "false",
    azimuthSpeed: "",
    azimuthEnable: "",
    elevationDirection: "",
    elevationSpeed: "",
    elevationEnable: "",
    designateType: "",
    azimuthDesignateAngle: "",
    elevationDesignateAngle: "",
  });

  // Connect to WebSocket and set up event listeners
  useEffect(() => {
    connectToSocket(dispatch); // Connect and listen to server updates
  }, [dispatch]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleApplySettings = () => {
    console.log("Settings to be applied:", formData);

    let dataToSend;

    if (mode === "manual") {
      const servoManualModePacket = {
        azimuthDirection: formData.azimuthDirection,
        azimuthSpeed: formData.azimuthSpeed,
        azimuthEnable: formData.azimuthEnable === "true", // Convert to boolean if necessary
        elevationDirection: formData.elevationDirection,
        elevationSpeed: formData.elevationSpeed,
        elevationEnable: formData.elevationEnable === "true", // Convert to boolean if necessary
      };
      dataToSend = { mode, servoManualModePacket }; // Send form data for manual mode
      console.log("Sending data to WebSocket:", dataToSend);
    } else if (mode === "designated") {
      dataToSend = { mode, formData }; // Send form data for designated mode
    } else {
      console.error("Invalid mode");
      return;
    }

    console.log("Sending data to WebSocket:", dataToSend);

    // Send form data via WebSocket
    sendFormData(dataToSend, setLoadingState, setErrorState);
  };

  const handleModeChange = (event, newMode) => {
    setMode(newMode); // Set the mode to either 'manual' or 'designated'
  };

  const handlePowerToggle = () => {
    const newPowerState = !power;
    sendPowerToggleRequest(dispatch, newPowerState ? 0x01 : 0x00); // Send the updated power state
    setPower(newPowerState); // Update local power state
  };
  const handleClose = () => {
    setPower(false); // Or reset other relevant states
  };

  // const handleTogglePower = () => {
  //   dispatch(toggleServoPower(power)); // Toggle the servo power
  // };

  return (
    <Box
    // display="flex"
    // justifyContent="flex-start"
    // alignItems="center"
    // minHeight=""
    // sx={{ backgroundColor: "transparent" }}
    >
      <Paper
      // sx={{
      //   padding: "",
      //   width: 200,
      //   borderRadius: 1,
      //   backgroundColor: "transparent",

      // }}
      >
        {/* <Typography
          variant="body1"
          color="textSecondary"
          align="center"
          gutterBottom
        >
          Current Status: {power ? "On" : "Off"}
        </Typography> */}

        {/* Power Button */}
        <Button
          variant="contained"
          color={power ? "error" : "primary"}
          onClick={handlePowerToggle}
          disabled={loading}
          fullWidth
          sx={{
            mt: 0,
            py: 0,
            width: 200,
            fontSize: "1rem",
            fontWeight: "bold",
          }}
        >
          {loading ? (
            <CircularProgress size={24} sx={{ color: "white" }} />
          ) : power ? (
            "Turn Off"
          ) : (
            "Power On"
          )}
        </Button>

        {/* <Divider sx={{ my: 2 }} /> */}

        {/* Mode Tabs only shown if power is ON */}
        {power && (
          <>
            <Box display="flex" justifyContent="flex-end" mb={2}>
              <Button
                onClick={handleClose}
                variant="contained"
                color="secondary"
                sx={{
                  backgroundColor: "red",
                  color: "white",
                  "&:hover": {
                    backgroundColor: "darkred",
                  },
                }}
              >
                Close
              </Button>
            </Box>
            <Tabs
              value={mode}
              onChange={handleModeChange}
              centered
              sx={{
                color: "red",
                mb: 5,
                "& .MuiTab-root": {
                  color: "white", // Sets the color of all tabs to white
                },
                "& .Mui-selected": {
                  color: "red", // Ensures the active tab is also white
                },
                "& .MuiTabs-indicator": {
                  backgroundColor: "white", // Optional: Change the indicator color to white for better visibility
                },
              }}
            >
              <Tab value="manual" label="Manual Mode" />
              <Tab value="designated" label="Designated Mode" />
            </Tabs>

            {/* Manual Mode Form Fields */}
            {mode === "manual" && (
              <Box mt={2}>
                <Typography variant="h5" align="center" gutterBottom>
                  Manual Mode
                </Typography>
                <FormControl fullWidth margin="normal">
                  <InputLabel>Azimuth Direction</InputLabel>
                  <Select
                    label="Azimuth Direction"
                    name="azimuthDirection"
                    value={formData.azimuthDirection}
                    onChange={handleInputChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        "& fieldset": {
                          borderColor: "white", // Set border color to white (optional)
                        },
                        "&:hover fieldset": {
                          borderColor: "white", // Change border color on hover
                        },
                        "&.Mui-focused fieldset": {
                          borderColor: "white", // Change border color when focused
                        },
                      },
                      "& .MuiFormLabel-root": {
                        color: "white", // Keep the label color white
                        "&.Mui-focused": {
                          color: "white", // Prevent label color change on focus
                        },
                      },
                    }}
                  >
                    <MenuItem value="CW">CW</MenuItem>
                    <MenuItem value="ACW">ACW</MenuItem>
                  </Select>
                </FormControl>

                <TextField
                  label="Azimuth Speed"
                  name="azimuthSpeed"
                  type="number"
                  value={formData.azimuthSpeed}
                  onChange={handleInputChange}
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <FormControl fullWidth margin="normal">
                  <InputLabel>Azimuth Axis Enable</InputLabel>
                  <Select
                    label="Azimuth Axis Enable"
                    name="azimuthEnable"
                    value={formData.azimuthEnable}
                    onChange={handleInputChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        "& fieldset": {
                          borderColor: "white", // Set border color to white (optional)
                        },
                        "&:hover fieldset": {
                          borderColor: "white", // Change border color on hover
                        },
                        "&.Mui-focused fieldset": {
                          borderColor: "white", // Change border color when focused
                        },
                      },
                      "& .MuiFormLabel-root": {
                        color: "white", // Keep the label color white
                        "&.Mui-focused": {
                          color: "white", // Prevent label color change on focus
                        },
                      },
                    }}
                  >
                    <MenuItem value={true}>Enable</MenuItem>
                    <MenuItem value={false}>Disable</MenuItem>
                  </Select>
                </FormControl>
                <FormControl fullWidth margin="normal">
                  <InputLabel>Elevation Direction</InputLabel>
                  <Select
                    label="Elevation Direction"
                    name="elevationDirection"
                    value={formData.elevationDirection}
                    onChange={handleInputChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        "& fieldset": {
                          borderColor: "white", // Set border color to white (optional)
                        },
                        "&:hover fieldset": {
                          borderColor: "white", // Change border color on hover
                        },
                        "&.Mui-focused fieldset": {
                          borderColor: "white", // Change border color when focused
                        },
                      },
                      "& .MuiFormLabel-root": {
                        color: "white", // Keep the label color white
                        "&.Mui-focused": {
                          color: "white", // Prevent label color change on focus
                        },
                      },
                    }}
                  >
                    <MenuItem value="UP">UP</MenuItem>
                    <MenuItem value="DOWN">DOWN</MenuItem>
                  </Select>
                </FormControl>
                <TextField
                  label="Elevation Speed"
                  name="elevationSpeed"
                  type="number"
                  value={formData.elevationSpeed}
                  onChange={handleInputChange}
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <FormControl fullWidth margin="normal">
                  <InputLabel>Elevation Axis Enable</InputLabel>
                  <Select
                    label="Elevation Axis Enable"
                    name="elevationEnable"
                    value={formData.elevationEnable}
                    onChange={handleInputChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        "& fieldset": {
                          borderColor: "white", // Set border color to white (optional)
                        },
                        "&:hover fieldset": {
                          borderColor: "white", // Change border color on hover
                        },
                        "&.Mui-focused fieldset": {
                          borderColor: "white", // Change border color when focused
                        },
                      },
                      "& .MuiFormLabel-root": {
                        color: "white", // Keep the label color white
                        "&.Mui-focused": {
                          color: "white", // Prevent label color change on focus
                        },
                      },
                    }}
                  >
                    <MenuItem value={true}>Enable</MenuItem>
                    <MenuItem value={false}>Disable</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            )}

            {/* Designated Mode Form Fields */}
            {mode === "designated" && (
              <Box mt={2}>
                <Typography variant="h5" align="center" gutterBottom>
                  Designated Mode
                </Typography>
                <TextField
                  label="Designate Type "
                  type="number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <TextField
                  label="Azimuth Designate Angle "
                  type="number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <TextField
                  label="Azimuth Axis Speed"
                  type="number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <TextField
                  label="Azimuth Axis Enable "
                  type="number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <TextField
                  label="Elevation Designate Angle"
                  type="number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <TextField
                  label="Elevation Axis Speed"
                  type="number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
                <TextField
                  label="Elevation Axis Enable "
                  type="number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white", // Set border color to white (optional)
                      },
                      "&:hover fieldset": {
                        borderColor: "white", // Change border color on hover
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white", // Change border color when focused
                      },
                    },
                    "& .MuiFormLabel-root": {
                      color: "white", // Keep the label color white
                      "&.Mui-focused": {
                        color: "white", // Prevent label color change on focus
                      },
                    },
                  }}
                />
              </Box>
            )}

            {/* Apply Settings Button */}
            <Button
              variant="contained"
              color="primary"
              onClick={handleApplySettings}
              fullWidth
              sx={{
                mt: 3,
                py: 1.5, // Slightly increase padding for better click feel
                fontSize: "1rem", // Adjust font size
                fontWeight: "bold", // Make text bold
                textTransform: "uppercase", // Make text uppercase for emphasis
                backgroundColor: "#1976d2", // Set a custom color
                "&:hover": {
                  backgroundColor: "#155a9a", // Darker shade on hover
                },
                "&:disabled": {
                  backgroundColor: "#cccccc", // Lighter gray for disabled state
                  color: "#666666", // Adjust text color for disabled
                },
              }}
            >
              Apply Settings
            </Button>
          </>
        )}

        {error && (
          <Typography variant="body2" color="error" mt={2} align="center">
            {error}
          </Typography>
        )}
      </Paper>
    </Box>
  );
};

export default PowerButton;
