// import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
// import axios from 'axios';

// // Async Thunk for toggling power
// export const toggleServoPower = createAsyncThunk(
//     'servo/togglePower',
//     async (currentState, { rejectWithValue }) => {
//         try {
//             const response = await axios.post('http://localhost:5000/api/servo/toggle', { power: !currentState });
//             return response.data; // Expecting { power: true/false }
//         } catch (error) {
//             return rejectWithValue(error.response.data);
//         }
//     }
// );

// // Async Thunk for applying settings
// export const applyServoSettings = createAsyncThunk(
//     'servo/applySettings',
//     async (settings, { rejectWithValue }) => {
//         try {
//             const response = await axios.post('http://localhost:5000/api/servo/settings', settings);
//             return response.data; // Expecting a response like { success: true }
//         } catch (error) {
//             return rejectWithValue(error.response.data);
//         }
//     }
// );

// const servoSlice = createSlice({
//     name: 'servo',
//     initialState: {
//         power: false, // Servo initial power state
//         loading: false,
//         error: null,
//         formData: {
//             azimuthDirection: '',
//             azimuthSpeed: '',
//             azimuthEnable: '',
//             elevationDirection: '',
//             elevationSpeed: '',
//             elevationEnable: '',
//             spare: '',
//             designateType: '',
//             azimuthDesignateAngle: '',
//             elevationDesignateAngle: '',
//         }, // Store form data
//         mode: null, // Store the selected mode ('manual' or 'designated')
//     },
//     reducers: {
//         setFormData: (state, action) => {
//             // Update the form data with the new input
//             state.formData = { ...state.formData, ...action.payload };
//         },
//         setMode: (state, action) => {
//             // Update the mode (manual or designated)
//             state.mode = action.payload;
//         },
//         resetFormData: (state) => {
//             // Reset form data to initial state
//             state.formData = {
//                 azimuthDirection: '',
//                 azimuthSpeed: '',
//                 azimuthEnable: '',
//                 elevationDirection: '',
//                 elevationSpeed: '',
//                 elevationEnable: '',
//                 spare: '',
//                 designateType: '',
//                 azimuthDesignateAngle: '',
//                 elevationDesignateAngle: '',
//             };
//         },
//     },
//     extraReducers: (builder) => {
//         builder
//             .addCase(toggleServoPower.pending, (state) => {
//                 state.loading = true;
//                 state.error = null;
//             })
//             .addCase(toggleServoPower.fulfilled, (state, action) => {
//                 state.loading = false;
//                 state.power = action.payload.power;

//                 // Log the backend response to the console
//                 console.log('Backend response for power toggle:', action.payload);
//             })
//             .addCase(toggleServoPower.rejected, (state, action) => {
//                 state.loading = false;
//                 state.error = action.payload || 'Failed to power on Servo';
//             })
//             .addCase(applyServoSettings.pending, (state) => {
//                 state.loading = true;
//             })
//             .addCase(applyServoSettings.fulfilled, (state, action) => {
//                 state.loading = false;
//                 // Handle the successful response (e.g., show a success message or reset form data)
//                 state.formData = {
//                     azimuthDirection: '',
//                     azimuthSpeed: '',
//                     azimuthEnable: '',
//                     elevationDirection: '',
//                     elevationSpeed: '',
//                     elevationEnable: '',
//                     spare: '',
//                     designateType: '',
//                     azimuthDesignateAngle: '',
//                     elevationDesignateAngle: '',
//                 };
//             })
//             .addCase(applyServoSettings.rejected, (state, action) => {
//                 state.loading = false;
//                 state.error = action.payload || 'Failed to apply settings';
//             });
//     },
// });

// // Export actions to update form data, mode, etc.
// export const { setFormData, setMode, resetFormData } = servoSlice.actions;

// export default servoSlice.reducer;


import { createSlice } from '@reduxjs/toolkit';

const powerSlice = createSlice({
  name: 'power',
  initialState: {
    power: false, // Power state (on/off)
    loading: false, // Loading state
    error: null, // Error message (if any)
  },
  reducers: {
    setPowerState: (state, action) => {
      state.power = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
  },
});

export const { setPowerState, setLoading, setError } = powerSlice.actions;

export default powerSlice;
