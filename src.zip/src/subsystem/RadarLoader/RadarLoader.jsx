import React from "react";
import { Box, Grid, Typography, useMediaQuery, useTheme } from "@mui/material";

const RadarLoader = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm")); // Detect screen size

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      sx={{
        height: "vh", // Full height for loader
        padding: 0, // Adds spacing around the container
      }}
    >
      <Grid item xs={12} sm={6}>
        <Box
          sx={{
            position: "relative",
            width: isMobile ? "50px" : "100px", // Responsive width
            height: isMobile ? "50px" : "100px", // Responsive height
            border: "3px solid rgba(255, 255, 255, 0.3)", // Subtle border
            borderRadius: "20%", // Circular shape for loader
            boxShadow: "0 0 30px rgba(0, 0, 0, 0.5)", // More prominent shadow
            overflow: "hidden",
            backgroundColor: "#222", // Dark background for the loader
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            position: "relative",
          }}
        >
          {/* Scanning Line */}
          <Box
            sx={{
              position: "absolute",
              top: "0%",
              left: "0%",
              width: "100%",
              height: "5px",
              backgroundColor: "rgba(0, 255, 0, 0.8)", // Neon green scanning line
              boxShadow: "0 0 15px rgba(0, 255, 0, 0.8)", // Glowing effect
              animation: "scan 2s infinite",
            }}
          />
          {/* Add keyframes for the scanning animation */}
          <style>
            {`
              @keyframes scan {
                0% { top: 0%; }
                50% { top: 50%; }
                100% { top: 100%; }
              }
            `}
          </style>
          {/* Scanning Text */}
          <Typography
            variant="h6"
            sx={{
              position: "absolute",
              bottom: "20px",
              width: "100%",
              textAlign: "center",
              color: "#fff",
              fontWeight: "bold",
              letterSpacing: "1px",
              fontFamily: "'Roboto', sans-serif", // Stylish font
            }}
          >
            Scanning Mode
          </Typography>
        </Box>
      </Grid>
    </Grid>
  );
};

export default RadarLoader;
