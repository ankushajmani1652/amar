import { Card, Typography, Grid } from "@mui/material";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward"; // Up arrow for clockwise
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward"; // Down arrow for counter-clockwise

const RotatingMotor = ({ motorRunning, motorDirection }) => {
  const upArrowColor = motorRunning === true && motorDirection === false ? "green" : "lightgray"; // Green if running clockwise
  const downArrowColor = motorRunning === true && motorDirection === true ? "red" : "lightgray"; // Red if running counter-clockwise




  // console.log(`Motor Running ⚠️🎟️🎟️🎟️🎟️${motorRunning}`);
  
  return (
    <Grid item xs={12} sm={6} md={12}>
      <Card
        sx={{
          boxShadow: 0,
          borderRadius: 3,
          height: "95%",
          marginTop: "0.5%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: 3,
        }}
      >
        {/* Display Arrows Side by Side */}
        <Grid container spacing={4} justifyContent="center" alignItems="center">
          {/* Up Arrow */}
          <Grid item>
            <ArrowUpwardIcon
              sx={{
                fontSize: 117,
                color: upArrowColor, // Apply green when moving clockwise
                transition: "color 0.3s ease", // Smooth transition for color change
              }}
            />
          </Grid>

          {/* Down Arrow */}
          <Grid item>
            <ArrowDownwardIcon
              sx={{
                fontSize: 117,
                color: downArrowColor, // Apply red when moving counter-clockwise
                transition: "color 0.3s ease", // Smooth transition for color change
              }}
            />
          </Grid>
        </Grid>

        {/* Text Displaying Rotation Direction */}
        <Typography
          variant="h5"
          sx={{
            fontWeight: "bold",
            marginTop: 3,
            color:
              motorRunning === false
                ? "gray" // Not moving
                : motorDirection === 1
                ? "green" // Clockwise
                : "red", // Counter-clockwise
          }}
          fontFamily= "'Times New Roman', serif"
        >
          {/* Show text based on motor running status and direction */}
          {motorRunning === false
            ? "Not Moving"
            : motorDirection === false
            ? "UP"
            : "DOWN"}
        </Typography>
      </Card>
    </Grid>
  );
};

export default RotatingMotor;
