import { io } from 'socket.io-client';
import { setPowerState, setLoading,  setError } from '../subsystem/ServoSubsystem/servoSlice'

const socket = io('http://localhost:3000');  

const connectToSocket = (dispatch) => {
  socket.on('connect', () => {
    console.log('Connected to WebSocket server');
  });

  socket.on('disconnect', () => {
    console.log('Disconnected from WebSocket server');
  });

  socket.on('respons', (data) => {
    // Handle the response from the server
    if (data.success) {
      dispatch(setPowerState(data.powerState));  // Update power state
    } else {
      dispatch(setError(data.message));  // Set error message
    }
    dispatch(setLoading(false));  // Set loading to false after response
  });
};

const sendPowerToggleRequest = (dispatch, powerState) => {
  dispatch(setLoading(true)); // Set loading state
  socket.emit('power', { param: powerState.toString(16) });  // Send power state in hex format
};

const sendFormData = (mode, formData, setLoading, setError) => {
  setLoading(true); // Show loading spinner or indicator
  try {
    // Send both mode and form data together
    const dataToSend = {
      mode: mode,  // Either 'manual' or 'designated'
      formData: formData  // The actual form data
    };

    socket.emit('form', dataToSend);  // Send data to server
    console.log("Form data sent:", dataToSend);  // Debugging line to see what is sent

  } catch (error) {
    console.error("Error sending form data:", error);  // Log any errors
    setError("Failed to submit form data");
  }
};


export { connectToSocket, sendPowerToggleRequest, sendFormData  };
